#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
"""Various process handling utilities"""
from typing import Union, List, cast
import collections
from queue import Queue
import os
import signal
from subprocess import Popen, PIPE, TimeoutExpired, check_call, call, DEVNULL
from threading import Thread
from time import sleep
import psutil
import pprint

from e2e.constants.logger_type import LoggerType
from e2e.logger import get_logger

logger = get_logger(LoggerType.SHELL_COMMAND)

TIMEOUT_CODE = 255


class Process(psutil.Process):

    def _init(self, pid, _ignore_nsp=True):
        return super()._init(pid, _ignore_nsp)

    def __str__(self):
        try:
            info = collections.OrderedDict()
        except AttributeError:
            info = {}  # Python 2.6
        info["pid"] = self.pid
        try:
            info["name"] = self.name()
            info["cmdline"] = self.cmdline()
            if self._create_time:
                info['started'] = psutil._pprint_secs(self._create_time)
        except psutil.ZombieProcess:
            info["status"] = "zombie"
        except psutil.NoSuchProcess:
            info["status"] = "terminated"
        except psutil.AccessDenied:
            pass
        return "{cls}({attrs})"\
            .format(cls=self.__class__.__name__,
                    attrs=", ".join(["%s=%r" % (k, v) for k, v in info.items()]))


def get_process(pid: Union[str, int]) -> Union[Process, None]:
    pid = int(pid) if isinstance(pid, str) else pid
    process = Process(pid)
    logger.debug(process)
    return process


def get_children(parent: Process) -> List[Process]:
    children = []
    if parent is not None and parent.is_running():
        children = parent.children(recursive=True)
    return children


def send_signal(process: Process, sig: int):
    if process is not None and process.is_running():
        logger.info("{process} is about to be killed with signal {sig}"
                    .format(process=process, sig=sig))
        process.send_signal(sig)
    else:
        logger.debug("Process {} wasn't found. Already killed".format(process))


def kill_child_processes(parent_pid: str, sig=signal.SIGTERM):
    """Kills all children for a given parent pid

    Args:
      parent_pid: pid of the parent
      sig: signal to send
    """
    parent = get_process(parent_pid)
    children = get_children(parent)
    kill_processes(children, sig)


def kill_processes(processes: List[Process], sig):
    for process in processes:
        send_signal(process, sig)
    _, alive = psutil.wait_procs(processes, timeout=5)  # type: List[psutil.Process], List[psutil.Process]
    for process in alive:
        if process.is_running():
            logger.error(f"{Process.__str__(cast(Process, process))} is still running.")


def kill_process(pid: Union[str, int], sig=signal.SIGTERM):
    process = get_process(pid)
    if process is not None:
        send_signal(process, sig)


def get_children_processes(pid=os.getpid()) -> List[Process]:
    parent = None
    try:
        parent = get_process(pid)
        children = get_children(parent)
        if len(children) > 0:
            logger.info("Children processes of {}:\n{}".format(parent, pprint.pformat(children)))
    except Exception as ex:
        logger.exception("unexpected exception occurred while getting children of process {process}."
                         .format(process=parent),
                         exc_info=ex)
        return []
    return children


def get_processes(process_name: List[str]) -> List[Process]:
    if process_name is None:
        return []
    all_processes_found_by_name = []
    process_name = " ".join(process_name)
    for process in psutil.process_iter(attrs=["name", "cmdline"]):
        info = process.info
        if process_name in " ".join([info["name"]] + info["cmdline"] if info["cmdline"] is not None else []):
            all_processes_found_by_name.append(process)
    current_process_children = get_children_processes()
    pids_intersection_without_duplicates = set(current_process_children) & set(all_processes_found_by_name)
    return list(pids_intersection_without_duplicates) if len(pids_intersection_without_duplicates) >= 1 else []


def get_pids(process_name: List[str]) -> List[int]:
    return [process.pid for process in get_processes(process_name)]


class ProcessManager:

    def __init__(self):
        self._proc = None
        self._std_stream = None
        self._err_stream = None

    def async_run(self, cmd, cwd=None, timeout=600):
        logger.debug(f'Executing cmd: {cmd} (timeout: {timeout})')
        cmd_mode = []
        if cwd:
            cmd = f"cd {cwd} && {cmd}"
        cmd_mode += ['bash', '-c', cmd]

        self._proc = Popen(cmd_mode,
                           stdout=PIPE,
                           stderr=PIPE,
                           stdin=DEVNULL)

        self._err_stream = StreamReaderThread(self._proc.stderr)
        self._std_stream = StreamReaderThread(self._proc.stdout)
        self._err_stream.run()
        self._std_stream.run()

    def run(self, cmd, cwd=None, timeout=600):
        self.async_run(cmd, cwd=cwd, timeout=timeout)
        return self._wait_for_output(timeout)

    def run_and_check(self, cmd, cwd=None, timeout=600):
        code, _stdout, stderr = self.run(cmd, cwd=cwd, timeout=timeout)
        return self._check_output(code, _stdout, stderr, cmd)

    def get_output(self):
        return self._std_stream.pop(), self._err_stream.pop()

    def wait(self, timeout):
        try:
            self._proc.wait(timeout)
            self._std_stream.wait_thread_end(timeout)
        except TimeoutExpired:
            self._std_stream.timeout_detected = True

    def is_alive(self):
        return self._proc.poll() is None

    def timeout_detected(self):
        return self._std_stream.timeout_detected or self._err_stream.timeout_detected

    def _check_output(self, code, _stdout, stderr, cmd):
        assert code == 0, f'Unexpected return code detected during executing cmd: {cmd} (code: {code}; stderr: '\
                          f'{stderr})!'
        assert not stderr, f'Detect non empty stderr during executing cmd: {cmd} (stderr: {stderr})!'
        return _stdout

    def _wait_for_output(self, timeout):
        self.wait(timeout)
        _stdout, stderr = self.get_output()
        return self.get_exitcode(), _stdout, stderr

    def cleanup(self):
        self._proc.terminate()

    def _kill(self, pid, force=False):
        cmd = f'kill -9 {pid}' if force else f'kill {pid}'
        logger.warning(f'Killing process {pid}!')
        check_call(cmd.split())

        i = 0
        cmd = 'ps --pid {}'.format(pid)
        tmp_return = call(cmd.split())
        while tmp_return == 0:
            sleep(5)
            i += 1
            if i > 12:
                break
            tmp_return = call(cmd.split())

    def kill(self, force=False):
        if not self._proc:
            return None

        logger.warning(f'Killing process {self._proc.pid} (force: {force})!')
        parent_proc = psutil.Process(self._proc.pid)
        child_processes = parent_proc.children()
        for child_proc in child_processes:
            child_proc.terminate()
        _, alive = psutil.wait_procs(child_processes,
                                     timeout=3,
                                     callback=lambda proc: f'Process {proc} exit code: {proc.returncode}')
        for proc in alive:
            proc.kill()

        if self.is_alive():
            self._kill(self._proc.pid, force)

        return not self.is_alive()

    def get_exitcode(self):
        result = self._proc.returncode
        if self.is_alive() and self._std_stream.timeout_detected:
            self.kill()
            sleep(5)
            if self.is_alive():
                self.kill(force=True)
                logger.warning(f'Timeout detected ({self.__class__.__name__})...')
                result = TIMEOUT_CODE
            else:
                result = self._proc.returncode
        return result


class StreamReaderThread:
    def __init__(self, stream, local_thread=True):
        self._queue = Queue()
        self._thread = None
        self._stream = stream
        self.timeout_detected = False
        self._local_thread = local_thread

    def run(self):
        self._thread = Thread(target=self._enqueue_output, args=(self._stream, ))
        self._thread.daemon = True
        self._thread.start()

    def _enqueue_output(self, out):
        try:
            for line in iter(out.readline, b'' if self._local_thread else ''):
                self._queue.put(line.decode('ascii', 'ignore') if self._local_thread else line)
        except:
            self.timeout_detected = True

    def pop(self):
        result = ""
        while not self._queue.empty():
            result += self._queue.get_nowait()
        return result

    def wait_thread_end(self, timeout=None):
        self._thread.join(timeout)
