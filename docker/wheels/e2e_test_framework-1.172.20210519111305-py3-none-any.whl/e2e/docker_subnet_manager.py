#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
from docker import DockerClient
from docker.errors import APIError


class DockerSubnetManager:
    def __init__(self, subnet_pool: int = None):
        assert subnet_pool > 0, f"Not expected subnet_range size given for manager {subnet_pool}, should be > 0."
        assert subnet_pool <= 255, f"Not expected subnet_range size given for manager {subnet_pool}, should be <= 255."
        self.range = subnet_pool
        self.allowed_subnet = self.define_range_of_allowed_subnets()
        self.reserved_subnet = self.docker_reserved_subnet_list()

    def define_range_of_allowed_subnets(self):
        return [f"172.28.{subnet_pool}.0/24" for subnet_pool in range(self.range)]

    def docker_reserved_subnet_list(self):
        client = DockerClient()
        network_list = client.networks.list()
        self.reserved_subnet = []
        for network in network_list:
            if not network.attrs["IPAM"]["Config"]:
                continue
            else:
                self.reserved_subnet.append(network.attrs["IPAM"]["Config"][0]["Subnet"])
        return self.reserved_subnet

    def get_subnet(self):
        fresh_reserved_list = self.docker_reserved_subnet_list()
        for subnet in self.allowed_subnet[:]:
            if subnet not in fresh_reserved_list:
                generated_subnet = self.reserve_subnet(subnet=subnet)
                return generated_subnet
            else:
                try:
                    subnet = next(subnet for subnet in self.allowed_subnet if subnet not in fresh_reserved_list)
                    generated_subnet = self.reserve_subnet(subnet=subnet)
                    return generated_subnet
                except StopIteration:
                    raise Exception(f"Subnet pool {self.range} has been used up. "
                                    f"Consider release subnet or increase pool size.")
        else:
            raise Exception(f"Allowed subnet list empty: {self.allowed_subnet}")

    def reserve_subnet(self, subnet):
        if subnet in self.reserved_subnet:
            self.allowed_subnet.remove(subnet)
            try:
                subnet = next(subnet for subnet in self.allowed_subnet if subnet not in self.reserved_subnet)
            except StopIteration:
                raise Exception(f"Subnet pool {self.range} has been used up. "
                                f"Consider release subnet or increase pool size.")
            self.reserved_subnet.append(subnet)
            self.allowed_subnet.remove(subnet)
            return subnet
        self.reserved_subnet.append(subnet)
        self.allowed_subnet.remove(subnet)
        return subnet

    def release_subnet(self, subnet):
        if subnet in self.reserved_subnet:
            self.allowed_subnet.remove(subnet)
            try:
                client = DockerClient()
                network_list = client.networks.list()
                for network in network_list:
                    if not network.attrs["IPAM"]["Config"]:
                        continue
                    if network.attrs["IPAM"]["Config"][0]["Subnet"] == subnet:
                        client.api.remove_network(network.short_id)
                        self.reserved_subnet.remove(subnet)
            except APIError:
                raise Exception(f"Error while removing network: {subnet}, network is in use and has active endpoints ")
            self.allowed_subnet.append(subnet)
        else:
            raise Exception(f"Subnet {subnet} not in reserved subnet list:{self.reserved_subnet},"
                            f" choose another subnet to release")
