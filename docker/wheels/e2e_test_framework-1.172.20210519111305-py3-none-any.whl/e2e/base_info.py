#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
"""Implementation that stores basic details about environment"""

from e2e.current_os_info import CurrentOsInfo
from e2e.environment_info import DEFAULT_FULL_VERSION_NUMBER
from e2e.logger import get_logger

logger = get_logger(__name__)


class BaseInfo:
    """Retrieves environment info"""
    glob_version = None
    glob_install_package_name = None
    glob_scm_repository_state = None
    glob_os_distname = None

    @property
    def version(self):
        """Retrieves version, but only once.

        If retrieval doesn't work, default version is returned.
        """
        if self.glob_version is None:

            self.glob_version = self.get()
            self.glob_version = \
                self.glob_version["version"]

        return self.glob_version

    @property
    def install_package_name(self):
        """Retrieves install package name, but only once.

        If retrieval doesn't work, default install package name is returned.
        """
        if self.glob_install_package_name is None:
            self.glob_install_package_name = self.get()
            self.glob_install_package_name = \
                self.glob_install_package_name["install_package_name"]

        return self.glob_install_package_name

    @property
    def scm_repository_state(self):
        """Retrieves scm repository state, but only once.

        If retrieval doesn't work, default scm repository state is returned.
        """
        if self.glob_scm_repository_state is None:
            self.glob_scm_repository_state = self.get()
            self.glob_scm_repository_state = \
                self.glob_scm_repository_state["scm_repository_state"]

        return self.glob_scm_repository_state

    @property
    def os_distname(self):
        """Retrieves os distname, but only once."""
        if self.glob_os_distname is None:
            self.glob_os_distname = CurrentOsInfo.get_os_distname()

        return self.glob_os_distname

    @classmethod
    def get(cls):
        """
        Returns constant environment info.
        """
        logger.info("BASIC INFO WITHOUT ANY API CALL")
        return {"version": DEFAULT_FULL_VERSION_NUMBER}
