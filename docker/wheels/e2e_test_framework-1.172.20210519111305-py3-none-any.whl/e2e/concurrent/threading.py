# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import threading
from logging import Logger
from typing import Callable, Union

from e2e.logger import get_logger

logger = get_logger(__name__)


class StoppingEvent(threading.Event):
    """Event with added cleanup method to be set on context cleanup"""

    def __init__(self, th_logger: Logger = logger):
        super().__init__()
        self.logger = th_logger

    def cleanup(self):
        if not self.is_set():
            self.set()

    def set(self):
        self.logger.info("Stopping event was set.")
        super().set()


class Timer(threading.Timer):
    def __init__(self, name,
                 interval: float = None,
                 fn: Callable = None,
                 stopping_event: StoppingEvent = None,
                 *args, **kwargs) -> None:
        self.args = None
        self.interval = None
        self.function = None
        self.stopping_event = stopping_event
        super().__init__(interval, fn, args, kwargs)
        self.name = name

    def set_interval(self, interval: float):
        self.interval = interval
        return self

    def set_function(self, fn: Callable):
        self.function = fn
        return self

    def set_args(self, *args):
        self.args = args

    def set_stopping_event(self, stopping_event: StoppingEvent):
        self.stopping_event = stopping_event
        return self

    def __call__(self, *args, **kwargs):
        return self.function(*args, **kwargs)


class Periodic(object):
    """
    A periodic task running in threading.Timers
    src: https://stackoverflow.com/a/18906292
    """

    def __init__(self, name,
                 interval: float = None,
                 fn: Callable = None,
                 stopping_event: StoppingEvent = None,
                 th_logger: Logger = logger,
                 *args, **kwargs):
        self.name = name
        self._lock = threading.Lock()
        self._timer = None  # type: Union[threading.Timer, None]
        self.function = fn
        self.interval = interval
        self.stopping_event = stopping_event
        self.logger = th_logger
        self.args = args
        self.kwargs = kwargs
        self._stopped = True

    def __call__(self, *args, **kwargs):
        return self.function(*args, **kwargs)

    def set_interval(self, interval):
        self.interval = interval
        return self

    def set_function(self, fn):
        self.function = fn
        return self

    def set_logger(self, th_logger):
        self.logger = th_logger
        return self

    def set_stopping_event(self, stopping_event: StoppingEvent):
        self.stopping_event = stopping_event
        return self

    def start(self, from_run=False):
        self._lock.acquire()
        if from_run or self._stopped:
            self._stopped = False
            self._timer = threading.Timer(self.interval, self._run)
            self._timer.name = self.name
            self._timer.start()
            self._lock.release()

    def _run(self):
        try:
            self.function(*self.args, **self.kwargs)
        except Exception as ex:
            self.logger.exception(ex)
            raise ex
        if self.stopping_event is not None and self.stopping_event.is_set():
            self.stop()
        else:
            self.start(from_run=True)

    def stop(self):
        self._lock.acquire()
        self.logger.info("Stopping periodic execution.")
        self._stopped = True
        if self._timer is not None:
            self._timer.cancel()
            self._timer.join(10)
        self._lock.release()

    @property
    def stopped(self):
        return self._stopped
