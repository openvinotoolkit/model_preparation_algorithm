#
# Copyright (c) 2018-2020 Intel Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

import json
from os.path import join as urljoin
from http import HTTPStatus

import numpy as np
from google.protobuf.json_format import Parse
from tensorflow_serving.apis import get_model_metadata_pb2, get_model_status_pb2

from e2e.assertions import assert_raises_http_exception
from e2e.grpc_client.inference import InferenceClient, logger
from e2e.http_client import HttpClientFactory, HttpMethod
from e2e.http_client.configuration_provider.no_auth import NoAuthConfigurationProvider
from e2e.http_client.configuration_provider.ssl_auth import SslAuthConfigurationProvider
from e2e.ssl_certificates import SslCertificates

REST = "rest"


class RestClient:
    METADATA = "metadata"
    MODELS = "models"
    PREDICT = ":predict"
    PROTOCOL = "http://"
    PROTOCOL_SSL = "https://"
    REST_VERSION = "v1"
    STATUS = "status"
    VERSIONS = "versions"

    def __init__(self, url: str, ssl_certificates: SslCertificates = None) -> None:
        super().__init__()

        if ssl_certificates is None:
            assert self.PROTOCOL_SSL not in url, "Using https protocol without ssl certificates not allowed. " \
                f"Provided url invalid: {url}"
            url = self.PROTOCOL + url if self.PROTOCOL not in url else url
            self.client = HttpClientFactory.get(NoAuthConfigurationProvider.get(url=url, proxies={}))

        if ssl_certificates is not None:
            assert self.PROTOCOL not in url, "Using http protocol with ssl certificates not allowed. " \
                f"Provided url invalid: {url}"
            url = self.PROTOCOL_SSL + url if self.PROTOCOL_SSL not in url else url
            cert = (ssl_certificates.get_https_cert())
            self.client = HttpClientFactory.get(SslAuthConfigurationProvider.get(url=url, cert=cert, proxies={}))

    def model_metadata(self, model_name: str, version: int = None, raw_response=True):
        rest_path = [self.REST_VERSION, self.MODELS, model_name]
        if version is not None:
            rest_path.append(self.VERSIONS)
            rest_path.append(str(version))
        rest_path.append(self.METADATA)
        return self.client.request(HttpMethod.GET, urljoin(*rest_path), raw_response=raw_response)

    def model_status(self, model_name: str, version: int = None, raw_response=True):
        rest_path = [self.REST_VERSION, self.MODELS, model_name]
        if version is not None:
            rest_path.append(self.VERSIONS)
            rest_path.append(str(version))
        return self.client.request(HttpMethod.GET, urljoin(*rest_path), raw_response=raw_response)

    def model_predict(self, model_name: str, json_data, version: int = None, timeout=900):
        rest_path = [self.REST_VERSION, self.MODELS, model_name]
        if version is not None:
            rest_path.append(self.VERSIONS)
            rest_path.append(str(version))
        return self.client.request(HttpMethod.POST, "".join([urljoin(*rest_path), self.PREDICT]),
                                   data=json_data, timeout=timeout, raw_response=True)


class InferenceRestClientTFS(InferenceClient):
    type = REST
    NOT_FOUND = HTTPStatus.NOT_FOUND
    INVALID_ARGUMENT = HTTPStatus.BAD_REQUEST
    INTERNAL = HTTPStatus.INTERNAL_SERVER_ERROR
    FAILED_PRECONDITION = HTTPStatus.PRECONDITION_FAILED
    UNAVAILABLE = HTTPStatus.SERVICE_UNAVAILABLE
    ALREADY_EXISTS = HTTPStatus.CONFLICT
    RESOURCE_EXHAUSTED = HTTPStatus.REQUEST_ENTITY_TOO_LARGE

    @staticmethod
    def assert_raises_exception(status, error_message_phrase, callable_obj, *args, **kwargs):
        return assert_raises_http_exception(status, error_message_phrase, callable_obj, *args, **kwargs)

    def __init__(self, address: str, port: str, model_name: str, batch_size: str, input_data_types: dict = None,
                 input_names: list = None, output_names: list = None, output_data_types: dict = None,
                 model_version: str = None, model_meta_from_serving: bool = True,
                 ssl_certificates: SslCertificates = None):
        super().__init__(address, port, model_name, batch_size, input_data_types, input_names, output_names,
                         output_data_types, model_version, model_meta_from_serving, ssl_certificates)
        self.client = None

    def create_inference(self):
        self.client = RestClient(self.url, self.ssl_certificates)
        self.prediction_service = self.client
        self.model_service = self.client
        if self.model_meta_from_serving:
            self.get_model_meta()
        return None

    def prepare_request(self, input_objects: dict):
        data_json = self.prepare_body_format(input_objects=input_objects)
        return data_json

    def prepare_stateful_request(self, input_objects: dict, sequence_ctrl=None, sequence_id=None):
        data_obj = InferenceRestClientTFS.prepare_body_dict(input_objects, request_format='column_name')
        if sequence_ctrl is not None:
            data_obj['inputs']['sequence_control_input'] = [sequence_ctrl]
        if sequence_id is not None:
            data_obj['inputs']['sequence_id'] = [sequence_id]
        return json.dumps(data_obj)

    @staticmethod
    def prepare_body_dict(input_objects: dict, request_format="row_name"):
        signature = "serving_default"
        data_obj = {}
        if request_format == "row_name":
            instances = []
            for input_name, input_object in input_objects.items():
                for i in range(0, input_object.shape[0], 1):
                    instances.append({input_name: input_object[i].tolist()})
            data_obj = {"signature_name": signature, "instances": instances}
        elif request_format == "row_noname":
            instances = []
            for input_object in input_objects.values():
                instances.append(input_object.tolist())
            data_obj = {"signature_name": signature, 'instances': instances}
        elif request_format == "column_name":
            inputs = dict()
            for input_name, input_object in input_objects.items():
                inputs[input_name] = input_object.tolist()
            data_obj = {"signature_name": signature, 'inputs': inputs}
        elif request_format == "column_noname":
            inputs = []
            for input_object in input_objects.values():
                inputs.append(input_object.tolist())
            data_obj = {"signature_name": signature, 'inputs': inputs}
        else:
            raise ValueError("Unknown response format: {}".format(request_format))
        return data_obj

    @staticmethod
    def prepare_body_format(input_objects: dict, request_format="row_name"):
        data_obj = InferenceRestClientTFS.prepare_body_dict(input_objects, request_format)
        data_json = json.dumps(data_obj)
        return data_json

    def process_json_output(self, result_dict):
        output = {}
        if "outputs" in result_dict:
            key_name = "outputs"
            if type(result_dict[key_name]) is dict:
                for output_tensor in self.output_names:
                    output[output_tensor] = np.asarray(result_dict[key_name][output_tensor])
            else:
                output[self.output_names[0]] = np.asarray(result_dict[key_name])
        elif "predictions" in result_dict:
            key_name = "predictions"
            if type(result_dict[key_name][0]) is dict:
                for row in result_dict[key_name]:
                    for output_tensor in self.output_names:
                        if output_tensor not in output:
                            output[output_tensor] = []
                        output[output_tensor].append(row[output_tensor])
                for output_tensor in self.output_names:
                    output[output_tensor] = np.asarray(output[output_tensor])
            else:
                output[self.output_names[0]] = np.asarray(result_dict[key_name])
        else:
            logger.error("Missing required response in {}".format(result_dict))
        return output

    def get_model_meta(self):
        result = self.client.model_metadata(self.model_name, version=self.model_version, raw_response=True)
        output_json = result.text
        metadata_pb = get_model_metadata_pb2.GetModelMetadataResponse()
        response = Parse(output_json, metadata_pb, ignore_unknown_fields=False)

        signature_def = response.metadata['signature_def']
        signature_map = get_model_metadata_pb2.SignatureDefMap()
        signature_map.ParseFromString(signature_def.value)
        serving_default = signature_map.ListFields()[0][1]['serving_default']
        serving_inputs = serving_default.inputs
        serving_outputs = serving_default.outputs

        if self.input_names is None:
            self.input_names = [key for key in serving_inputs.keys()]
        if self.output_names is None:
            self.output_names = [key for key in serving_outputs.keys()]

        self.input_dims = dict()
        self.input_data_types = dict()
        self.output_dims = dict()
        self.output_data_types = dict()

        for input_name in self.input_names:
            serving_input = serving_inputs[input_name]
            input_tensor_shape = serving_input.tensor_shape
            self.input_dims[input_name] = [d.size for d in input_tensor_shape.dim]
            self.input_data_types[input_name] = self.get_data_type(serving_input.dtype)

        for output_name in self.output_names:
            serving_output = serving_outputs[output_name]
            output_tensor_shape = serving_output.tensor_shape
            self.output_dims[output_name] = [d.size for d in output_tensor_shape.dim]
            self.output_data_types[output_name] = self.get_data_type(serving_output.dtype)
        return response

    def get_model_status(self):
        result = self.client.model_status(self.model_name, version=self.model_version, raw_response=True)
        output_json = result.text
        status_pb = get_model_status_pb2.GetModelStatusResponse()
        response = Parse(output_json, status_pb, ignore_unknown_fields=False)
        return response

    def predict(self, request, timeout=900):
        result = self.prediction_service.model_predict(self.model_name, request, version=self.model_version, timeout=timeout)
        output_json = json.loads(result.text)
        outputs = self.process_json_output(output_json)
        return outputs

    def predict_stateful_request(self, request, timeout=900):
        result = self.prediction_service.model_predict(self.model_name, request, version=self.model_version,
                                                       timeout=timeout)
        output_json = json.loads(result.text)
        sequence_id = output_json['outputs'].pop('sequence_id')[0] if 'outputs' in output_json else None
        outputs = self.process_json_output(output_json)
        return sequence_id, outputs
