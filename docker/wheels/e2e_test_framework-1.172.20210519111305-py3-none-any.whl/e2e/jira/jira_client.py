#
# INTEL CONFIDENTIAL
# Copyright (c) 2021 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
from jira import JIRA, Issue
from jira.resources import IssueType
from typing import List, Dict

from e2e import config as e2e_config
from e2e.helpers import SingletonMeta, SingletonABCMeta


class JiraClient(JIRA, metaclass=SingletonMeta):

    JIRA_SERVER_CONFIG = {
        "server": e2e_config.jira_server,
        "verify": False
    }
    JIRA_SERVER_AUTH = (e2e_config.jira_user,
                        e2e_config.jira_pass)

    JIRA_PROJECT_KEY = e2e_config.jira_project_key

    def __init__(self, server=None, options=None, basic_auth=None, oauth=None, jwt=None,
                 kerberos=False, kerberos_options=None, validate=False, get_server_info=True,
                 async_=False, async_workers=5, logging=True, max_retries=3, proxies=None,
                 timeout=None, auth=None):
        options = self.JIRA_SERVER_CONFIG if options is None else options
        auth = self.JIRA_SERVER_AUTH if auth is None else auth
        super().__init__(server, options, basic_auth, oauth, jwt, kerberos, kerberos_options,
                         validate, get_server_info, async_, async_workers, logging, max_retries,
                         proxies, timeout, auth)

    def field_by_name(self, name):
        """returns issue field filtered by its name"""
        fields = self.fields()
        field = next(filter(lambda fld: fld.get("name") == name, fields), None)
        if field is None:
            raise KeyError("Field '%s' is unknown." % name)
        return field


class JiraIssue(JiraClient, metaclass=SingletonABCMeta):
    ISSUE_TYPE_NAME = NotImplemented

    def __init__(self, server=None, options=None, basic_auth=None, oauth=None, jwt=None,
                 kerberos=False, kerberos_options=None, validate=False, get_server_info=True,
                 async_=False, async_workers=5, logging=True, max_retries=3, proxies=None,
                 timeout=None, auth=None):
        self._issue_types_meta = None
        self._issue_type = None
        self._issue_type_meta = None
        self._required_issue_type_fields = None
        self._projects_meta = None
        super().__init__(server, options, basic_auth, oauth, jwt, kerberos, kerberos_options,
                         validate, get_server_info, async_, async_workers, logging, max_retries,
                         proxies, timeout, auth)

    @property
    def type(self) -> IssueType:
        if self._issue_type is None:
            self._issue_type = self.issue_type_by_name(self.ISSUE_TYPE_NAME)
        return self._issue_type

    @property
    def projects_meta(self):
        if self._projects_meta is None:
            self._projects_meta = self.createmeta(
                projectKeys=self.JIRA_PROJECT_KEY,
                issuetypeIds=self.type.id,
                expand="projects.issuetypes.fields"
            )
        return self._projects_meta

    @property
    def curr_project_meta(self):
        project_filter = filter(lambda p: p.get("key", self.JIRA_PROJECT_KEY),
                                self.projects_meta.get("projects", []))
        curr_project = next(project_filter, None)
        return curr_project

    @property
    def issue_types_meta(self) -> List[Dict]:
        if self._issue_types_meta is None:
            self._issue_types_meta = self.curr_project_meta.get("issuetypes", [])
        return self._issue_types_meta

    @property
    def type_meta(self):
        if self._issue_type_meta is None:
            self._issue_type_meta = next(filter(
                lambda it: it.get("name") == self.type.name,
                self.issue_types_meta
            ), None)
        return self._issue_type_meta

    @property
    def issue_fields(self):
        """lists all issue fields"""
        return self.type_meta.get("fields", {})

    @property
    def required_issue_fields(self):
        """lists all required issue fields"""
        if self._required_issue_type_fields is None:
            self._required_issue_type_fields = {
                name: field
                for name, field in self.issue_fields.items()
                if field.get("required", False) is True
            }
        return self._required_issue_type_fields

    def allowed_values(self, field_name) -> List[Dict]:
        """returns list of allowed values for field name"""
        return self.issue_fields.get(field_name, {}).get("allowedValues", [])


class TaskFactory(JiraIssue):
    ISSUE_TYPE_NAME = "Task"

    def create(self, summary, description, **kwargs) -> Issue:

        task = self.create_issue(project=self.JIRA_PROJECT_KEY,
                                 summary=summary,
                                 description=description,
                                 issuetype=int(self.type.id),
                                 **kwargs)
        return task


class BugFactory(JiraIssue):
    ISSUE_TYPE_NAME = "Bug"

    def create(self, summary, description, components, versions, exposure, **kwargs) -> Issue:

        bug = self.create_issue(project=self.JIRA_PROJECT_KEY,
                                summary=summary,
                                description=description,
                                issuetype=self.ISSUE_TYPE_NAME,
                                components=components,
                                versions=versions,
                                customfield_13805=exposure,
                                **kwargs)
        return bug
