#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

from .http_session import HttpSession
from .client_auth_base import ClientAuthBase
from .client_auth_http_basic import ClientAuthHttpBasic
from .client_auth_session import ClientAuthSession
from .client_auth_token import ClientAuthToken
from .client_auth_token_no_auth import ClientAuthTokenProvided
from .client_auth_type import ClientAuthType
from .client_auth_no_auth import ClientAuthNoAuth
from .client_auth_ssl import ClientAuthSsl
from .client_auth_login_page import ClientAuthLoginPage


class ClientAuthFactory(object):
    """Client authentication factory."""

    EMPTY_URL = ""

    @staticmethod
    def get(username: str = None, password: str = None, auth_type: ClientAuthType = None,
            proxies: dict = None, cert: tuple = None, auth_url: str = EMPTY_URL, params: dict = None) -> ClientAuthBase:
        """Create client authentication for given type."""
        session = HttpSession(username, password, proxies, cert)

        if auth_type == ClientAuthType.TOKEN_AUTH:
            return ClientAuthToken(auth_url, session, params)

        elif auth_type == ClientAuthType.HTTP_SESSION:
            return ClientAuthSession(auth_url, session, params)

        elif auth_type == ClientAuthType.HTTP_BASIC:
            return ClientAuthHttpBasic(auth_url, session, params)

        elif auth_type == ClientAuthType.TOKEN_NO_AUTH:
            return ClientAuthTokenProvided(auth_url, session, params)

        elif auth_type == ClientAuthType.NO_AUTH:
            return ClientAuthNoAuth(auth_url, session)

        elif auth_type == ClientAuthType.SSL:
            return ClientAuthSsl(auth_url, session)

        elif auth_type == ClientAuthType.LOGIN_PAGE:
            return ClientAuthLoginPage(auth_url, session, params)

        else:
            raise ClientAuthFactoryInvalidAuthTypeException(auth_type)


class ClientAuthFactoryInvalidAuthTypeException(Exception):
    TEMPLATE = "Client authentication with type {} is not implemented."

    def __init__(self, message=None):
        super().__init__(self.TEMPLATE.format(message))
