#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
"""Authentication client related to token based operations."""

import time

from requests.auth import AuthBase

from .client_auth_base import ClientAuthBase
from .http_method import HttpMethod
from .http_session import HttpSession
from .http_session_auth import HTTPSessionAuth


class ClientAuthSession(ClientAuthBase):
    """Base class that all session based http client authentication implementations derive from."""
    DATA_OR_BODY = "body"
    request_headers = {"Content-Type": "application/json"}  # "Accept": "application/json"}
    session_life_time = 600

    def __init__(self, url: str, session: HttpSession, params: dict):
        self._session_id = None
        self._session_timestamp = None
        self._response = None
        super().__init__(url, session, params)

    @property
    def session_id(self) -> str:
        """session is the session retrieved from the response during authentication."""
        return self._session_id

    @property
    def authenticated(self) -> bool:
        """Check if current user is authenticated."""
        return self._session_id and not self._is_session_expired()

    def authenticate(self) -> AuthBase:
        """Use session credentials to authenticate."""
        self._response = self.session.request(**self.auth_request_params)
        self._set_session_id()
        self._http_auth = HTTPSessionAuth(self._session_id)
        return self._http_auth

    def _is_session_expired(self):
        """Check if token has been expired."""
        return time.time() - self._session_timestamp > self.session_life_time

    def _set_session_id(self):
        """Set token taken from token request response."""
        self._session_id = self._response.headers.get("Session", None)
        if self._session_id is None:
            raise ClientAuthSessionMissingResponseSessionHeaderException()
        self._session_timestamp = time.time()

    @property
    def auth_request_params(self) -> dict:
        """build request params"""
        request_params = super().auth_request_params
        request_params.update({
            'method': HttpMethod.POST,
            'raw_response': True,
            'log_message': "Retrieve session id.",
        })
        return request_params

    def parse_params(self, params: dict):
        self.session_life_time = params.get("session_life_time", 60 * 10)
        self.request_data_params = params.get("request_data", {})
        self.request_params = params.get("request_params", {})


class ClientAuthSessionMissingResponseSessionHeaderException(Exception):
    """Exception that is thrown when no session id is found in the response"""
    def __init__(self):
        super().__init__("Session header is missing in session request response.")
