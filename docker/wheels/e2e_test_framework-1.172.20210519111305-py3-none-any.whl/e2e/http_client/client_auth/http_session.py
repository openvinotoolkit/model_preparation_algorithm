#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
"""Wrapper for the Session class from the requests library."""

from abc import ABCMeta
import json

from requests import Session, Request, PreparedRequest, exceptions
from requests.adapters import HTTPAdapter
from retry import retry

from e2e import config
from e2e.exceptions import UnexpectedResponseError
from e2e.mongo_reporter.request_reporter import log_request
from e2e.logger import log_http_request, log_http_response
from .http_method import HttpMethod

POOL_SIZE = 100


class HttpSession(object, metaclass=ABCMeta):
    """HttpSession is wrapper for the Session class from the requests library.

    It stores the information about the username, password, possible proxies and certificates.
    It does not do any authentication per se.
    For ease of use it has a "request" method that prepares and performs the request.
    """
    def __init__(self, username: str = None, password: str = None,
                 proxies: dict = None, cert: tuple = None):
        self._username = username
        self._password = password
        self._session = Session()
        if proxies is not None:
            self._session.proxies = proxies
        elif config.http_proxy:
            self._session.proxies = {"http": "{}".format(config.http_proxy),
                                     "https": "{}".format(config.https_proxy)}

        self._session.verify = config.ssl_validation
        if cert is not None:
            self._session.cert = cert
            try:
                self._session.verify = cert[2]
            except IndexError:
                pass

        adapter = HTTPAdapter(pool_connections=POOL_SIZE, pool_maxsize=POOL_SIZE)
        self._session.mount('http://', adapter)
        self._session.mount('https://', adapter)

    @property
    def username(self) -> str:
        """Session user name."""
        return self._username

    @property
    def password(self) -> str:
        """Session user password."""
        return self._password

    @property
    def cookies(self):
        """Session cookies."""
        return self._session.cookies

    def request(self, method: HttpMethod, url, path="", path_params=None,
                headers=None, files=None, data=None, params=None, auth=None,
                body=None, log_message="", raw_response=False, timeout=None,
                raise_exception=True, log_response_content=True):
        """Wrapper for the request method from the Session library"""
        path_params = {} if path_params is None else path_params
        url = '{}/{}'.format(url, path).format(**path_params)
        request = self._request_prepare(method, url, headers, files,
                                        data, params, auth, body, log_message)
        return self._request_perform(request, path, path_params, raw_response, timeout=timeout,
                                     raise_exception=raise_exception,
                                     log_response_content=log_response_content)

    def _request_prepare(self, method, url, headers, files, data, params, auth, body, log_message):
        """Prepare request to perform."""
        request = Request(method=method, url=url, headers=headers,
                          files=files, data=data, params=params,
                          auth=auth, json=body)

        prepared_request = self._session.prepare_request(request)
        log_http_request(prepared_request, self._username,
                         description=log_message, data=data)
        return prepared_request

    def _request_perform(self, request: PreparedRequest, path: str, path_params, raw_response: bool,
                         timeout: int, raise_exception: bool, log_response_content=True):
        """Perform request and return response."""
        response = self._send_request_and_get_raw_response(request, path,
                                                           path_params, timeout=timeout)
        if log_response_content:
            # workaround for downloading large files - reading response.text takes too long
            log_http_response(response)
        else:
            log_http_response(response, logged_body_length=0)

        if raise_exception and not response.ok and response.text.strip() != "session_expired":
            raise UnexpectedResponseError(response.status_code, response.text)

        if raw_response is True:
            return response

        try:
            return json.loads(response.text)
        except ValueError:
            return response.text

    @log_request
    @retry(exceptions=exceptions.ConnectionError, tries=2)
    def _send_request_and_get_raw_response(self, request: Request, timeout: int):
        return self._session.send(request, timeout=timeout)
