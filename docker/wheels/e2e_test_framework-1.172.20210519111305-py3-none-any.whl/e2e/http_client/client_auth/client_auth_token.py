#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
"""Authentication client related to token based operations."""
import time

from requests.auth import AuthBase

from .client_auth_base import ClientAuthBase
from .http_session import HttpSession
from .http_token_auth import HTTPTokenAuth


class ClientAuthToken(ClientAuthBase):
    """Base class that all token based http client authentication implementations derive from."""
    request_headers = {"Accept": "application/json"}
    token_life_time = None
    token_name = None
    token_header_format = "Bearer {}"

    def __init__(self, url: str, session: HttpSession, params: dict = None):
        self._token = None
        self._token_header = None
        self._token_timestamp = None
        self._response = None
        super().__init__(url, session, params)

    @property
    def token(self) -> str:
        """token is the token retrieved from the response during authentication."""
        return self._token

    @property
    def authenticated(self) -> bool:
        """Check if current user is authenticated."""
        return self._token and not self._is_token_expired()

    def authenticate(self) -> AuthBase:
        """Use session credentials to authenticate."""
        self._response = self.session.request(**self.auth_request_params)
        self._set_token()
        self._http_auth = HTTPTokenAuth(self._token_header)
        return self._http_auth

    def _is_token_expired(self):
        """Check if token has been expired."""
        return time.time() - self._token_timestamp > self.token_life_time

    def _set_token(self):
        """Set token taken from token request response."""
        if self.token_name not in self._response:
            raise ClientAuthTokenMissingResponseTokenKeyException()
        self._token_timestamp = time.time()
        self._token = self._response[self.token_name]
        self._token_header = self.token_header_format.format(self._token)

    def parse_params(self, params: dict):
        self.token_name = params.get("token_name", "access_token")  # config.api_token_name
        self.token_life_time = params.get("token_life_time", 298)  # 60 * 60 * 24
        self.request_data_params = params.get("request_data", {})
        self.request_params = params.get("request_params", {})

    @property
    def auth_request_params(self) -> dict:
        """build request params"""
        request_params = super().auth_request_params
        request_params.update(self.request_params)
        return request_params

    @property
    def request_data(self) -> dict:
        """Token request data."""
        request_data = super().request_data
        request_data.update(self.request_data_params)
        return request_data


class ClientAuthTokenMissingResponseTokenKeyException(Exception):
    """Exception that is thrown when no token is found in the response"""
    def __init__(self):
        super().__init__("Token key is missing in token request response.")
