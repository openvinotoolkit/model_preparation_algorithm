#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
"""Wrapper for the HttpSession class that performs automatic autentication."""

from abc import ABCMeta, abstractmethod
from collections import OrderedDict

from requests.auth import AuthBase

from .http_session import HttpSession


class ClientAuthBase(object, metaclass=ABCMeta):
    """Base class that all http client authentication implementations derive from.

    It performs automatic authentication.
    """
    DATA_OR_BODY = "data"
    _http_auth = None
    request_headers = None
    request_data_params = None
    request_params = None

    def __init__(self, url: str, session: HttpSession, params: dict = None):
        """
        Args:
            url: url
            session: http session
            params: additional params
        """
        self._url = url  # type: str
        self.session = session  # type: HttpSession
        self.parse_params(params if params is not None else {})
        self._http_auth = self.authenticate()  # type: AuthBase

    @property
    def http_auth(self) -> AuthBase:
        """Http authentication method."""
        return self._http_auth

    @property
    @abstractmethod
    def authenticated(self) -> bool:
        """Is current user already authenticated."""

    @abstractmethod
    def authenticate(self) -> AuthBase:
        """Use session credentials to authenticate."""

    @property
    def request_data(self) -> OrderedDict:
        """Token request data."""
        return OrderedDict([
            ("username", self.session.username),
            ("password", self.session.password),
        ])

    def parse_params(self, params: dict) -> None:
        """params parser to pass configuration customizations"""
        pass

    @property
    def auth_request_params(self) -> dict:
        """build request params"""
        return {
            'url': self._url,
            'headers': self.request_headers,
            self.DATA_OR_BODY: self.request_data,
        }
