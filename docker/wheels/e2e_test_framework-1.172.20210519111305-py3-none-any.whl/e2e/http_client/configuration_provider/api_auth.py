#
# INTEL CONFIDENTIAL
# Copyright (c) 2021 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

import requests
from ..http_client_configuration import HttpClientConfiguration
from ..http_client_type import HttpClientType
from .base import BaseConfigurationProvider


class ApiConfigurationProvider(BaseConfigurationProvider):
    """Provide configuration for console http client."""
    CSRF_NAME = "_oauth2_proxy_csrf"
    PROXY_NAME = "_oauth2_proxy"
    NEXT_NAME = "next"
    state = {CSRF_NAME: None, PROXY_NAME: None}

    @classmethod
    def redirects(cls, response):
        """ Fetch csrf cookie"""
        if response.status_code in [302, 303]:
            location = response.next.url
            cls.state[cls.NEXT_NAME] = location
            redirected = requests.get(location, verify=False, allow_redirects=False)
            proxy_csrf = redirected.cookies.get(cls.CSRF_NAME, None)
            print(redirected.cookies.__dict__)
            if proxy_csrf:
                cls.state[cls.CSRF_NAME] = proxy_csrf
            cls.redirects(redirected)

    @classmethod
    def get(cls, username: str, password: str, url: str) -> HttpClientConfiguration:
        """Provide http client configuration."""

        r = requests.get(url, verify=False, allow_redirects=False)
        cls.redirects(r)
        auth_uri = cls.state[cls.NEXT_NAME]
        params = {cls.CSRF_NAME: cls.state[cls.CSRF_NAME]}

        return HttpClientConfiguration(
            client_type=HttpClientType.API,
            url=url,
            username=username,
            password=password,
            auth_uri=auth_uri,
            params=params
        )
