#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

import unittest
from typing import Type

from e2e.http_client.client_auth.client_auth_no_auth import ClientAuthNoAuth
from e2e.http_client.unittests.mock_http_session import MockHttpSession
from e2e.http_client.client_auth.client_auth_base import ClientAuthBase
from e2e.http_client.client_auth.client_auth_token import ClientAuthToken
from e2e.http_client.http_client import HttpClient
from e2e.http_client.http_client_configuration import HttpClientConfiguration
from e2e.http_client.http_client_factory import HttpClientFactory
from e2e.http_client.http_client_type import HttpClientType


class TestHttpClientFactory(MockHttpSession):
    """Unit: HttpClientFactory."""

    USERNAME = "username"
    PASSWORD = "password"
    URL = "api.test.platform.eu"

    def setUp(self):
        HttpClientFactory._INSTANCES = {}
        self.mock_http_session()
        super().setUp()

    def test_get_should_return_client_for_uaa(self):
        self._assertHttpClientInstance(HttpClientType.TOKEN_AUTH, ClientAuthToken)

    def test_get_should_return_client_for_service_tool(self):
        self._assertHttpClientInstance(HttpClientType.NO_AUTH, ClientAuthNoAuth)

    def test_get_should_create_only_one_instance(self):
        # given
        configuration = self._get_configuration(HttpClientType.BROKER)
        self.assertNotIn(configuration, HttpClientFactory._INSTANCES, "Invalid instance reference.")
        # when
        HttpClientFactory.get(configuration)
        HttpClientFactory.get(configuration)
        # then
        self.assertIn(configuration, HttpClientFactory._INSTANCES, "Missing instance reference.")
        self.assertEqual(1, len(HttpClientFactory._INSTANCES), "Invalid number of instances.")

    def test_get_should_return_new_instance_after_remove(self):
        # given
        configuration = self._get_configuration(HttpClientType.BROKER)
        self.assertNotIn(configuration, HttpClientFactory._INSTANCES, "Invalid instance reference.")
        client = HttpClientFactory.get(configuration)
        self.assertEqual(client._auth.session.username, self.USERNAME)
        self.assertEqual(client._auth.session.password, self.PASSWORD)
        # when
        HttpClientFactory.remove(configuration)
        new_configuration = self._get_configuration(HttpClientType.BROKER, self.URL, self.USERNAME, "new_password")
        new_client = HttpClientFactory.get(new_configuration)
        # then
        self.assertNotIn(configuration, HttpClientFactory._INSTANCES)
        self.assertIn(new_configuration, HttpClientFactory._INSTANCES)
        self.assertEqual(1, len(HttpClientFactory._INSTANCES), "Invalid number of instances.")
        self.assertEqual(new_client._auth.session.username, self.USERNAME)
        self.assertEqual(new_client._auth.session.password, "new_password")

    def test_get_should_create_two_different_instances(self):
        # given
        url_first = "first.sample.url"
        url_second = "second.sample.url"
        configuration_first = self._get_configuration(HttpClientType.BROKER, url_first)
        configuration_second = self._get_configuration(HttpClientType.BROKER, url_second)
        # when
        client_first = HttpClientFactory.get(configuration_first)
        client_second = HttpClientFactory.get(configuration_second)
        # then
        self.assertEqual(client_first.url, url_first)
        self.assertEqual(client_second.url, url_second)
        self.assertNotEqual(client_first.url, client_second.url)
        self.assertEqual(2, len(HttpClientFactory._INSTANCES), "Invalid number of instances.")

    def _assertHttpClientInstance(self, client_type, auth: Type[ClientAuthBase]):
        configuration = self._get_configuration(client_type)
        client = HttpClientFactory.get(configuration)
        self.assertIsInstance(client, HttpClient, "Invalid client class.")
        self.assertIsInstance(client._auth, auth, "Invalid auth class.")
        self.assertIn(configuration, HttpClientFactory._INSTANCES, "Missing instance reference.")

    @staticmethod
    def _get_configuration(client_type, url=URL, username=USERNAME, password=PASSWORD):
        return HttpClientConfiguration(client_type, url, username, password)


if __name__ == '__main__':
    unittest.main()
