#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

import json
import unittest
from unittest.mock import patch

from http import HTTPStatus
from requests import Session, Response

from e2e.exceptions import UnexpectedResponseError
from e2e.http_client.client_auth.http_method import HttpMethod
from e2e.http_client.client_auth.http_session import HttpSession


class TestHttpSession(unittest.TestCase):
    """Unit: HttpSession."""

    USERNAME = "username"
    PASSWORD = "password"
    PATH = "path"
    URL = "http://some"

    def setUp(self):
        self._create_http_session()
        super().setUp()

    def test_init(self):
        self.assertEqual(self.USERNAME, self.http_session.username)
        self.assertEqual(self.PASSWORD, self.http_session.password)
        self.assertIsInstance(self.http_session._session, Session, "Invalid session class.")

    @patch("requests.Session.send")
    def test_request_should_return_valid_response(self, mock_session_send_call):
        # given
        content = b'{"status":"ok"}'
        expected_response = json.loads(content.decode())
        response = Response()
        response.status_code = HTTPStatus.OK
        response._content = content
        mock_session_send_call.return_value = response
        # when
        response = self.http_session.request(HttpMethod.GET, self.URL, self.PATH)
        # then
        self.assertEqual(response, expected_response)

    @patch("requests.Session.send")
    def test_request_should_return_invalid_response(self, mock_session_send_call):
        # given
        response = Response()
        response.status_code = HTTPStatus.BAD_REQUEST
        mock_session_send_call.return_value = response
        # then
        self.assertRaises(UnexpectedResponseError, self.http_session.request, HttpMethod.GET, self.URL, self.PATH)

    def _create_http_session(self):
        self.http_session = HttpSession(
            self.USERNAME,
            self.PASSWORD
        )


if __name__ == '__main__':
    unittest.main()
