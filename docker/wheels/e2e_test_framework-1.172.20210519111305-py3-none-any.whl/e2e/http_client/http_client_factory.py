#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

from .http_client import HttpClient
from .http_client_type import HttpClientType
from .client_auth.client_auth_type import ClientAuthType
from .client_auth.client_auth_factory import ClientAuthFactory
from .http_client_configuration import HttpClientConfiguration


class HttpClientFactory(object):
    """Http client factory with implemented singleton behaviour for each generated client."""

    _INSTANCES = {}

    @classmethod
    def get(cls, configuration: HttpClientConfiguration) -> HttpClient:
        """Create http client for given configuration."""
        client_type = configuration.client_type

        if client_type == HttpClientType.TOKEN_AUTH:
            return cls._get_instance(configuration, ClientAuthType.TOKEN_AUTH)

        elif client_type == HttpClientType.SESSION_AUTH:
            return cls._get_instance(configuration, ClientAuthType.HTTP_SESSION)

        elif client_type == HttpClientType.NO_AUTH:
            return cls._get_instance(configuration, ClientAuthType.NO_AUTH)

        elif client_type == HttpClientType.K8S:
            return cls._get_instance(configuration, ClientAuthType.TOKEN_NO_AUTH)

        elif client_type == HttpClientType.BROKER:
            return cls._get_instance(configuration, ClientAuthType.HTTP_BASIC)

        elif client_type == HttpClientType.BASIC_AUTH:
            return cls._get_instance(configuration, ClientAuthType.HTTP_BASIC)

        elif client_type == HttpClientType.API:
            return cls._get_instance(configuration, ClientAuthType.LOGIN_PAGE)

        elif client_type == HttpClientType.SSL:
            return cls._get_instance(configuration, ClientAuthType.SSL)

        else:
            raise HttpClientFactoryInvalidClientTypeException(client_type)

    @classmethod
    def remove(cls, configuration: HttpClientConfiguration):
        """Remove client instance from cached instances."""
        if configuration in cls._INSTANCES:
            del cls._INSTANCES[configuration]

    @classmethod
    def _get_instance(cls, configuration: HttpClientConfiguration, auth_type):
        """Check if there is already created requested client type and return it otherwise create new instance."""
        if configuration in cls._INSTANCES:
            return cls._INSTANCES[configuration]
        return cls._create_instance(configuration, auth_type)

    @classmethod
    def _create_instance(cls, configuration: HttpClientConfiguration, auth_type):
        """Create new client instance."""
        auth = ClientAuthFactory.get(auth_type=auth_type, **configuration.as_dict)
        instance = HttpClient(configuration.url, auth)
        cls._INSTANCES[configuration] = instance
        return instance


class HttpClientFactoryInvalidClientTypeException(Exception):
    TEMPLATE = "Http client with type {} is not implemented."

    def __init__(self, message=None):
        super().__init__(self.TEMPLATE.format(message))
