#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
"""Basic class for ssh tunnels"""
import socket
import subprocess

from retry import retry

from e2e import config
from e2e.constants.framework_constants import LOCALHOST
from e2e.logger import get_logger
from e2e.process_utils import kill_child_processes
from .base_jump_tunnel import BaseJumpTunnel
from .jump_client import JumpClient


class SimpleJumpTunnel(BaseJumpTunnel):
    """Simple, non-nested jump tunnel"""
    _logger = get_logger(__name__)

    def __init__(self, jump_client: JumpClient):
        super().__init__(LOCALHOST, config.socks_proxy_port, jump_client)

    @property
    def _tunnel_command(self):
        return self.jump_client.ssh_command + ["-D", str(self.port), "-N"]

    def open(self):
        """Opens a tunnel"""
        self._logger.info("Open tunnel with '{}'".format(" ".join(self._tunnel_command)))
        self.process = subprocess.Popen(self._tunnel_command)
        try:
            self._logger.info("Wait until tunnel is established")
            self._check_tunnel_established()
        except Exception:
            self.close()
            raise

    def close(self):
        """Closes the tunnel. Kills all the subprocess children
        and the subprocess itself
        """
        self._logger.debug("Close simple jump tunnel")
        kill_child_processes(self.process.pid)
        self.process.kill()

    @retry((ConnectionRefusedError, TimeoutError), tries=20, delay=5)
    def _check_tunnel_established(self):
        sock = socket.create_connection((self.host, self.port))
        sock.close()
