#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
"""Wrapper for SimpleJumpTunnel"""

from e2e import config
from e2e.constants.framework_constants import LOCALHOST
from e2e.logger import get_logger
from .jump_client import JumpClient
from ._remote_process import RemoteProcess
from ._simple_jump_tunnel import SimpleJumpTunnel


class NestedJumpTunnel(SimpleJumpTunnel):
    """Implements multiple nested jump tunnels"""
    _logger = get_logger(__name__)
    _KEY_COPIED = False
    _DEFAULT_JUMP_PORT = 5555
    _PORT_OPTION = "-D"

    def __init__(self, jump_client: JumpClient):
        super().__init__(jump_client)
        self._username = config.host_os_user
        self._ssh_command = self.jump_client.ssh_command
        self._auth_options = self.jump_client.ssh_command.auth_options
        self.__jump_port = None
        self._remote_tunnel_command_no_port = \
            "ssh {} {} -N -D ".format(" ".join(self._auth_options), config.nested_tunnel_hostname)
        self._local_tunnel_command = None

    @property
    def jump_port(self):
        return self.__jump_port

    @property
    def _remote_tunnel_command(self):
        """
        Before remote tunnel command is built, available port on jumpbox is first established.
        """
        return self._remote_tunnel_command_no_port + str(self.__jump_port)

    @property
    def _tunnel_command(self):
        self._logger.warning("Kubernetes not available directly from jumpbox.")
        self._get_available_jump_port()
        self._local_tunnel_command = \
            ["-L", "{0}:{1}:{2}".format(self.port, LOCALHOST, self.__jump_port)]
        return self._ssh_command + self._local_tunnel_command + [self._remote_tunnel_command]

    def close(self):
        """
        First, close tunnel process started on jumpbox.
        Second, close tunnel process started locally.
        """
        self._logger.debug("Close ssh tunnel on jumpbox")
        tunnel_process_on_jump = self._find_tunnel_process_on_jump()
        if tunnel_process_on_jump is None:
            self._logger.warning("Tunnel process does not seem to exist on jumpbox")
        else:
            tunnel_process_on_jump.kill()
        super().close()

    @classmethod
    def _get_port_from_remote_tunnel_command(cls, actual_command):
        assert cls._PORT_OPTION in actual_command, \
                "Process command does not include '{}'".format(cls._PORT_OPTION)
        index = actual_command.index(cls._PORT_OPTION)
        try:
            port = actual_command[index:].split(" ")[1]
            return int(port, 10)
        except (ValueError, IndexError):
            raise ValueError("Did not find port in command '{}'".format(actual_command))

    def _get_available_jump_port(self):
        """
        Search for an available port on jumpbox - only on the first call.
        This method is suboptimal, it looks only for processes started by this class.
        We'll see if it works.
        """
        if self.__jump_port is None:
            jump_processes = RemoteProcess.get_list(ssh_client=self.jump_client)
            busy_ports = []
            for process in jump_processes:
                if self._remote_tunnel_command_no_port in process.command:
                    port = self._get_port_from_remote_tunnel_command(process.command)
                    self._logger.warning("Port {} on jumpbox is busy".format(port))
                    busy_ports.append(port)
            for port in range(self._DEFAULT_JUMP_PORT, self._DEFAULT_JUMP_PORT + 100):
                if port not in busy_ports:
                    self.__jump_port = port
                    break
        return self.__jump_port

    def _find_tunnel_process_on_jump(self):
        jump_processes = RemoteProcess.get_list(ssh_client=self.jump_client)
        for process in jump_processes:
            if self._remote_tunnel_command in process.command and self._username in process.user:
                return process
