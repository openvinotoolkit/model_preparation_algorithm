#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
from abc import ABCMeta, abstractmethod

from e2e.constants.framework_constants import LOCALHOST


class BaseJumpTunnel(metaclass=ABCMeta):
    ALLOCATED_PORTS = []

    def __init__(self, host: str = LOCALHOST, port: str = None, jump_client=None) -> None:
        self._host = host
        self._port = port
        self._jump_client = jump_client
        self._process = None

    @property
    def host(self):
        return self._host

    @property
    def port(self):
        return self._port

    @port.setter
    def port(self, port):
        if port is not None:
            self._port = port
            self.ALLOCATED_PORTS.append(port)

    @property
    def jump_client(self):
        return self._jump_client

    @property
    def process(self):
        return self._process

    @process.setter
    def process(self, tunnel):
        self._process = tunnel

    @process.deleter
    def process(self):
        if self.process is not None:
            if self.is_open:
                self.close()
        del self._process

    @abstractmethod
    def open(self):
        pass

    @property
    def is_open(self) -> bool:
        return self._process is not None

    @abstractmethod
    def close(self):
        pass

    @abstractmethod
    def _check_tunnel_established(self):
        pass

    def __del__(self):
        del self.process
        if self._port in self.ALLOCATED_PORTS:
            self.ALLOCATED_PORTS.remove(self.port)

    def __enter__(self):
        self.open()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
