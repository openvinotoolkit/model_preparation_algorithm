#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

from unittest import mock

import pytest

from e2e.ssh_lib._simple_jump_tunnel import SimpleJumpTunnel
from ._mocks import MockConfig


@mock.patch("e2e.ssh_lib.jump_client.config", MockConfig())
class TestSimpleJumpTunnel:
    CONFIG_MODULE = "e2e.ssh_lib._simple_jump_tunnel.config"
    CLIENT_GET_REPOSITORY = "e2e.ssh_lib.jump_client.AppSources.get_repository"
    JUMP_CLIENT_CLASS = "e2e.ssh_lib._simple_jump_tunnel.JumpClient"
    SSH_CONFIG_MODULE = "e2e.command_wrappers.ssh.config"
    SUBPROCESS_POPEN_CLASS = "e2e.ssh_lib._simple_jump_tunnel.subprocess.Popen"
    CHECK_TUNNEL_ESTABLISHED = "e2e.ssh_lib._simple_jump_tunnel.SimpleJumpTunnel._check_tunnel_established"
    CLOSE = "e2e.ssh_lib._simple_jump_tunnel.SimpleJumpTunnel.close"

    MOCK_SSH_COMMAND = ["mock", "ssh", "command"]

    def test_init(self):
        with mock.patch(self.CONFIG_MODULE, MockConfig()) as mock_config,\
                mock.patch(self.SSH_CONFIG_MODULE, MockConfig()):
            with mock.patch(self.JUMP_CLIENT_CLASS) as mock_client:
                mock_instance = mock_client.return_value
                mock_instance.ssh_command = self.MOCK_SSH_COMMAND
                jump_tunnel = SimpleJumpTunnel(mock_instance)

        assert jump_tunnel._port == mock_config.socks_proxy_port
        assert " ".join(mock_instance.ssh_command) in " ".join(jump_tunnel._tunnel_command)
        assert "-D {}".format(mock_config.socks_proxy_port) in " ".join(jump_tunnel._tunnel_command)
        assert jump_tunnel._process is None

    @pytest.fixture(scope="function")
    @mock.patch(CONFIG_MODULE, MockConfig())
    def jump_tunnel(self):
        with mock.patch(self.JUMP_CLIENT_CLASS) as mock_client:
            mock_instance = mock_client.return_value
            mock_instance.ssh_command = self.MOCK_SSH_COMMAND
            return SimpleJumpTunnel(mock_instance)

    @mock.patch(CHECK_TUNNEL_ESTABLISHED, mock.Mock())
    def test_open_success(self, jump_tunnel):
        class Popen:
            pid = None

            def kill(self):
                pass

        test_subprocess = Popen()
        with mock.patch(self.SUBPROCESS_POPEN_CLASS, mock.Mock(return_value=test_subprocess)):
            jump_tunnel.open()
        assert jump_tunnel._process == test_subprocess

    @mock.patch(SUBPROCESS_POPEN_CLASS, mock.Mock())
    @mock.patch(CHECK_TUNNEL_ESTABLISHED, mock.Mock(side_effect=Exception()))
    def test_open_exception(self, jump_tunnel):
        with mock.patch(self.CLOSE) as mock_close:
            with pytest.raises(Exception):
                jump_tunnel.open()
        assert mock_close.call_count == 1
