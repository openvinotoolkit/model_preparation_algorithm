#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
from unittest import mock

import pytest

from e2e.ssh_lib.jump_client import JumpClient
from ._mocks import MockConfig


class TestJumpClient:
    TEST_USERNAME = "test-username"
    JUMP_CLIENT_CONFIG_MODULE = "e2e.ssh_lib.jump_client.config"
    SSH_CONFIG_MODULE = "e2e.command_wrappers.ssh.config"
    SCP_CONFIG_MODULE = "e2e.command_wrappers.scp.config"
    HOST_DNS = "host"

    @pytest.fixture()
    def dummy_object(self):
        class Dummy:
            pass
        return Dummy()

    @pytest.mark.parametrize("verbose_ssh", (False, True), ids=("verbose_ssh=False", "verbose_ssh=True"))
    def test_init(self, verbose_ssh):
        MockConfig()
        with mock.patch(self.JUMP_CLIENT_CONFIG_MODULE, MockConfig(verbose_ssh=verbose_ssh)),\
                mock.patch(self.SSH_CONFIG_MODULE, MockConfig(verbose_ssh=verbose_ssh)),\
                mock.patch(self.SCP_CONFIG_MODULE, MockConfig(verbose_ssh=verbose_ssh)):
            test_client = JumpClient(remote_username=self.TEST_USERNAME,
                                     remote_host=self.HOST_DNS)

        print(test_client.ssh_command)
        print(test_client.scp_command)
        print(test_client.ssh_command.auth_options)
        print(test_client.scp_command.auth_options)
        assert TestJumpClient.TEST_USERNAME + "@" + self.HOST_DNS == test_client.ssh_command.user_at_host
        assert " ".join(test_client.ssh_command.auth_options) in " ".join(test_client.ssh_command)
        assert " ".join(test_client.scp_command.auth_options) in " ".join(test_client.scp_command)

        if verbose_ssh:
            assert "-vvv" in test_client.ssh_command
            assert "-v" in test_client.scp_command
        else:
            assert "-vvv" not in test_client.ssh_command
            assert "-v" not in test_client.scp_command
