#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

from unittest import mock

import pytest

from e2e.command_wrappers import Ssh
from e2e.ssh_lib._remote_process import RemoteProcess
from e2e.ssh_lib._nested_jump_tunnel import NestedJumpTunnel
from ._mocks import MockConfig


class MockProcess:
    def __init__(self, cmd, user):
        self.command = cmd
        self.user = user


@mock.patch("e2e.ssh_lib.jump_client.config", MockConfig())
class TestNestedJumpTunnel:
    CONFIG_MODULE = "e2e.ssh_lib._nested_jump_tunnel.config"
    BASE_CLASS_CONFIG_MODULE = "e2e.ssh_lib._simple_jump_tunnel.config"
    JUMP_CLIENT_CLASS = "e2e.ssh_lib._nested_jump_tunnel.JumpClient"
    SSH_CONFIG_MODULE = "e2e.command_wrappers.ssh.config"
    REMOTE_PROCESS_GET_LIST_METHOD = "e2e.ssh_lib._nested_jump_tunnel.RemoteProcess.get_list"
    REMOTE_TUNNEL_COMMAND_PROPERTY = "e2e.ssh_lib._nested_jump_tunnel.NestedJumpTunnel._remote_tunnel_command"
    SIMPLE_TUNNEL_CLOSE = "e2e.ssh_lib._simple_jump_tunnel.SimpleJumpTunnel.close"
    REMOTE_PROCESS_GET_AVAILABLE_PORT = "e2e.ssh_lib._nested_jump_tunnel.NestedJumpTunnel._get_available_jump_port"

    MOCK_SSH_COMMAND = Ssh(remote_username="mock", remote_host="command")
    MOCK_AUTH_OPTIONS = MOCK_SSH_COMMAND.auth_options

    @pytest.fixture(scope="function")
    def jump_tunnel(self):
        with mock.patch(self.CONFIG_MODULE, MockConfig()), \
                mock.patch(self.SSH_CONFIG_MODULE, MockConfig()),\
                mock.patch(self.JUMP_CLIENT_CLASS) as mock_client:
            mock_instance = mock_client.return_value
            mock_instance.ssh_command = self.MOCK_SSH_COMMAND
            mock_instance.auth_options = self.MOCK_AUTH_OPTIONS
            return NestedJumpTunnel(mock_instance)

    @pytest.fixture(scope="class")
    def mock_client(self):
        class Dummy:
            execute_ssh_command = None
        return Dummy

    def test_init(self):
        with mock.patch(self.CONFIG_MODULE, MockConfig()) as mock_config,\
                mock.patch(self.BASE_CLASS_CONFIG_MODULE, MockConfig()),\
                mock.patch(self.JUMP_CLIENT_CLASS) as mock_client,\
                mock.patch(self.SSH_CONFIG_MODULE):
            mock_instance = mock_client.return_value
            mock_instance.ssh_command = self.MOCK_SSH_COMMAND
            mock_instance.auth_options = self.MOCK_AUTH_OPTIONS
            jump_tunnel = NestedJumpTunnel(mock_instance)
        assert jump_tunnel._username == mock_config.host_os_user
        assert jump_tunnel._ssh_command == self.MOCK_SSH_COMMAND
        assert jump_tunnel._auth_options == self.MOCK_AUTH_OPTIONS
        assert jump_tunnel._port == mock_config.socks_proxy_port
        assert jump_tunnel._process is None
        assert jump_tunnel.jump_port is None

    def test_get_port_from_remote_tunnel_command(self):
        expected_port = 12345
        test_command = "ssh -D {} -N".format(expected_port)
        port = NestedJumpTunnel._get_port_from_remote_tunnel_command(test_command)
        assert port == expected_port

    @pytest.mark.parametrize("incorrect_command", ("", " ", "ssh 12345 -N"))
    def test_get_port_from_remote_tunnel_command_no_d_option(self, incorrect_command):
        with pytest.raises(AssertionError) as e:
            NestedJumpTunnel._get_port_from_remote_tunnel_command(incorrect_command)
        assert "Process command does not include" in str(e.value)

    @pytest.mark.parametrize("incorrect_command", ("-D abcde", "ssh 12345 -D"))
    def test_get_port_from_remote_tunnel_command_no_port(self, incorrect_command):
        with pytest.raises(ValueError) as e:
            NestedJumpTunnel._get_port_from_remote_tunnel_command(incorrect_command)
        assert "Did not find port in command" in e.value.args[0]

    @mock.patch(REMOTE_PROCESS_GET_LIST_METHOD, mock.Mock(return_value=[]))
    def test_jump_port_no_processes(self, jump_tunnel):
        port = jump_tunnel._get_available_jump_port()
        assert port == NestedJumpTunnel._DEFAULT_JUMP_PORT

    def test_jump_port_some_busy(self, jump_tunnel, mock_client):
        busy_ports = [5555, 5556, 5557, 5559]
        expected_port = 5558
        commands = [jump_tunnel._remote_tunnel_command_no_port + str(bp) for bp in busy_ports]
        processes = [RemoteProcess(ssh_client=mock_client, user="u", pid=1, command=c) for c in commands]
        with mock.patch(self.REMOTE_PROCESS_GET_LIST_METHOD, mock.Mock(return_value=processes)):
            port = jump_tunnel._get_available_jump_port()
        assert port == expected_port

    def test_jump_port_is_not_retrieved_twice(self, jump_tunnel):
        with mock.patch(self.REMOTE_PROCESS_GET_LIST_METHOD, mock.Mock(return_value=[])) as mock_get_processes:
            port = jump_tunnel._get_available_jump_port()
            port_b = jump_tunnel._get_available_jump_port()
        assert mock_get_processes.call_count == 1
        assert port == port_b

    def test_remote_tunnel_command(self, jump_tunnel):
        with mock.patch.object(jump_tunnel, "_get_available_jump_port", mock.Mock(return_value=None)) as mock_port:
            remote_tunnel_command = jump_tunnel._remote_tunnel_command
        assert str(mock_port.return_value) in remote_tunnel_command

    @mock.patch(REMOTE_PROCESS_GET_AVAILABLE_PORT, mock.Mock(return_value="5557"))
    def test_tunnel_command(self, jump_tunnel):
        with mock.patch(self.REMOTE_TUNNEL_COMMAND_PROPERTY, "abc") as mock_remote_tunnel_cmd:
            tunnel_command = jump_tunnel._tunnel_command
        assert tunnel_command == jump_tunnel._ssh_command + jump_tunnel._local_tunnel_command + [mock_remote_tunnel_cmd]

    def test_tunnel_process_on_jump(self, jump_tunnel):
        expected_command = "abc"
        expected_username = jump_tunnel._username
        expected_process = MockProcess(expected_command, expected_username)
        remote_processes = [MockProcess("123 sdf", expected_username), MockProcess(expected_command, "username"),
                            MockProcess("xxxx", "xxx"), expected_process]
        with mock.patch(self.REMOTE_TUNNEL_COMMAND_PROPERTY, expected_command):
            with mock.patch(self.REMOTE_PROCESS_GET_LIST_METHOD, mock.Mock(return_value=remote_processes)):
                process = jump_tunnel._find_tunnel_process_on_jump()
        assert process == expected_process

    def test_tunnel_process_on_jump_no_process(self, jump_tunnel):
        expected_command = "abc"
        expected_username = jump_tunnel._username
        remote_processes = [MockProcess("123 sdf", expected_username), MockProcess(expected_command, "username"),
                            MockProcess("xxxx", "xxx")]
        with mock.patch(self.REMOTE_TUNNEL_COMMAND_PROPERTY, expected_command):
            with mock.patch(self.REMOTE_PROCESS_GET_LIST_METHOD, mock.Mock(return_value=remote_processes)):
                process = jump_tunnel._find_tunnel_process_on_jump()
        assert process is None

    def test_close(self, jump_tunnel):
        with mock.patch.object(jump_tunnel, "_find_tunnel_process_on_jump",
                               mock.Mock(return_value=mock.Mock())) as mock_process:
            mock_process.return_value.kill = mock.Mock()
            with mock.patch(self.SIMPLE_TUNNEL_CLOSE, mock.Mock()) as mock_super_close:
                jump_tunnel.close()
        mock_process.return_value.kill.assert_called_with()
        mock_super_close.assert_called_with()

    def test_close_no_process_on_jump(self, jump_tunnel):
        with mock.patch.object(jump_tunnel, "_find_tunnel_process_on_jump", mock.Mock(return_value=None)):
            with mock.patch(self.SIMPLE_TUNNEL_CLOSE, mock.Mock()) as mock_super_close:
                jump_tunnel.close()
        mock_super_close.assert_called_with()
