#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
"""Defines JumpClient class used for operations over SSH"""
import pprint
import subprocess

from retry import retry
from typing import Union

from e2e import command, config
from e2e.command_wrappers import SshPass
from e2e.command_wrappers.ssh import Ssh
from e2e.command_wrappers.scp import Scp
from e2e.constants.framework_constants import LOCALHOST
from e2e.logger import get_logger
from .base_jump_tunnel import BaseJumpTunnel


class JumpClient:
    """Jump clients that allows listing files, copying files etc.
    over ssh"""
    TUNNELS = {}
    _SSH_RETRY_DELAY = 30
    _SSH_RETRIES = 120
    logger = get_logger(__name__)

    def __init__(self, remote_username: str = None, remote_password: str = None,
                 remote_host: str = None, remote_port: str = "22", priv_key: str = None,
                 batch_mode: bool = False, quiet_mode: bool = True, tty_required: bool = False,
                 tunnel_class: Union[type(BaseJumpTunnel), BaseJumpTunnel] = None,
                 tunnel_kwargs: dict = None):
        """Client that is capable of executing commands on a remote host

        Args:
          remote_username: name of the ssh user
          remote_password: password of the ssh user
          remote_host: remote config.env_user if remote_username is None else remote_username address
          priv_key: path to private key file if exists
          batch_mode: see man scp
          quiet_mode: see man scp
        """
        from .tunnel import Tunnel
        tunnel_class = Tunnel if tunnel_class is None else tunnel_class
        remote_host = config.environment.env_main if remote_host is None else remote_host
        remote_username = config.env_user if remote_username is None else remote_username
        remote_password = config.env_pass if remote_password is None else remote_password
        priv_key = config.env_priv_key if priv_key is None else priv_key

        if tunnel_class:
            tunnel_id = (remote_host, remote_port)
            if tunnel_id not in self.TUNNELS:
                tunnel_kwargs = tunnel_kwargs if tunnel_kwargs is not None else dict(
                    target_host=remote_host,
                    target_port=remote_port,
                )
                self.TUNNELS[tunnel_id] = dict(tunnel=self.create_tunnel(tunnel_class, tunnel_kwargs), counter=1)
            else:
                self.TUNNELS[tunnel_id]["counter"] += 1
            self.tunnel = self.TUNNELS[tunnel_id]["tunnel"]
            remote_host = self.tunnel.host
            remote_port = self.tunnel.port
        else:
            self.tunnel = None

        self.kwargs = dict(
            remote_username=remote_username,
            remote_password=remote_password,
            remote_host=remote_host,
            remote_port=remote_port,
            priv_key=priv_key,
            batch_mode=batch_mode,
            quiet_mode=quiet_mode,
        )
        self.ssh_command = Ssh(tty=tty_required, **self.kwargs)
        self.scp_command = Scp(**self.kwargs)
        self.ssh_interactive = Ssh(remote_username=remote_username, remote_host=remote_host)

    @staticmethod
    def create_tunnel(tunnel_class: Union[type(BaseJumpTunnel), BaseJumpTunnel], tunnel_kwargs: dict) -> BaseJumpTunnel:
        if isinstance(tunnel_class, BaseJumpTunnel):
            tunnel = tunnel_class
        else:
            tunnel = tunnel_class(LOCALHOST, **tunnel_kwargs)
        tunnel.open()
        return tunnel

    def execute_ssh_command(self, remote_command, get_shell_data: bool = False, sshpass: bool = False):
        """Executes ssh command over ssh

        Args:
          :param remote_command: command to execute
          :param get_shell_data: when True no exception is raised while executing command
          :param sshpass: - when True 'sshpass' command is added to command line
        """
        if not isinstance(remote_command, list):
            remote_command = [remote_command]
        if config.os_name == "Windows":
            for i, part in enumerate(remote_command):
                remote_command[i] = part.replace("\\\"", "\"")
        if sshpass:
            self.ssh_command.extend(SshPass(password=self.kwargs["remote_password"]))
        cmd = self.ssh_command + remote_command
        return command.run(cmd, get_shell_data=get_shell_data)

    def execute_ssh_command_with_prompt(self, remote_command, prompt_answers, timeout=30,
                                        accept_timeout=False):
        """Executes interactive ssh

        Args:
          :param remote_command: - command to execute
          :param prompt_answers: list of expect / send pairs
          :param timeout: - timeout in seconds
          :param accept_timeout: - if True - command might be finished with timeout
        """
        cmd = self.ssh_command + remote_command
        return command.run_interactive(cmd, prompt_answers, timeout, accept_timeout=accept_timeout)

    def run_command(self, cmd):
        """Runs command with a predefined timeout

        Args:
          cmd: command as a list to execute

        Returns:
          Process exit code
        """
        self.logger.info("Executing command {}".format(" ".join(cmd)))
        process = subprocess.Popen(cmd)
        try:
            self.logger.info("Wait for command {} to finish".format(" ".join(cmd)))
            JumpClient.check_if_proc_finished(process, cmd)
        except subprocess.TimeoutExpired:
            self.logger.info("Killing {}".format(" ".join(cmd)))
            process.kill()
            raise
        return process.returncode

    def scp_from_remote(self, source_path, target_path):
        """Retrieves file from host"""
        cmd = self.scp_command.from_remote(source_path, target_path)
        return self.run_command(cmd)

    def scp_to_remote(self, source_path, target_path):
        """Copies file to host"""
        cmd = self.scp_command.to_remote(source_path, target_path)
        return self.run_command(cmd)

    @classmethod
    @retry(subprocess.TimeoutExpired, tries=_SSH_RETRIES, delay=_SSH_RETRY_DELAY)
    def check_if_proc_finished(cls, proc, remote_command):
        """Verifies process has finished"""
        if proc.poll() is None:
            raise subprocess.TimeoutExpired(remote_command, 0)

    # noinspection PyBroadException
    def __del__(self):
        if hasattr(self, "tunnel") and self.tunnel is not None:
            tunnel_id = (self.tunnel.host, self.tunnel.port)
            if tunnel_id in self.TUNNELS:
                self.TUNNELS[tunnel_id]["counter"] -= 1
                if self.TUNNELS[tunnel_id]["counter"] < 1:
                    del self.TUNNELS[tunnel_id]
                    del self.tunnel
            else:
                try:
                    self.logger.error("Lack of tunnel in TUNNELS: {}\n{}".format(tunnel_id,
                                                                                 pprint.pformat(self.TUNNELS)))
                except Exception:
                    try:
                        print("Lack of tunnel in TUNNELS: {}\n{}".format(tunnel_id, pprint.pformat(self.TUNNELS)))
                    except Exception:
                        pass
