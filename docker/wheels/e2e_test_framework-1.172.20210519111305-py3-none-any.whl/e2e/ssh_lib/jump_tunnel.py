#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import socket
import subprocess

from retry import retry

from e2e import config
from e2e.constants.framework_constants import LOCALHOST
from e2e.logger import get_logger
from e2e.process_utils import kill_child_processes
from .base_jump_tunnel import BaseJumpTunnel
from .jump_client import JumpClient

logger = get_logger(__name__)


class JumpTunnel(BaseJumpTunnel, JumpClient):
    PORT_FORWARD_ARGS = "{local_port}:{target_host}:{target_port}".format
    ALLOCATED_PORTS = []
    logger = get_logger(__name__)

    def __init__(self, host: str = LOCALHOST, port=None, target_host=None, target_port=None,
                 remote_username: str = None, remote_password: str = None,
                 remote_host: str = None, remote_port: str = None, priv_key: str = None,
                 batch_mode: bool = False, quiet_mode: bool = True, tty_required: bool = False):
        remote_host = config.tunnel_host if remote_host is None else remote_host
        remote_username = config.tunnel_user if remote_username is None else remote_username
        remote_password = config.tunnel_pass if remote_password is None else remote_password
        priv_key = config.tunnel_priv_key if priv_key is None else priv_key
        BaseJumpTunnel.__init__(self, host, self.allocate_local_port(port), self)
        self.target_host = target_host
        self.target_port = target_port
        JumpClient.__init__(self,
                            remote_username=remote_username, remote_password=remote_password,
                            remote_host=remote_host, remote_port=remote_port,
                            priv_key=priv_key,
                            batch_mode=batch_mode, quiet_mode=quiet_mode, tty_required=tty_required,
                            tunnel_class="")
        self.tunnel_command = self.ssh_command\
            .not_execute_remote_command()\
            .append(self.ssh_command.PORT_FORWARD)\
            .append(self.PORT_FORWARD_ARGS(local_port=self.port, target_host=self.target_host,
                                           target_port=self.target_port))

    @retry(OSError, tries=20, delay=5, logger=logger)
    def _check_tunnel_established(self):
        sock = socket.create_connection((self.host, self.port))
        sock.close()

    def open(self):
        """Open ssh tunnel. Remember to use close() after tests finished."""
        if self.is_open:
            self.logger.info("Tunnel already opened with command: {}".format(" ".join(self.tunnel_command)))
            return
        self.logger.info("Opening tunnel {}".format(" ".join(self.tunnel_command)))
        self.process = subprocess.Popen(self.tunnel_command)
        try:
            self.logger.info("Wait until tunnel is established")
            self._check_tunnel_established()
        except Exception as ex:
            logger.exception("Exception thrown while opening tunnel.", exc_info=ex)
            self.close()
            raise ex

    def close(self):
        """Closes the tunnel"""
        self.logger.debug("Close jump tunnel")
        kill_child_processes(self.process.pid)
        self.process.kill()

    @retry(AssertionError, tries=5, delay=.1, logger=logger)
    def allocate_local_port(self, port: str = None) -> str:
        if port is not None:
            if port in self.ALLOCATED_PORTS:
                raise RuntimeError("Port provided as an argument is already allocated.")
        else:
            with socket.socket() as s:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                s.bind(("", 0))
                addr, port = s.getsockname()
                port = str(port)
            assert port not in self.ALLOCATED_PORTS
        return port
