#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

import re

from e2e.exceptions import CommandExecutionException


class RemoteProcess(object):
    PS_COMMAND = "ps aux"
    KILL_COMMAND = "kill {}"
    USER_HEADER = "USER"
    PID_HEADER = "PID"
    COMMAND_HEADER = "COMMAND"

    def __init__(self, ssh_client, user: str, pid: int, command: str):
        if not hasattr(ssh_client, "execute_ssh_command"):
            raise TypeError("{} object does not have attribute execute_ssh_command".format(type(ssh_client)))
        self._ssh_client = ssh_client
        self.user = user
        self.pid = pid
        self.command = command

    def __repr__(self):
        return "{} (user={}, pid={}, command={})".format(self.__class__.__name__, self.user, self.pid, self.command)

    @classmethod
    def get_list(cls, ssh_client):
        output, _, _ = ssh_client.execute_ssh_command(cls.PS_COMMAND)
        header_index = cls._find_header_index_in_ps_aux_output(output)
        header = output[header_index]
        processes = []
        for line in output[header_index+1:]:
            try:
                process = cls(ssh_client=ssh_client,
                              user=cls._get_user_from_line(line, header),
                              pid=cls._get_pid_from_line(line, header),
                              command=cls._get_command_from_line(line, header))
                processes.append(process)
            except (CommandExecutionException, AssertionError, ValueError):
                # Ignore parsing errors, command output is unpredictable
                continue
        return processes

    def kill(self):
        self._ssh_client.execute_ssh_command(self.KILL_COMMAND.format(self.pid))

    @classmethod
    def _get_user_from_line(cls, line: str, header: str) -> str:
        index = header.index(cls.USER_HEADER)
        matches = re.findall(r"\S+", line[index:])
        assert len(matches) > 0, "Did not find process user in line '{}'".format(line)
        return matches[0]

    @classmethod
    def _get_pid_from_line(cls, line, header):
        end_index = header.index(cls.PID_HEADER) + len(cls.PID_HEADER)
        matches = re.findall(r"\S+", line[:end_index])
        assert len(matches) > 0, "Did not find process PID in line '{}'".format(line)
        try:
            pid = int(matches[-1], base=10)
        except ValueError:
            raise ValueError("Did not find process PID in line '{}".format(line))
        return pid

    @classmethod
    def _get_command_from_line(cls, line, header):
        """This method is implemented with the assumption that COMMAND is the last column."""
        index = header.index(cls.COMMAND_HEADER)
        return line[index:]

    @classmethod
    def _find_header_index_in_ps_aux_output(cls, output: list):
        for index, line in enumerate(output):
            if all(header in line for header in (cls.USER_HEADER, cls.PID_HEADER, cls.COMMAND_HEADER)):
                return index
        raise AssertionError("There seems to be no header in output of '{}'".format(cls.PS_COMMAND))
