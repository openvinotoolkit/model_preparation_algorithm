#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import base64
import os
import posixpath
import stat
from abc import abstractmethod
from typing import NamedTuple, Optional

from e2e import config
from e2e.command import run
from e2e.download import Downloader

PRIVATE_KEY = "{user_name}.key".format
PUBLIC_KEY = "{private_key_file_name}.pub".format
KEYS_LOCATION_PATH = "certificates"
MAIN_ADMIN_ACCOUNT = config.host_os_user
USERS_WITH_PRE_GENERATED_KEYS = [MAIN_ADMIN_ACCOUNT]


class KeyPair(NamedTuple("KeyPair", [("private", str), ("public", Optional[str])])):
    @property
    def public_as_string(self):
        with open(self.public) as key:
            return key.read()

    @property
    def public_as_base64(self):
        with open(self.public, "rb") as pubkey:
            key = pubkey.read()
            key = base64.b64encode(key)
        return key


CURRENT_PATH = os.getcwd()


def set_key_file_attributes(key_file):
    os.chmod(key_file, stat.S_IRUSR | stat.S_IWUSR)


def get_path_local(file: str):
    return os.path.join(CURRENT_PATH, file)


class SshKeyPairGenerator:

    @abstractmethod
    def __new__(cls, *args, **kwargs):
        pass

    @classmethod
    def generate_keys(cls, user_name: str) -> KeyPair:
        return cls.generate(PRIVATE_KEY(user_name=user_name))

    @classmethod
    def generate(cls, private_key_file_name: str) -> KeyPair:
        private_key_file_name = get_path_local(private_key_file_name)
        public_key = PUBLIC_KEY(private_key_file_name=private_key_file_name)
        output, return_code, pid = run(["ssh-keygen", "-f", private_key_file_name, "-t", "rsa", "-N", ""''""])
        assert return_code == 0, "Creation of keys not succeeded"
        set_key_file_attributes(private_key_file_name)
        set_key_file_attributes(public_key)
        return KeyPair(private=private_key_file_name, public=public_key)


class SshKeyPairDownloader:
    _DOWNLOADER = Downloader()

    @classmethod
    def fetch_pre_generated_keys(cls, user_name, private_key: str = None, public_key: str = None) -> KeyPair:
        private_key = cls.download_private_key(user_name, private_key)
        public_key = cls.download_public_key(user_name, public_key)
        return KeyPair(private=private_key, public=public_key)

    @classmethod
    def download_key(cls, key: str) -> str:
        cls._DOWNLOADER.download(file=key, path=KEYS_LOCATION_PATH.join([posixpath.sep, posixpath.sep]))
        key = get_path_local(key)
        set_key_file_attributes(key)
        return key

    @classmethod
    def download_private_key(cls, user_name: str, private_key: str = None) -> str:
        if private_key is not None:
            key = cls.download_key(private_key)
            if os.path.exists(key):
                return key
        return cls.download_key(PRIVATE_KEY(user_name=user_name))

    @classmethod
    def download_public_key(cls, user_name: str, public_key: str = None) -> str:
        if public_key is not None:
            key = cls.download_key(public_key)
            if os.path.exists(key):
                return key
        else:
            return cls.download_key(PUBLIC_KEY(user_name=user_name))


class SshKeyPair:
    _KEYS = dict()  # NOTE: keys are being cached in *class* field - ones with the same username are fetched from cache

    def __new__(cls, user_name: str, private_key: str = None, public_key: str = None) -> KeyPair:
        if not user_name:
            user_name = MAIN_ADMIN_ACCOUNT
        if user_name not in cls._KEYS:
            if cls.exist_provided_key(private_key) and cls.exist_provided_key(public_key):
                cls._KEYS[user_name] = KeyPair(private=private_key, public=public_key)
            elif user_name in USERS_WITH_PRE_GENERATED_KEYS:
                cls._KEYS[user_name] = SshKeyPairDownloader.fetch_pre_generated_keys(user_name, private_key, public_key)
            else:
                cls._KEYS[user_name] = SshKeyPairGenerator.generate_keys(user_name)
        return cls._KEYS[user_name]

    @classmethod
    def exist_provided_key(cls, key_file_path: str) -> bool:
        return key_file_path is not None and os.path.exists(key_file_path)
