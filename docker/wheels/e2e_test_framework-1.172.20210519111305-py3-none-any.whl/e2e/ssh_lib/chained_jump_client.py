#
# Copyright (c) 2020 Intel Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

from typing import List

from e2e import command
from e2e.command_wrappers import Ssh


class HostCredentials:

    def __init__(self, host: str, user: str, password: str):
        self.host = host
        self.user = user
        self.password = password

    def get_ssh_string(self) -> List[str]:
        return Ssh(remote_password=self.password, remote_username=self.user, remote_host=self.host, quiet_mode=True)


class ChainedJumpClient:

    def __init__(self, credentials_chain: List[HostCredentials] = None):
        if credentials_chain is None:
            credentials_chain = []
        self.credentials_chain = credentials_chain

    def add_host(self, host: str, user: str, password: str):
        self.credentials_chain.append(HostCredentials(host=host, user=user, password=password))
        return self

    def execute_ssh_command(self, remote_command, get_shell_data: bool = False):
        """Executes ssh command over ssh

        Args:
          remote_command: command to execute
          get_shell_data: when True no exception is raised while executing command
        """
        if not isinstance(remote_command, list):
            remote_command = [remote_command]
        cmd = []
        for credentials in self.credentials_chain:
            cmd = cmd + credentials.get_ssh_string()
        cmd = cmd + remote_command
        return command.run(cmd, get_shell_data=get_shell_data)
