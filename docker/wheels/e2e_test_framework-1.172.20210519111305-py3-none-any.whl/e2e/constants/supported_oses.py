#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import platform
from enum import Enum

from typing import List, NamedTuple, Callable, Union, Any

import distro

from e2e.current_os_info import CurrentOsInfo


class EnumComparableWithStrCaseIgnored(Enum):
    def __eq__(self, other):
        if isinstance(other, str):
            return self.value.lower() == other.lower()
        return super().__eq__(other)


class Entry:
    def __init__(self, value: Union[str, Any], getter: Callable[[], str] = None,
                 comparator:  Callable[[str, str], bool] = None):
        self.value = value
        self.getter = getter if getter is not None else lambda: None
        self.comparator = comparator if comparator is not None else self.cmp_equal

    @staticmethod
    def cmp_equal(expected: str, found: str):
        return expected == found

    @staticmethod
    def cmp_equal_or_greater_as_int(expected: str, found: str):
        try:
            expected = int(expected, base=10)
            found = int(found, base=10)
        except ValueError as value_error:
            from e2e.logger import get_logger
            logger = get_logger(__name__)
            logger.exception("Cannot compare os minor versions expected: {}, found: {}. "
                             "Conversion to int not succeeded."
                             .format(expected, found),
                             exc_info=value_error)
        return expected <= found


class OsSpecification(NamedTuple("OsSpecification", [
    ('system', Entry),
    ('architecture', Entry),
    ("major_version", Entry),
    ("minor_version", Entry),
    ("release_type", Entry)
])):
    __slots__ = ()


class EnumOsSpecification(Enum):
    def check(self):
        return all([entry.comparator(entry.value, entry.getter()) for entry in self.value]) is True

    def eval(self) -> dict:
        return {key: dict(expected=entry.value, found=entry.getter())
                for key, entry in self.value._asdict().items()}


class SupportedOsName:

    # operating system ids for parametrization
    UBUNTU_16_ID = "ubuntu16"
    UBUNTU_18_ID = "ubuntu18"
    UBUNTU_20_ID = "ubuntu20"
    REDHAT_ID = "redhat"
    CENTOS_ID = "centos"
    WINDOWS_10_ID = "windows"
    SIERRA_ID = "sierra"
    MOJAVE_ID = "mojave"

    # operating system descriptions for parametrization
    UBUNTU_16 = "Ubuntu 16.04 LTS"
    UBUNTU_18 = "Ubuntu 18.04 LTS"
    UBUNTU_20 = "Ubuntu 20.04 LTS"
    REDHAT = "Red Hat Enterprise Linux Server"
    CENTOS = "Centos"
    WINDOWS_10 = "Windows 10"
    SIERRA = "MacOS High Sierra"
    MOJAVE = "MacOs Mojave"


def get_platform_architecture() -> str:
    return platform.architecture()[0]


def get_linux_major_version() -> str:
    return distro.info()['version_parts']['major']


def get_ubuntu_release_type() -> str:
    return distro.os_release_attr("version").partition("LTS")[1]


def get_mac_major_version() -> str:
    return platform.mac_ver()[0].split(".")[0]


def get_mac_minor_version() -> str:
    return platform.mac_ver()[0].split(".")[1]


class SupportedLinux(EnumOsSpecification):
    Ubuntu_16_LTS_64bit = OsSpecification(
        system=Entry("Ubuntu", distro.name),
        architecture=Entry("64bit", get_platform_architecture),
        major_version=Entry("16", get_linux_major_version),
        minor_version=Entry(None),
        release_type=Entry("LTS", get_ubuntu_release_type))

    Ubuntu_18_LTS_64bit = OsSpecification(
        system=Entry("Ubuntu", distro.name),
        architecture=Entry("64bit", get_platform_architecture),
        major_version=Entry("18", get_linux_major_version),
        minor_version=Entry(None),
        release_type=Entry("LTS", get_ubuntu_release_type))

    RedHat_7_64bit = OsSpecification(
        system=Entry("Red Hat Enterprise Linux Server", distro.name),
        architecture=Entry("64bit", get_platform_architecture),
        major_version=Entry("7", get_linux_major_version),
        minor_version=Entry(None),
        # TODO This line should be  changed
        release_type=Entry("", lambda: distro.os_release_attr("version").partition("LTS")[1]))


class SupportedWindows(EnumOsSpecification):
    Windows_10_64bit = OsSpecification(
        system=Entry("Windows", platform.system),
        architecture=Entry("64bit", get_platform_architecture),
        major_version=Entry("10", platform.release),
        minor_version=Entry(None),
        release_type=Entry(None))


class SupportedMacOs(EnumOsSpecification):
    HighSierra_64bit = OsSpecification(
        system=Entry("Darwin", distro.name),
        architecture=Entry("64bit", get_platform_architecture),
        major_version=Entry("10", get_mac_major_version),
        minor_version=Entry("13", get_mac_minor_version, Entry.cmp_equal_or_greater_as_int),
        release_type=Entry(None))


class OS(EnumComparableWithStrCaseIgnored):
    Windows = "Windows", SupportedWindows
    Linux = "Linux", SupportedLinux
    Darwin = "Darwin", SupportedMacOs

    def __new__(cls, os_name: str, supported_versions: List[EnumOsSpecification]):
        obj = object.__new__(cls)
        obj._value_ = os_name
        obj._supported_versions = supported_versions
        return obj

    @property
    def versions(self) -> List[EnumOsSpecification]:
        return self._supported_versions

    @classmethod
    def current(cls) -> 'OS':
        return cls[CurrentOsInfo.get_os_name()]
