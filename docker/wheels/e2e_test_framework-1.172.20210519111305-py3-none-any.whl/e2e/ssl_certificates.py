#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

from collections import namedtuple
from grpc import ssl_channel_credentials as grpc_ssl_channel_credentials

from e2e.config import tmp_dir
from e2e.test_names import generate_test_object_name


HttpsCerts = namedtuple("HttpsCerts", ["client_cert", "client_key", "server_cert"])


class SslCertificates:
    """
    Load ssl certificates.
    """

    def __init__(self):
        self.server_cert_path = None
        self.server_cert = None

        self.server_key_path = None
        self.server_key = None

        self.client_cert_ca_path = None
        self.client_cert_ca = None

        self.client_cert_ca_crl_path = None
        self.client_cert_ca_crl = None

        self.dhparam_path = None
        self.dhparam = None

        self.client_cert_path = None
        self.client_cert = None

        self.client_key_path = None
        self.client_key = None

    def _load_file_into_attribute(self, attribute, filepath):
        self.__setattr__(f"{attribute}_path", filepath)
        with open(filepath, "rb") as f:
            self.__setattr__(attribute, f.read())

    def load_server_cert(self, filepath):
        self._load_file_into_attribute("server_cert", filepath)

    def load_server_key(self, filepath):
        self._load_file_into_attribute("server_key", filepath)

    def load_client_cert_ca(self, filepath):
        self._load_file_into_attribute("client_cert_ca", filepath)

    def load_client_cert_ca_crl(self, filepath):
        self._load_file_into_attribute("client_cert_ca_crl", filepath)

    def load_dhparam(self, filepath):
        self._load_file_into_attribute("dhparam", filepath)

    def load_client_cert(self, filepath):
        self._load_file_into_attribute("client_cert", filepath)

    def load_client_key(self, filepath):
        self._load_file_into_attribute("client_key", filepath)

    def get_server_cert_bytes(self):
        return self.server_cert

    def get_client_key_bytes(self):
        return self.client_key

    def get_client_cert_bytes(self):
        return self.client_cert

    def get_client_ca_bytes(self):
        return self.client_cert_ca

    def get_https_cert(self):
        return HttpsCerts(self.client_cert_path, self.client_key_path, self.server_cert_path)

    def get_grpc_ssl_channel_credentials(self):
        return grpc_ssl_channel_credentials(
            root_certificates=self.get_server_cert_bytes(),
            private_key=self.get_client_key_bytes(),
            certificate_chain=self.get_client_cert_bytes(),
        )
