#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import os
import re
from collections import Counter, namedtuple
from datetime import datetime
from itertools import groupby
from typing import TYPE_CHECKING, Optional

import pytest
from pytest import ExitCode
from _pytest.mark import MarkDecorator, Mark
from _pytest.python import Function

from e2e import config as e2e_config
from e2e.markers import MarkGeneral, MarkRunType, MarksRegistry
from e2e.http_calls.basic import get_info
from e2e.constants.project_paths import Path
from e2e.date_time import DateTime
from e2e.config import bug_ids, req_ids
from e2e.environment_info import EnvironmentInfo
from e2e.files.file_base import FileBase
from e2e.http_client.configuration_provider.no_auth import NoAuthConfigurationProvider
from e2e.http_client.http_client_factory import HttpClientFactory
from e2e.mongo_reporter.run_reporter import RunReporter
from e2e.mongo_reporter.request_reporter import request_reporter
from e2e.logger import get_logger, SEPARATOR, E2eFileHandler

if TYPE_CHECKING:
    from _pytest.nodes import Item

PYTHON_FILE_EXTENSION = ".py"
INCREMENTAL_KEYWORD = "incremental"
SkippedItem = namedtuple("SkippedItem", "test_name reason")
_current_test_run = ""
_master = False
test_run_reporters = {}
# performance_reporter = PerformanceReporter(run_id=e2e_config.test_run_id)

logger = get_logger(__name__)


def _log_test_configuration():
    logger.info("============== configuration variables ==============")
    pt_env_vars = []
    for key, value in os.environ.items():
        if key.startswith("TT_"):
            pt_env_vars.append("{}={}".format(key, value))
    pt_env_vars.sort()
    for env_var in pt_env_vars:
        logger.info(env_var)


def pytest_sessionstart(session):
    """
    Log platform_test environment variables.
    Report test type to mongo_reporter.
    Check environment viability. If the check fails, report unavailable environment
    and don't start test session.
    """
    logger.info("Starting test session in the following folder: {}".format(session.startdir))
    DateTime.TEST_SESSION_START = datetime.now()

    _log_test_configuration()

    client = HttpClientFactory.get(NoAuthConfigurationProvider.get(url=e2e_config.environment.api))

    try:
        if not e2e_config.disable_environment_check:
            get_info(client)
    except Exception as e:
        logger.error("Environment {} is unavailable - {}: {}".format(client.url, type(e).__name__, e))
        mongo_reporter = RunReporter(document_id=e2e_config.test_run_id,
                                     environment=EnvironmentInfo.get_environment_name())
        mongo_reporter.report_test_type(
            MarkRunType.TEST_MARK_INITIAL if e2e_config.run_initial_tests
            else MarkRunType.TEST_MARK_SMOKE if e2e_config.run_smoke_tests
            else MarkRunType.TEST_MARK_ON_COMMIT if e2e_config.run_on_commit_tests
            else MarkRunType.TEST_MARK_REGRESSION if e2e_config.run_regression_tests
            else MarkRunType.TEST_MARK_ENABLING if e2e_config.run_enabling_tests
            else MarkRunType.TEST_MARK_MANUAL if e2e_config.run_manual_tests
            else MarkRunType.TEST_MARK_OTHER if e2e_config.run_api_other_tests
            else MarkRunType.TEST_MARK_GUI_SMOKE if e2e_config.run_gui_smoke_tests
            else MarkRunType.TEST_MARK_GUI_REGRESSION if e2e_config.run_gui_regression_tests
            else MarkRunType.TEST_MARK_GUI_ENABLING if e2e_config.run_gui_enabling_tests
            else MarkRunType.TEST_MARK_GUI_OTHER if e2e_config.run_gui_other_tests
            else MarkRunType.TEST_MARK_GUI_LONG if e2e_config.run_gui_long_tests
            else MarkRunType.TEST_MARK_STRESS_AND_LOAD if e2e_config.run_stress_and_load_tests
            else MarkRunType.TEST_MARK_LONG if e2e_config.run_long_tests
            else MarkRunType.TEST_MARK_PERFORMANCE if e2e_config.run_performance_tests
            else MarkRunType.TEST_MARK_ON_MERGE_REQUEST if e2e_config.run_on_merge_request_tests
            else MarkRunType.TEST_MARK_GUI_ON_MERGE_REQUEST if e2e_config.run_gui_on_merge_request_tests
            else MarkRunType.TEST_MARK_HW_SPECIFIC)
        mongo_reporter.report_test_build_number(build_number=e2e_config.test_session_build_number)
        mongo_reporter.report_env_numbers(build_number=EnvironmentInfo.get_build_number(),
                                          version_number=EnvironmentInfo.get_version_number())
        mongo_reporter.report_unavailable_environment()
        raise


def pytest_addoption(parser):
    parser.addoption("--only-with-param", type=str, action="store", metavar="PARAMETER",
                     help="run only tests with parameter (for api-performance test)")


def pytest_configure(config):
    MarksRegistry.register(config)
    _set_master(config)


def is_test_marker_id_is_matched_with_jira_id(test, id_to_check: str):
    for marker in test.own_markers:
        if marker.name is MarkGeneral.BUGS.value or marker.name is MarkGeneral.REQIDS.value:
            jira_marker = marker.args[0]
            if isinstance(jira_marker, dict):
                for param in jira_marker:
                    if param is None:
                        if id_to_check in str(jira_marker.values):
                            return True
                    else:
                        if param in test.name:
                            if id_to_check in str(jira_marker.values()):
                                return True
            elif isinstance(jira_marker, str):
                if id_to_check in jira_marker:
                    return True
            else:
                raise RuntimeError(f"Test {test.name} do not have mark in correct form. Form: {type(jira_marker)} ")
    return False


def get_required_markers_id_for_test_run():
    required_marker_ids_list = []
    if bug_ids is not None:
        required_marker_ids_list.append(bug_ids)
    if req_ids is not None:
        required_marker_ids_list.append(req_ids)
    if len(required_marker_ids_list) == 0:
        return None
    return required_marker_ids_list


def pytest_collection_modifyitems(session, config, items):
    """
    Support for running tests with component tags.
    Report all test component markers to mongo_reporter.
    """
    logger.info("Preparing tests for test session in the following folder: {}".format(session.startdir))
    only_param = config.getoption("only_with_param")
    if only_param is not None:
        items[:] = [i for i in items if only_param in i.name]

    if config.option.collectonly:
        _log_skip_statistic(items)

    deselected = []
    all_component_markers = {}
    all_reqids = {}
    pytest_markers_with_filled_id = get_required_markers_id_for_test_run()
    for item in items:
        if isinstance(item, Function):
            any_test_type_marker = MarkRunType.get_test_type_mark(item)
            if not any_test_type_marker:
                raise RuntimeError("Test do not have test_type: " + item.name)
            if pytest_markers_with_filled_id is not None:
                for jira_id in pytest_markers_with_filled_id:
                    if not is_test_marker_id_is_matched_with_jira_id(item, jira_id) and item not in deselected:
                        deselected.append(item)
                        continue
            else:
                if _test_deselected(item):
                    deselected.append(item)
                    continue
        components = item.get_closest_marker(MarkGeneral.COMPONENTS.mark)
        if components is not None:
            if MarkRunType.get_test_type_mark(item) not in all_component_markers:
                all_component_markers[MarkRunType.get_test_type_mark(item)] = []
            all_component_markers[MarkRunType.get_test_type_mark(item)].append(components)
            for component in components.args:
                item.add_marker(str(component))
        reqids = item.get_closest_marker(MarkGeneral.REQIDS.mark)
        if reqids is not None:
            if MarkRunType.get_test_type_mark(item) not in all_reqids:
                all_reqids[MarkRunType.get_test_type_mark(item)] = []
            all_reqids[MarkRunType.get_test_type_mark(item)].extend(list(reqids.args))

    if deselected:
        config.hook.pytest_deselected(items=deselected)
        for item in deselected:
            test_name = item.parent.nodeid
            # nodeid comes in a way:
            # 1) test.py::TestClass::()
            # 2) test.py::
            if test_name[-2:] == "()":
                test_name = test_name[:-2]
            else:
                test_name += "::"

            test_name += item.name
            logger.info("Deselecting test: " + test_name)
            items.remove(item)

    # sort items so that we have the sequence of tests being executed as in MarkRunType:
    items[:] = sorted(items, key=lambda element: MarkRunType.test_type_mark_to_int(element))

    # initiate one test run reporter for each marked test type
    for item in items:
        # the below call will instantiate test run reporter for every test type
        _ = _get_test_run_reporter(MarkRunType.get_test_type_mark(item))

    for test_mark in test_run_reporters:
        mongo_reporter = test_run_reporters[test_mark]
        mongo_reporter.report_test_type(test_type_mark=test_mark, save=False)
        mongo_reporter.report_env_numbers(save=False, build_number=EnvironmentInfo.get_build_number(),
                                          version_number=EnvironmentInfo.get_version_number())
        all_components = []
        for marker in all_component_markers[test_mark]:
            all_components.extend(list(marker.args))
        mongo_reporter.report_components(all_components, save=False)
        if all_reqids[test_mark]:
            mongo_reporter.report_reqids(all_reqids[test_mark], save=False)
        mongo_reporter.save_report()


def _test_deselected(item):
    if item.get_closest_marker(MarkRunType.TEST_MARK_ON_COMMIT) and not e2e_config.run_on_commit_tests:
        return True
    if item.get_closest_marker(MarkRunType.TEST_MARK_REGRESSION) and not e2e_config.run_regression_tests:
        return True
    if item.get_closest_marker(MarkRunType.TEST_MARK_ENABLING) and not e2e_config.run_enabling_tests:
        return True
    if item.get_closest_marker(MarkRunType.TEST_MARK_LONG) and not e2e_config.run_long_tests:
        return True
    if item.get_closest_marker(MarkRunType.TEST_MARK_STRESS_AND_LOAD) and not e2e_config.run_stress_and_load_tests:
        return True
    if item.get_closest_marker(MarkRunType.TEST_MARK_PERFORMANCE) and not e2e_config.run_performance_tests:
        return True
    if item.get_closest_marker(MarkRunType.TEST_MARK_INITIAL) and not e2e_config.run_initial_tests:
        return True
    if item.get_closest_marker(MarkRunType.TEST_MARK_SMOKE) and not e2e_config.run_smoke_tests:
        return True
    if item.get_closest_marker(MarkRunType.TEST_MARK_OTHER) and not e2e_config.run_api_other_tests:
        return True
    if item.get_closest_marker(MarkRunType.TEST_MARK_GUI_SMOKE) and not e2e_config.run_gui_smoke_tests:
        return True
    if item.get_closest_marker(MarkRunType.TEST_MARK_GUI_REGRESSION) and not e2e_config.run_gui_regression_tests:
        return True
    if item.get_closest_marker(MarkRunType.TEST_MARK_GUI_ENABLING) and not e2e_config.run_gui_enabling_tests:
        return True
    if item.get_closest_marker(MarkRunType.TEST_MARK_GUI_OTHER) and not e2e_config.run_gui_other_tests:
        return True
    if item.get_closest_marker(MarkRunType.TEST_MARK_GUI_LONG) and not e2e_config.run_gui_long_tests:
        return True
    if item.get_closest_marker(MarkRunType.TEST_MARK_MANUAL) and not e2e_config.run_manual_tests:
        return True
    if item.get_closest_marker(MarkRunType.TEST_MARK_HW_SPECIFIC) and not e2e_config.run_hw_specific:
        return True
    if item.get_closest_marker(MarkRunType.TEST_MARK_ON_MERGE_REQUEST) \
            and not e2e_config.run_on_merge_request_tests:
        return True
    if item.get_closest_marker(MarkRunType.TEST_MARK_GUI_ON_MERGE_REQUEST) \
            and not e2e_config.run_gui_on_merge_request_tests:
        return True
    if item.get_closest_marker(MarkRunType.TEST_MARK_UNIT) and not e2e_config.run_unit_tests:
        return True
    if item.get_closest_marker(MarkRunType.TEST_MARK_COMPONENT) and not e2e_config.run_component_tests:
        return True
    return False


def _get_test_run_reporter(test_mark):
    if test_mark not in test_run_reporters:
        mongo_reporter = RunReporter(document_id=e2e_config.test_run_id,
                                     environment=EnvironmentInfo.get_environment_name())
        mongo_reporter.report_test_type(test_type_mark=test_mark)
        mongo_reporter.report_test_build_number(build_number=e2e_config.test_session_build_number)
        mongo_reporter.report_env_numbers(build_number=EnvironmentInfo.get_build_number(),
                                          version_number=EnvironmentInfo.get_version_number())
        test_run_reporters[test_mark] = mongo_reporter
        return mongo_reporter
    return test_run_reporters[test_mark]


def _log_skip_statistic(items):
    issue_stats, other_tests = _calc_statistics(items)
    _log_labeled_stats(issue_stats)
    _log_others(other_tests)


def _calc_statistics(items):
    skipped_items = _get_skipped_items(items)
    issue_numbers = []
    other_tests = []
    for item in skipped_items:
        match = re.search(r"DPNG-\d+", item.reason)
        if match:
            issue_numbers.append(match.group(0))
        else:
            issue_numbers.append('others')
            other_tests.append(item)
    return Counter(issue_numbers), other_tests


def _get_skipped_items(items):
    skipped_items = [item for item in items if item.keywords.get('skip') is not None]
    items = []
    for item in skipped_items:
        skip_info = item.keywords.get('skip')
        if isinstance(skip_info, (Mark, MarkDecorator)):
            if 'reason' in skip_info.kwargs:
                reason = skip_info.kwargs['reason']
            elif skip_info.args:
                reason = skip_info.args[0]
            else:
                reason = ''
            items.append(SkippedItem(item.nodeid, reason))
    return items


def _log_labeled_stats(issues):
    msg = ["Skipped tests statistic:"]
    issues_sorted_by_quantity = sorted(issues.items(), key=lambda i: i[1], reverse=True)
    for issue, quantity in issues_sorted_by_quantity:
        msg.append("{:>11}: {:>6}".format(issue, quantity))
    logger.info("\n".join(msg))


def _log_others(other_items):
    msg = ["Skipped tests not labeled with issue:"]
    items_grouped_by_reason = groupby(other_items, key=lambda i: i.reason)
    for reason, items in list(items_grouped_by_reason):
        msg.append("{}:".format(reason))
        msg.extend("|---{}".format(item.test_name) for item in list(items))
    logger.info("\n".join(msg))


def pytest_collection_finish(session):
    """Logs test statistics for all implemented tests, split by main directory."""
    if session.config.known_args_namespace.collectonly:
        stats = {}
        for item in session.items:
            for directory_name in Path.test_directories:
                if item.location[0].startswith(directory_name):
                    stats[directory_name] = stats.get(directory_name, 0) + 1
        logger.info("==================== test statistics ====================")
        for directory, test_number in list(stats.items()):
            logger.info("{}: {}".format(directory, test_number))


def _get_current_test_run():
    return _current_test_run


def _set_current_test_run(test_run):
    global _current_test_run
    _current_test_run = test_run
    return _current_test_run


def _set_master(config):
    global _master
    _master = not hasattr(config, 'slaveinput')


def master():
    return _master


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    # report for setup, call, teardown
    outcome = yield

    # check if we are shifting from one test type to another so that we update next test run start
    # and current test run end date
    current_run_type = _get_current_test_run()
    current_test_type = MarkRunType.get_test_type_mark(item)
    test_run_reporter = _get_test_run_reporter(current_test_type)

    if current_test_type != current_run_type:
        logger.info("Finishing tests for test run type: {}".format(_get_current_test_run()))
        if current_run_type != "":
            previous_test_run_reporter = _get_test_run_reporter(current_run_type)
            previous_test_run_reporter.on_run_end()
        test_run_reporter.report_start_date(datetime.now(), save=True)
        current_run_type = _set_current_test_run(current_test_type)
        logger.info("Starting tests for test run type: {}".format(current_run_type))

    report = outcome.get_result()
    inserted_id = test_run_reporter.log_report(report, item)

    setattr(item, "rep_" + report.when, report)

    if inserted_id:
        test_name = item.nodeid.split('::')[-1]
        request_reporter.send_to_db(test_name=test_name, result_document_id=inserted_id)

    if hasattr(report, 'passed') and not report.passed:
        logger.info(report.longreprtext)

    # support for incremental tests
    if INCREMENTAL_KEYWORD in item.keywords:
        if call.excinfo is not None and call.excinfo.typename != "Skipped":
            parent = item.parent
            parent._previous_fail = item


__root_logger = get_logger(None)


@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_protocol(item: "Item", nextitem: "Optional[Item]"):
    if not item.keywords.get("skip"):
        fh = E2eFileHandler(item)
        __root_logger.addHandler(fh)
    yield
    if not item.keywords.get("skip"):
        fh.close()
        __root_logger.removeHandler(fh)


def pytest_runtest_setup(item):
    if INCREMENTAL_KEYWORD in item.keywords:
        previous_fail = getattr(item.parent, "_previous_fail", None)
        if previous_fail is not None:
            pytest.skip("previous test failed ({})".format(previous_fail.name))


def pytest_sessionfinish(session, exitstatus):
    current_test_run = _get_current_test_run()
    logger.info("Finishing test session for test run type: {} in the following folder: {}".format(current_test_run,
                                                                                                  session.startdir))
    data_to_save = []

    test_status_report_header = f"{SEPARATOR} TEST TYPE STATUS REPORT - BEGIN {SEPARATOR}"
    logger.info(test_status_report_header)

    for test_mark in test_run_reporters:
        mongo_reporter = test_run_reporters[test_mark]
        mongo_document = mongo_reporter.mongo_run_document
        test_type = mongo_document["test_type"]
        test_type_result = mongo_document["status"]
        test_status_report_item = f"Test type: {test_type} result: {test_type_result}"
        logger.info(test_status_report_item)
        data_to_save.append(test_status_report_item)
    test_status_report_footer = f"{SEPARATOR} TEST TYPE STATUS REPORT - END {SEPARATOR}"
    logger.info(test_status_report_footer)

    if e2e_config.artifacts_dir != "":
        test_status_file_name = "test_status.txt"
        test_status_file = FileBase(test_status_file_name, e2e_config.artifacts_dir)
        test_status_file.save_list_to_file(data=data_to_save, flags="a")

    logger.info("Exit status is: {}".format(str(exitstatus)))
    if e2e_config.test_temp_dir_cleanup is False:
        from e2e.tmp_dir import TmpDir
        TmpDir.TMP_DIR._finalizer.detach()
    if current_test_run != "":
        _get_test_run_reporter(current_test_run).on_run_end()
    else:
        if not _master:
            logger.error("Finishing test session without any test executed")
    if e2e_config.no_fail_no_test_collected and exitstatus == ExitCode.NO_TESTS_COLLECTED:
        no_fail_no_test_collected = "{}={}".format("TT_NO_FAIL_NO_TESTS_COLLECTED",
                                                   e2e_config.no_fail_no_test_collected)
        logger.info("Exiting with success with flag {}".format(no_fail_no_test_collected))
        session.exitstatus = ExitCode.OK
