#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
from collections import defaultdict
from datetime import datetime
from email import parser
from typing import NamedTuple, Union, Tuple, Callable

from bs4 import BeautifulSoup
from marshmallow.orderedset import OrderedSet
from retry import retry

from e2e import config
from e2e.http_client import HttpClientConfiguration, HttpClientType, HttpClientFactory, HttpMethod, HttpClient

EMAIL_FILE_ATTRIBUTES_FIELDS = [('created', Union[datetime, str]), ('size', Union[int, str])]
EMAIL_FILE_FIELDS = [('name', str)] + EMAIL_FILE_ATTRIBUTES_FIELDS


class EmailNotFoundException(Exception):
    """Exception thrown when expected email was not received."""
    pass


class EmailFileAttributes(NamedTuple("EmailFileAttributes", EMAIL_FILE_ATTRIBUTES_FIELDS)):
    """Email file attributes representation"""
    __slots__ = ()

    def __new__(cls, created: Union[datetime, str], size: Union[int, str]):
        """
        Creates EmailFileAttributes named tuple with fields: [created, size].
        Args:
            created: date of file (email) creation.
            size: size of file with email.

        Returns: EmailFileAttributes named tuple.
        """
        created = created if isinstance(created, datetime) else datetime.strptime(created, "%d-%b-%Y %H:%M")
        size = size if isinstance(size, int) else cls.decode_size(size)
        return tuple.__new__(cls, (created, size))

    @staticmethod
    def decode_size(size_as_string: str):
        """
        Convert size provided as string to integer representation.
        Args:
            size_as_string: size of the file as a string

        Returns: size as a integer value.
        """
        try:
            size = int(size_as_string)
        except ValueError:
            raise AssertionError("Incorrect file size format in mail as a file representation listing")
        return size


class EmailFile(NamedTuple("EmailFile", EMAIL_FILE_FIELDS)):
    """Email file representation. It not contains file itself, only contains file attributes."""
    __slots__ = ()

    def __new__(cls, name: str, file_attributes: str):
        """
        Creates EmailFile named tuple with fields: [name, created, size].
        Args:
            name: name of the file with email.
            file_attributes: string to parse to find date time of creation and file size.

        Returns:
            EmailFile named tuple.

        """
        attr = cls.decode_file_attributes(file_attributes)
        assert name != "" or name is not None, "File name cannot be empty"
        return tuple.__new__(cls, (name, attr.created, attr.size))

    @classmethod
    def decode_file_attributes(cls, file_attributes: str):
        """
        Decode string representation of file attributes
        expected format:
        "                            15-Jul-2017 05:00                1204"
        description of fields:       date        time                 size
        Args:
            file_attributes: string in format as above

        Returns: Email file attributes converted to EmailFileAttributes named tuple
        """
        file_attributes_list = file_attributes.strip().rsplit(maxsplit=1)
        assert len(file_attributes_list) == 2,\
            "Incorrect file attributes format in 'mail as a file' representation listing"
        return EmailFileAttributes(*file_attributes_list)


class FakeSMTPServerClient:
    """
    Tool to gather emails from fake smtp server.
    """
    DEFAULT_SCHEMA = "https://"
    DEFAULT_PATH = "email/"
    DEFAULT_CLIENT_TYPE = HttpClientType.BASIC_AUTH
    username = None
    password = None
    emails = None
    new_emails = None
    HTML_TAG_NAME_TO_STORE_EMAIL_LISTING = "pre"

    def __init__(self,
                 url: str = config.packages_server_address,
                 path: str = DEFAULT_PATH,
                 client_type: HttpClientType = DEFAULT_CLIENT_TYPE,
                 username: str = config.packages_server_user,
                 password: str = config.packages_server_password):
        """
        Create Fake-SMTP-Server Client to gather e-mails stored as a *.eml files listed as a html file listing.
        Args:
            url: url to fake server
            path: path on the server to access list of e-mails and particular e-mail files.
            client_type: client authentication type
            username: user name to authenticate
            password: user password to authenticate.
        """
        self.client_type = client_type
        self.path = path
        self.url = url
        self.username = username
        self.password = password
        self.clean_emails()
        self.config = self.create_config()
        self.http_client = self.get_client()

    def get_client(self) -> HttpClient:
        """
        Gets http client instance with previously created its config.
        Returns:
            HttpClient to perform all requests.
        """
        return HttpClientFactory.get(configuration=self.config)

    def create_config(self) -> HttpClientConfiguration:
        """
        Creates config for http client to authenticate user
        Returns:
            HttpClientConfiguration required to create HttpClient
        """
        return HttpClientConfiguration(client_type=self.client_type,
                                       url="{schema}{url}".format(schema=self.DEFAULT_SCHEMA, url=self.url),
                                       username=self.username, password=self.password)

    def clean_emails(self) -> None:
        """Removes stored list of e-mails. All gathered e-mail will be seen as new ones."""
        self.emails = OrderedSet()

    def gather_new_emails(self) -> OrderedSet:
        """
        Gathers e-mails from fake server.
        Returns:
            OrderedSet of new e-mails (not fetch previously).
        """
        updated = self.parse_emails_list(self.get_file_list_from_fake_email_server())
        self.new_emails = updated - self.emails
        self.emails = updated
        return self.new_emails

    @retry(exceptions=EmailNotFoundException, tries=120, delay=5)
    def gather_new_emails_with_retry(self) -> OrderedSet:
        """
        Attempts to gather e-mails from fake server with configured number of tries with configured delay between them.
        Returns:
            OrderedSet of new e-mails (not fetch previously).
        Raises:
            AssertException if not found any new e-mails.
        """
        self.gather_new_emails()
        if len(self.new_emails) == 0:
            raise EmailNotFoundException("Not found any new emails.")
        return self.new_emails

    def get_file_list_from_fake_email_server(self) -> str:
        """
        Gets file listing from fake e-mail server.
        Returns:
            html listing of e-mail files as a string.
        """
        return self.http_client.request(HttpMethod.GET, path=self.path)

    def gather_new_emails_and_check_content(self, checks: Tuple[Callable, ...]) -> Tuple[OrderedSet, dict]:
        """
        Gathers e-mails from fake server and do the checks
        Args:
            checks: callable or tuple of callable to perform checks on received email(s)
        Returns:
            OrderedSet of new e-mails (not fetch previously) that match all checks.
        Raises:
            AssertException if not found any new e-mails.
        """
        self.gather_new_emails()
        return self.check_content_of_new_emails(checks)

    @retry(exceptions=EmailNotFoundException, tries=30, delay=5)
    def gather_new_emails_and_check_content_with_retry(self, checks: Tuple[Callable, ...]) -> Tuple[OrderedSet, dict]:
        """
        Gathers e-mails from fake server and do the checks with number of tries with configured delay between them.
        Args:
            checks: callable or tuple of callable to perform checks on received email(s)
        Returns:
            OrderedSet of new e-mails (not fetch previously) that match all checks.
        Raises:
            AssertException if not found any new e-mails.
        """
        matched, not_matched = self.gather_new_emails_and_check_content(checks)
        from inspect import getsource
        if len(matched) == 0:
            raise EmailNotFoundException("Not found any new emails that match provided checks {checks}"
                                         .format(checks=[getsource(check) for check in checks]))
        return matched, not_matched

    def check_content_of_new_emails(self, checks: Tuple[Callable, ...]) -> Tuple[OrderedSet, dict]:
        """
        Perform checks against new emails
        Args:
            checks: tuple of callable to perform checks on received email(s)
        Returns:
            tuple of:
                OrderedSet of new e-mails (not fetch previously) that match all checks.
                Dict of not matching emails with a list of check that have failed
        Raises:
            AssertException if not found any new e-mails.
        """
        matching_emails = OrderedSet()
        not_matching_emails = defaultdict(list)
        for email in self.new_emails:
            email_as_a_file = self.get_email_file(email)
            parsed_email = self.get_email(email_as_a_file)
            checked = None
            for check in checks:
                check_result = bool(check(parsed_email))
                if not check_result:
                    not_matching_emails[email].append(check)
                checked = check_result if checked is None else checked and check_result
            if checked is True:
                matching_emails.add(email)
        return matching_emails, not_matching_emails

    def get_email_file(self, email_file: Union[EmailFile, str]) -> str:
        """
        Gets single email file with e-mail.
        Args:
            email_file: file to fetch, its name or class EmailFile instance.
        Returns:
            string that contains e-mail content to parse.
        """
        file_name = email_file.name if isinstance(email_file, EmailFile) else email_file
        return self.http_client.request(HttpMethod.GET, path="{path}{file}".format(path=self.path, file=file_name))

    @staticmethod
    def get_email(email_as_a_str):
        """
        Get e-mail string parsed as email object.
        Args:
            email_as_a_str: string representation of e-mail message.

        Returns:
            parsed email with access to e-mail fields email["To"], email["Subject"], etc...
        """
        return parser.Parser().parsestr(email_as_a_str)

    @classmethod
    def parse_emails_list(cls, html_file_listing: str = None) -> OrderedSet:
        """
        Html listing of e-mail files parser. Converts listing into set of e-mails files representation,
        using class EmailFile to store its name, creation date and size.
        Args:
            html_file_listing: html formatted listing of files with e-mail messages.
        Returns:
            OrderedSet of EmailFile objects.

        """
        soup = BeautifulSoup(html_file_listing, "html.parser")
        pre = soup.find(cls.HTML_TAG_NAME_TO_STORE_EMAIL_LISTING)
        files = OrderedSet()
        children_iterator = pre.children
        try:
            for child in children_iterator:
                a_tag = child
                file_attributes = next(children_iterator)
                if a_tag.string == "../":
                    continue
                files.add(EmailFile(name=a_tag.string, file_attributes=file_attributes))
        except StopIteration:
            pass
        return files
