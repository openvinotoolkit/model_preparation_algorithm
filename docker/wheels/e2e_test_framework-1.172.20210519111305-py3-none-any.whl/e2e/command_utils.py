#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import sys
from enum import Enum
from typing import Union, List, Pattern, AnyStr, Set

import copy
import pexpect as pexpect
import re

from e2e import config
from e2e.logger import get_logger

logger = get_logger(__name__)


class LogOutput(Enum):
    TRUE = "True"
    DEFER = "Defer"
    FALSE = "False"

    def __str__(self):
        return str(self.value)

    def __enter__(self):
        global default_logger_output
        self.previous_logger_output = default_logger_output
        default_logger_output = self

    def __exit__(self, exc_type, exc_val, exc_tb):
        global default_logger_output
        default_logger_output = self.previous_logger_output
        self.previous_logger_output = None
        return False


default_logger_output = LogOutput(config.logger_output)


class Question:
    """Represents complied regexp or ExceptionPexpect that can be 'expected'."""

    def __new__(cls, value: Union[AnyStr, pexpect.ExceptionPexpect, 'Question'],
                ignore_case: bool = False, dotall: bool = True,
                multiline: bool = False) -> Union[Pattern, pexpect.ExceptionPexpect]:

        if isinstance(value, (pexpect.ExceptionPexpect, type(re.compile('')), Question)):
            return value
        elif isinstance(value, str):
            flags = 0
            if ignore_case is True:
                flags |= re.IGNORECASE
            if dotall is True:
                flags |= re.DOTALL
            if multiline is True:
                flags |= re.MULTILINE
            value = re.compile(value, flags)
            return value
        else:
            raise RuntimeError("Incorrect value type: {}, should be str, EOF, TIMEOUT, {}".format(type(value),
                                                                                                  type(re.compile(''))))


class Query:
    """
    Contains atomic Query that asks particular Question and can have response to send when Question was found.
    Also it can have follow up questions as a list of Query (class Queries)
    """
    def __init__(self, name: Union[str, None], question: Union[Question, Pattern, pexpect.ExceptionPexpect],
                 response: str = None, required: bool = True, timeout: int = -1,
                 followup_queries: Union['Query', 'Queries'] = None):
        """name of query should match matching group name in regexp"""
        self.name = name
        self.required = required
        self.question = question
        self.timeout = timeout
        self.response = response
        self.after = None
        self.before = None
        self.match = None
        self.followup_queries = followup_queries if isinstance(followup_queries, Queries)\
            else Queries(followup_queries) if isinstance(followup_queries, Query)\
            else None

    def __copy__(self):
        return Query(self.name, self.question, self.response,
                     self.required, self.timeout, copy.copy(self.followup_queries))

    def __str__(self):
        return "Query({name}, question: {question}, required: {required}, match: {match}{timeout})".format(
            name=self.name,
            question=self.question.pattern if isinstance(self.question, type(re.compile(""))) else repr(self.question),
            required=str(self.required),
            match=self.match,
            timeout=", timeout: {timeout}".format(timeout=self.timeout) if self.timeout is not None else ""
        )

    def __repr__(self):
        if self.followup_queries is not None:
            followup = ", followup: {followup}".format(followup=self.followup_queries)
        else:
            followup = ""
        return "Query({name}, question: {question}, required: {required}, match: {match}{timeout}{followup})".format(
            name=self.name,
            question=self.question.pattern if isinstance(self.question, type(re.compile(""))) else repr(self.question),
            required=str(self.required),
            match=self.match,
            timeout=", timeout: {timeout}".format(timeout=self.timeout) if self.timeout is not None else "",
            followup=followup
        )


class Queries(List[Query]):
    """
    Convenience class to store Query as a list.
    Contains set of properties to simplify access to Questions and responses of list of Query
    Calculates cumulative timeout for asking all questions.
    """

    def __init__(self, *queries: Query) -> None:
        super().__init__(queries)

    @property
    def not_matched(self) -> List[Query]:
        return [query for query in self if query is not None and query.match is None]

    @property
    def questions(self) -> List[Question]:
        return [query.question for query in self if query is not None and query.match is None]

    @property
    def responses(self) -> List[Union[str, None]]:
        return [query.response for query in self if query is not None and query.match is None]

    def timeout(self, default: int = -1):
        def key(value):
            if value is None:
                return sys.maxsize
            elif value == -1:
                return default
            else:
                return value
        timeouts = [query.timeout for query in self if query is not None and query.match is None]
        if default != -1:
            timeouts.append(default)
        return max(timeouts, key=key)

    def __copy__(self):
        return Queries(*[copy.copy(query) for query in self])

    def __str__(self):
        return "Queries(\n{}\n)".format("\n".join([str(query) for query in self]))

    def __repr__(self):
        return "Queries(\n{}\n)".format("\n".join([repr(query) for query in self]))


class Communication:
    def __init__(self, queries: Union[Query, Queries] = None, pid: int = None) -> None:
        self.queries = queries  # type: Queries
        self._pid = pid
        self.return_code = None
        self._exception = None
        self._logs = []

    def __copy__(self):
        copied = Communication(copy.copy(self.queries), self.pid)
        copied.exception = self.exception
        return copied

    def copy(self):
        return copy.copy(self)

    @property
    def pid(self) -> int:
        return self._pid

    @pid.setter
    def pid(self, pid: int):
        self._pid = pid

    @property
    def queries(self) -> Queries:
        return self._queries

    @queries.setter
    def queries(self, queries: Union[Query, Queries] = None):
        self._queries = queries if isinstance(queries, Queries) else\
            Queries(queries) if isinstance(queries, Query) else None  # type: Queries

    @property
    def query_set(self):
        queries = set(self.queries)  # type: Set[Query]
        return queries

    @property
    def exception(self) -> BaseException:
        return self._exception

    @exception.setter
    def exception(self, exception: BaseException):
        self._exception = exception

    @property
    def logs(self) -> List[str]:
        return self._logs
