import os

from datetime import datetime
now = datetime.now()

date = now.strftime("%y%m%d")
time = now.strftime("%H%M%S")

os.environ["TT_TEST_SESSION_BUILD_NUMBER"] = "{}{}".format(date, time)
print("\n******** Test Session Build number is: {} ********\n\n".format(os.environ["TT_TEST_SESSION_BUILD_NUMBER"]))

os.environ["TT_JIRA_USER"] = "michal.wilkowski@intel.com"
# os.environ["TT_JIRA_PASS"] = "N0tMAter3CtOUndyentE&E!"
os.environ["TT_JIRA_PASS"] = "K0p41in017)#"

# os.environ["TT_PROXY"] = "https://proxy-chain.intel.com:912"
os.environ["SSL_CERT_VERIFICATION"] = "False"
# os.environ["TT_FIXTURE_SELECTOR"] = "cvat"
os.environ["PYTHONHTTPSVERIFY"] = "0"
os.environ["TT_K8S_CLUSTER_INFO"] = "False"
os.environ["TT_SELENIUM_HEADLESS"] = "False"
# os.environ["TT_CLEAN_WORKFLOW_OBJECTS"] = "True"
#os.environ["TT_LOGGING_LEVEL"] = "VERBOSE"

# os.environ["TT_K8S_CLUSTER_ADMIN_CONFIG"] = "/Users/mwilkows/.kube/IMPP/coonfig.k8s"
# os.environ["TT_K8S_CLUSTER_ADMIN_CONFIG"] = "/Users/mwilkows/.kube/IMPP/mclx-42.conf"
# os.environ["TT_K8S_CLUSTER_ADMIN_CONFIG"] = "/Users/mwilkows/.kube/IMPP/mclx-41.conf"
# os.environ["TT_K8S_CLUSTER_ADMIN_CONFIG"] = "/Users/mwilkows/.kube/IMPP/jmichali.conf"
os.environ["TT_K8S_CLUSTER_ADMIN_CONFIG"] = "/Users/mwilkows/.kube/IMPP/sclab18.conf"
# os.environ["TT_K8S_CLUSTER_ADMIN_CONFIG"] = "/Users/mwilkows/.kube/IMPP/cleanup.conf"
# os.environ["TT_K8S_CLUSTER_ADMIN_CONFIG"] = "/Users/mwilkows/.kube/IMPP/page_landing.conf"
# os.environ["TT_K8S_CLUSTER_ADMIN_CONFIG"] = "/Users/mwilkows/.kube/IMPP/mwilkows-ubuntu_tiny.conf"
# os.environ["TT_K8S_CLUSTER_ADMIN_CONFIG"] = "/Users/mwilkows/.kube/IMPP/mwilkows2-ubuntu_tiny.conf"
# os.environ["TT_K8S_CLUSTER_ADMIN_CONFIG"] = "/Users/mwilkows/.kube/IMPP/prod-1.conf"
# os.environ["TT_K8S_CLUSTER_ADMIN_CONFIG"] = "/Users/mwilkows/.kube/IMPP/mclx-38.conf"
# os.environ["TT_K8S_CLUSTER_ADMIN_CONFIG"] = "/Users/mwilkows/.kube/IMPP/mclx-33.conf"
# os.environ["TT_K8S_CLUSTER_ADMIN_CONFIG"] = "/Users/mwilkows/.kube/IMPP/mclx-24.conf"
# os.environ["TT_K8S_CLUSTER_ADMIN_CONFIG"] = "/Users/mwilkows/.kube/IMPP/config.10.91.242.165.config"
#os.environ["TT_ENV_USER"] = "devuser"
os.environ["TT_ENV_USER"] = "root"
#os.environ["TT_ENV_PASS"] = "P@55wordless"
os.environ["TT_ENV_PASS"] = "Nerv@naDL1"
# os.environ["TT_K8S_CLUSTER_ADMIN_CONFIG"] = "/Users/mwilkows/.kube/k8s_sclab-testers_user_admin.k8s.config"
#os.environ["TT_ENV_IP"] = "10.91.120.159"
#os.environ["TT_ENV_DNS"] = "10.91.120.159"
#os.environ["TT_ENV_PRIV_KEY"] = "/Users/mwilkows/.ssh/nauta-clusters"
# os.environ["TT_K8S_CLUSTER_ADMIN_CONFIG"] = "/Users/mwilkows/.kube/k8s_akulakow_user_admin.k8s.config"
# os.environ["TT_K8S_CONFIG"] = "/Users/mwilkows/.kube/k8s_user.k8s.config"
# os.environ["TT_K8S_CLUSTER_ADMIN_CONFIG"] = "/Users/mwilkows/.kube/k8s_user_admin.k8s.config"
# os.environ["TT_K8S_CLUSTER_ADMIN_CONFIG"] = "/Users/mwilkows/.kube/k8s_mwilkows_endurance_user_admin.k8s.config"
# os.environ["TT_K8S_CLUSTER_ADMIN_CONFIG"] = "/Users/mwilkows/.kube/config.admin.drb0"
# os.environ["TT_K8S_CLUSTER_ADMIN_CONFIG"] = "/Users/mwilkows/.kube/k8s_drb1_user_admin.k8s.config"
# os.environ["TT_K8S_CONFIG"] = "/Users/mwilkows/.kube/k8s_mwilkows_user.k8s.config"
# os.environ["TT_K8S_CLUSTER_ADMIN_CONFIG"] = "/Users/mwilkows/.kube/k8s_mwilkows-test-stress_user_admin.k8s.config"
# os.environ["TT_K8S_CLUSTER_ADMIN_CONFIG"] = "/Users/mwilkows/.kube/k8s_mwilkows-test_user_admin.k8s.config"
# os.environ["TT_K8S_CLUSTER_ADMIN_CONFIG"] = "/Users/mwilkows/.kube/k8s_10.23.167.100.k8s.config"

# os.environ["TT_K8S_NAMESPACE"] = "mwilkows-test"


#os.environ["TT_DLSCTL_INSTALL_URL"] = "http://repository.toolbox.nervana.sclab.intel.com/releases/dlsctl/darwin/dlsctl-1.0.0-beta2-darwin.tar.gz"
#os.environ["TT_DLSCTL_INSTALL_URL"] = "http://repository.toolbox.nervana.sclab.intel.com/releases/dlsctl/linux/dlsctl-1.0.0-20190108133845-linux.tar.gz"
#os.environ["TT_DLSCTL_INSTALL_URL"] = "http://repository.toolbox.nervana.sclab.intel.com/releases/dlsctl/darwin/dlsctl-1.0.0-20180518113714-darwin.tar.gz"
#os.environ["TT_DLSCTL_INSTALL_URL"] = "http://repository.toolbox.nervana.sclab.intel.com/releases/dlsctl/linux
# /dlsctl-1.0.0-20181025085448-linux.tar.gz"
# os.environ["TT_NCTL_INSTALL_URL"] = "http://repository.toolbox.nervana.sclab.intel.com/tmp/nctl-1.0.0-mwilkows-40_min_sleep_in_version_spinner-dev-darwin.tar.gz"

#os.environ["TT_NERVANA_DOMAIN"] = "sclab.intel.com"
#os.environ["TT_HEAD_HOST"] = "mwilkows.dev.nervana"
#os.environ["TT_HEAD_HOST"] = "dm1.nervana"
#os.environ["TT_HEAD_USER"] = "root"
#os.environ["TT_ENV_DNS"] = "mwilkows-ingress.k8s.nervanasys.com"

#os.environ["TT_ADMIN_USERNAME"] = "nervana_sys"
#os.environ["TT_ADMIN_EMAIL"] = "nervana_sys@nervanasys.com"

# os.environ["TT_DISABLE_ENVIRONMENT_CHECK"] = "True"
# os.environ["TT_COLLECT_LOGSEARCH_LOGS"] = "True"
# # #os.environ["TT_NCLOUD_VERSION"] = "1.4.0"
# #os.environ["TT_NEON_VERSION"] = "1.8.1"
os.environ["TT_SMOKE_TESTS"] = "True"
os.environ["TT_RUN_REGRESSION_TESTS"] = "True"
os.environ["TT_API_OTHER_TESTS"] = "True"
os.environ["TT_GUI_OTHER_TESTS"] = "True"
os.environ["TT_GUI_REGRESSION_TESTS"] = "True"
os.environ["TT_GUI_SMOKE_TESTS"] = "True"
os.environ["TT_LONG_TESTS"] = "True"
# os.environ["TT_MANUAL_TESTS"] = "True"
#os.environ["TT_PERFORMANCE_TESTS"] = "True"


os.environ["TT_TEST_TEMP_DIR_CLEANUP"] = "False"
# os.environ["TT_TEST_STRESS_SATURABLE_EXPERIMENT_MULTIPLIER"] = "3"
# os.environ["TT_TEST_STRESS_OVERLOAD_MAX"] = "20"
# os.environ["TT_TEST_STRESS_SUBMIT_LIMIT"] = "30"
# os.environ["TT_TEST_STRESS_EPOCHS"] = "5"
# os.environ["TT_NERVANA_INFRASTRUCTURE_TYPE"] = "VIRTUAL"
# os.environ["TT_TEST_STRESS_TIMEOUT_IN_HOURS"] = "1.0"
#
# os.environ["TT_PRODUCT_INFRASTRUCTURE_TYPE"] = "VIRTUAL"
os.environ["TT_PRODUCT_INFRASTRUCTURE_TYPE"] = "BM"
os.environ["TT_DATABASE_URL"] = "mongodb://validationreports.sclab.intel.com/impt_develop_test_results"

os.environ["TT_K8S_TESTS"] = "True"

