#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

from unittest import TestCase
from e2e.command_wrappers import JournalCtl


class TestJournalCtl(TestCase):
    def test_output(self):
        assert "journalctl --priority=info"\
               == str(JournalCtl(priority=JournalCtl.Priority.INFO, add_sudo=False))
        assert "sudo journalctl --priority=info"\
               == str(JournalCtl(priority=JournalCtl.Priority.INFO))
        assert "sudo journalctl --priority=info"\
               == str(JournalCtl(unit=None, priority=JournalCtl.Priority.INFO))
        assert "sudo journalctl --unit=test-unit"\
               == str(JournalCtl(unit="test-unit"))
        assert "sudo journalctl --unit=test-unit"\
               == str(JournalCtl(unit="test-unit", priority=None))

        assert "sudo journalctl --output=verbose"\
               == str(JournalCtl(output=JournalCtl.Output.VERBOSE))
        assert "sudo journalctl --output=cat"\
               == str(JournalCtl(output=JournalCtl.Output.CAT))

        assert "sudo journalctl --priority=info --unit=test-unit --output=verbose"\
               == str(JournalCtl(unit="test-unit", priority=JournalCtl.Priority.INFO, output=JournalCtl.Output.VERBOSE))
        assert "sudo journalctl --priority=info..info --unit=test-unit --output=cat"\
               == str(JournalCtl(unit="test-unit", priority=(JournalCtl.Priority.INFO,), output=JournalCtl.Output.CAT))
        assert "sudo journalctl --priority=info..debug --unit=test-unit --output=export"\
               == str(JournalCtl(unit="test-unit", priority=(JournalCtl.Priority.INFO, JournalCtl.Priority.DEBUG),
                                 output=JournalCtl.Output.EXPORT))

        assert "sudo journalctl --since='yesterday'" == str(JournalCtl(since="yesterday"))

        assert "sudo journalctl --until='tomorrow'" == str(JournalCtl(until="tomorrow"))

    def test_get_item_as_string(self):
        assert JournalCtl.Priority["INFO"] == JournalCtl.Priority.INFO
        assert JournalCtl.Priority["ERROR"] == JournalCtl.Priority.ERROR
        assert JournalCtl.Priority["ERR"] == JournalCtl.Priority.ERR
        assert JournalCtl.Priority["WARN"] == JournalCtl.Priority.WARN
        assert JournalCtl.Priority["WARNING"] == JournalCtl.Priority.WARNING
        assert JournalCtl.Priority["EMERG"] == JournalCtl.Priority.EMERG
        assert JournalCtl.Priority["PANIC"] == JournalCtl.Priority.PANIC
