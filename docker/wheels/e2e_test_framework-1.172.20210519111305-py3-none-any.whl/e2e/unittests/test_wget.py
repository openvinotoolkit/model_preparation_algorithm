#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
from e2e.command_wrappers.wget import WGet


class TestWGet:
    def test_wget_all_in(self):
        wget = WGet(url="test.url.com",
                    no_clobber=True,
                    file="file",
                    time_stamping=True,
                    no_proxy=True,
                    ignore_case=True,
                    user="user",
                    password="password",
                    no_directories=True,
                    no_host_directories=True,
                    directory_prefix="prefix",
                    cut_dirs=5,
                    content_on_error=True,
                    no_check_certificate=True,
                    recursive=True,
                    level=6,
                    mirror=True,
                    accept=["accept", "list"],
                    reject="one_reject_dir",
                    accept_regexp="acc*pt_rege?p",
                    reject_regexp="r.*ct_rege?p",
                    include_dirs=["dirs", "to", "include"],
                    exclude_dirs=["dirs", "to", "exclude"],
                    no_parent=True)
        w_get = " ".join(wget)
        assert w_get == "wget --no-clobber -O file --timestamping --no-proxy " \
                        "--ignore-case --user=user --password=password "\
                        "--directory-prefix=prefix --no-host-directories " \
                        "--no-directories --cut-dirs=5 --content-on-error "\
                        "--no-check-certificate -r --level=6 --mirror --accept=accept,list --reject=one_reject_dir "\
                        "--accept-regex=acc*pt_rege?p --reject-regex=r.*ct_rege?p " \
                        "--include-directories=dirs,to,include "\
                        "--exclude-directories=dirs,to,exclude --no-parent test.url.com"
