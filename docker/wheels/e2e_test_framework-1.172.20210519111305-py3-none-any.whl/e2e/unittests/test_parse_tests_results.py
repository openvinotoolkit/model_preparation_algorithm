#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
from bson import ObjectId
from datetime import datetime
import mongomock
import pytest
try:
    import mock
except ImportError:
    from unittest import mock

from e2e import config
from e2e.current_os_info import CurrentOsInfo
from e2e.environment_info import EnvironmentInfo
from e2e.markers.run_type import MarkRunType
from e2e.mongo_reporter._client import DBClient
from e2e.mongo_reporter.run_reporter import RunReporter
from e2e.parse_tests_results import parse_test_run, parse_test_results, parse_date, date_format, \
    default_docstring, default_priority, save_to_database, update_test_results


ENVIRONMENT = "test-env"
START_DATE_STR = "2020-05-05 16:13:43.515805"
START_DATE_PARSED = datetime(2020, 5, 5, 16, 13, 43, 515805)
END_DATE_STR = "2020-05-05 16:14:19.520100"
TEST_TYPE = MarkRunType.TEST_MARK_ON_COMMIT
COMPONENT_LIST = ["Component A", "Component B"]


def get_test_step_content(step: str, details: dict = None):
    test_step_dict = dict()
    if details:
        test_step_dict["outcome"] = details["outcome"]
        test_step_dict["name"] = details["name"]
        test_step_dict["duration"] = details["duration"]
        test_step_dict["longrepr"] = details["longrepr"]
        test_step_dict["log"] = details.get("log", None)
    else:
        test_step_dict["outcome"] = "passed"
        test_step_dict["name"] = step
        test_step_dict["duration"] = 1.3677434921264649
    return test_step_dict


def get_test_content(status: str, name: str, duration: float, run_index: int, setup_details: dict = None,
                     call_details: dict = None):
    test_dict = dict()
    test_dict["outcome"] = status
    test_dict["name"] = name
    test_dict["setup"] = get_test_step_content("setup", setup_details)
    test_dict["call"] = get_test_step_content("call", call_details)
    if status == "error":
        del test_dict["call"]
    test_dict["teardown"] = get_test_step_content("teardown")
    test_dict["duration"] = duration
    test_dict["run_index"] = run_index
    return test_dict


def assert_test_parsed(parsed_test, test):
    assert parsed_test["components"] == COMPONENT_LIST
    assert parsed_test["docstring"] == default_docstring
    assert parsed_test["duration"] == test["duration"]
    assert parsed_test["end_date"] == test["end_date"]
    assert parsed_test["logs"] == test["logs"]
    assert parsed_test["name"] == test["name"]
    assert parsed_test["priority"] == default_priority
    assert parsed_test["reqids"] == []
    assert test["stacktrace"] in parsed_test["stacktrace"]
    assert parsed_test["status"] == test["status"]
    assert parsed_test["order"] == test["order"]
    assert parsed_test["start_date"] == datetime.strptime(START_DATE_STR, date_format)
    assert parsed_test["test_type"] == MarkRunType.test_mark_to_test_run_type(TEST_TYPE)


SUMMARY_DICT = {
                "num_tests": 6,
                "failed": 2,
                "skipped": 2,
                "passed": 1,
                "error": 1,
                "duration": 36.004294633865359
            }

ENVIRONMENT_DICT = {
            "Platform": "Linux-4.4.0-31-generic-x86_64-with-Ubuntu-16.04-xenial",
            "Python": "3.5.2"
        }

TEST_PASSED = get_test_content(
    status="passed",
    name="tests/functional/test_batching.py::TestBatchModelInference::()::test_run_inference",
    duration=22.588816165924074,
    run_index=0)

TEST_NOT_IMPLEMENTED = get_test_content(
    status="skipped",
    name="tests/functional/test_reshaping.py::TestModelReshaping::()::"
         "test_single_local_model_reshaping_fixed_rest[column_name-shape0-True]",
    duration=0.0008215904235839844,
    run_index=59,
    setup_details={
        "outcome": "skipped",
        "longrepr": "('tests/functional/test_reshaping.py', 101, 'Skipped: not implemented yet')",
        "name": "setup",
        "duration": 0.00020241737365722656
    })

TEST_SKIPPED = get_test_content(
    status="skipped",
    name="tests/functional/test_reshaping.py::TestModelReshaping::()::"
         "test_single_local_model_reshaping_fixed_rest[row_name-shape0-True]",
    duration=0.0008215904235839844,
    run_index=58,
    setup_details={
        "outcome": "skipped",
        "longrepr": "('tests/functional/test_reshaping.py', 101, 'Skipped: other reason')",
        "name": "setup",
        "duration": 0.00020241737365722656
    })

TEST_FAILED_NO_LOGS = get_test_content(
    status="failed",
    name="tests/functional/test_batching.py::TestBatchModelInference::()::test_run_inference_bs4",
    duration=16.86748719215393,
    run_index=1,
    call_details={
        "outcome": "failed",
        "longrepr": "self = <test_batching.TestBatchModelInference object at 0x7f109c4b0f28>\n"
                    "resnet_multiple_batch_sizes = (('/tmp/ovms_models/saved_models/resnet_V1_50/1/"
                    "resnet_V1_50.bin', '/tmp/ovms_models/saved_models/resnet_V1_50/1/resne...1_50_batch8/1/"
                    "resnet_V1_50_batch8.bin', '/tmp/ovms_models/saved_models/resnet_V1_50_batch8/1/"
                    "resnet_V1_50_batch8.xml'))\nstart_server_batch_model_bs4 = (<Container: 568ec3efc5>, "
                    "{'grpc_port': '9016', 'rest_port': '5516'})\ncreate_grpc_channel = "
                    "<function create_grpc_channel.<locals>._create_channel at 0x7f109c350598>\n\n    "
                    "def test_run_inference_bs4(self, resnet_multiple_batch_sizes,\n                               "
                    "start_server_batch_model_bs4,\n                               "
                    "create_grpc_channel):\n    \n        _, ports = start_server_batch_model_bs4\n        "
                    "print(\"Downloaded model files:\", resnet_multiple_batch_sizes)\n    \n        "
                    "# Connect to grpc service\n        stub = create_grpc_channel('localhost:{}'"
                    ".format(ports[\"grpc_port\"]),\n                                   "
                    "PREDICTION_SERVICE)\n    \n        batch_input = np.ones((4, 3, 224, 224), "
                    "np.float32)\n        in_name = 'map/TensorArrayStack/TensorArrayGatherV3'\n        "
                    "out_name = 'softmax_tensor'\n        output = infer(batch_input, "
                    "input_tensor=in_name,\n                       grpc_stub=stub, "
                    "model_spec_name='resnet',\n                       "
                    "model_spec_version=None,\n>                      "
                    "output_tensors=[out_name])\n\ntests/functional/test_batching.py:80: \n"
                    "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ "
                    "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ "
                    "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _\ntests/functional/utils/grpc.py:31: in infer\n    "
                    "result = grpc_stub.Predict(request, 10.0)\n.venv/lib/python3.5/site-packages/grpc/_channel.py"
                    ":604: in __call__\n    return _end_unary_response_blocking(state, call, False, None)\n"
                    "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ "
                    "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ "
                    "_ _ _ _ _ _ _ _ _ _\n\nstate = <grpc._channel._RPCState object at 0x7f109c3b2f28>, "
                    "call = <grpc._cython.cygrpc.SegregatedCall object at 0x7f109c3e2e08>, with_call = False, "
                    "deadline = None\n\n    def _end_unary_response_blocking(state, call, with_call, deadline):\n"
                    "        if state.code is grpc.StatusCode.OK:\n            if with_call:\n                "
                    "rendezvous = _Rendezvous(state, call, None, deadline)\n                return "
                    "state.response, rendezvous\n            else:\n                return state.response\n        "
                    "else:\n>           raise _Rendezvous(state, None, None, deadline)\nE           "
                    "grpc._channel._Rendezvous: <_Rendezvous of RPC that terminated with:\nE           \t"
                    "status = StatusCode.INVALID_ARGUMENT\nE           \tdetails = \"Invalid input shape\"\n"
                    "E           \tdebug_error_string = \"{\"created\":\"@1587651208.320907851\",\"description\":\""
                    "Error received from peer ipv6:[::1]:9016\",\"file\":\"src/core/lib/surface/call.cc\",\""
                    "file_line\":1055,\"grpc_message\":\"Invalid input shape\",\"grpc_status\":3}\"\n"
                    "E           >\n\n.venv/lib/python3.5/site-packages/grpc/_channel.py:506: _Rendezvous",
        "name": "call",
        "duration": 0.07700085639953613
    })

TEST_ERROR = get_test_content(
    status="error",
    name="tests/functional/test_multi_models.py::TestMultiModelInference::()::test_run_inference",
    duration=15.61942172050476,
    run_index=42,
    setup_details={
        "name": "setup",
        "duration": 7.809592008590698,
        "outcome": "error",
        "longrepr": "request = <SubRequest 'get_minio_server_s3' for <Function 'test_run_inference'>>\n"
                    "get_image = 'cpp-experiments:2e74fbcb9091a603f56dc89f82cee3c5b4098223'\nget_test_dir = "
                    "'/tmp/ovms_models'\nstart_minio_server = (<Container: abd0cb9783>, {'grpc_port': '9002', "
                    "'rest_port': '5502'})\n\n    @pytest.fixture(scope=\"session\")\n    "
                    "def get_minio_server_s3(request, get_image, get_test_dir, start_minio_server):\n    \n        "
                    "path_to_mount = get_test_dir + '/saved_models/resnet_V1_50/1'\n        "
                    "input_bin = os.path.join(path_to_mount, 'resnet_V1_50.bin')\n        input_xml = "
                    "os.path.join(path_to_mount, 'resnet_V1_50.xml')\n    \n        MINIO_ACCESS_KEY = os.getenv("
                    "'MINIO_ACCESS_KEY')\n        MINIO_SECRET_KEY = os.getenv('MINIO_SECRET_KEY')\n        "
                    "AWS_REGION = os.getenv('AWS_REGION')\n    \n        if AWS_REGION is None:\n            "
                    "AWS_REGION = \"eu-central-1\"\n            os.environ[\"AWS_REGION\"] = AWS_REGION\n    \n"
                    "        if MINIO_ACCESS_KEY is None or MINIO_SECRET_KEY is None:\n            "
                    "MINIO_ACCESS_KEY = \"MINIO_A_KEY\"\n            MINIO_SECRET_KEY = \"MINIO_S_KEY\"\n"
                    "            os.environ[\"MINIO_ACCESS_KEY\"] = MINIO_ACCESS_KEY\n            "
                    "os.environ[\"MINIO_SECRET_KEY\"] = MINIO_SECRET_KEY\n    \n        _, "
                    "ports = start_minio_server\n        s3 = boto3.resource('s3',\n                            "
                    "endpoint_url='http://localhost:{}'.format(\n                                "
                    "ports[\"grpc_port\"]),\n                            aws_access_key_id=os.getenv("
                    "'MINIO_ACCESS_KEY'),\n                            aws_secret_access_key=os.getenv("
                    "'MINIO_SECRET_KEY'),\n                            config=Config(signature_version='s3v4'),\n"
                    "                            region_name=AWS_REGION)\n    \n        bucket_conf = "
                    "{'LocationConstraint': AWS_REGION}\n    \n        s3.create_bucket(Bucket='inference',\n>"
                    "                        CreateBucketConfiguration=bucket_conf)\n\n"
                    "tests/functional/fixtures/server_remote_models_fixtures.py:195: \n"
                    "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ \n"
                    ".venv/lib/python3.6/site-packages/boto3/resources/factory.py:520: in do_action\n    "
                    "response = action(self, *args, **kwargs)\n.venv/lib/python3.6/site-packages/boto3/resources/"
                    "action.py:83: in __call__\n    response = getattr(parent.meta.client, operation_name)"
                    "(**params)\n.venv/lib/python3.6/site-packages/botocore/client.py:276: in _api_call\n    "
                    "return self._make_api_call(operation_name, kwargs)\n"
                    "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ \n\n"
                    "self = <botocore.client.S3 object at 0x7f0f055ecb00>\noperation_name = 'CreateBucket'\n"
                    "api_params = {'Bucket': 'inference', 'CreateBucketConfiguration': {'LocationConstraint': "
                    "'eu-central-1'}}\n\n    def _make_api_call(self, operation_name, api_params):\n        "
                    "operation_model = self._service_model.operation_model(operation_name)\n        service_name = "
                    "self._service_model.service_name\n        history_recorder.record('API_CALL', {\n            "
                    "'service': service_name,\n            'operation': operation_name,\n            "
                    "'params': api_params,\n        })\n        if operation_model.deprecated:\n            "
                    "logger.debug('Warning: %s.%s() is deprecated',\n                         "
                    "service_name, operation_name)\n        request_context = {\n            'client_region': "
                    "self.meta.region_name,\n            'client_config': self.meta.config,\n            "
                    "'has_streaming_input': operation_model.has_streaming_input,\n            'auth_type': "
                    "operation_model.auth_type,\n        }\n        request_dict = self._convert_to_request_dict(\n"
                    "            api_params, operation_model, context=request_context)\n    \n        service_id = "
                    "self._service_model.service_id.hyphenize()\n        handler, event_response = "
                    "self.meta.events.emit_until_response(\n            'before-call.{service_id}.{operation_name}'"
                    ".format(\n                service_id=service_id,\n                operation_name="
                    "operation_name),\n            model=operation_model, params=request_dict,\n            "
                    "request_signer=self._request_signer, context=request_context)\n    \n        "
                    "if event_response is not None:\n            http, parsed_response = event_response\n        "
                    "else:\n            http, parsed_response = self._make_request(\n                "
                    "operation_model, request_dict, request_context)\n    \n        self.meta.events.emit(\n"
                    "            'after-call.{service_id}.{operation_name}'.format(\n                "
                    "service_id=service_id,\n                operation_name=operation_name),\n            "
                    "http_response=http, parsed=parsed_response,\n            model=operation_model, "
                    "context=request_context\n        )\n    \n        if http.status_code >= 300:\n            "
                    "error_code = parsed_response.get(\"Error\", {}).get(\"Code\")\n            error_class = "
                    "self.exceptions.from_code(error_code)\n>           raise error_class(parsed_response, "
                    "operation_name)\nE           botocore.exceptions.ClientError: An error occurred (403) when "
                    "calling the CreateBucket operation: Forbidden\n\n"
                    ".venv/lib/python3.6/site-packages/botocore/client.py:586: ClientError"
    })

TEST_FAILED_WITH_LOGS = get_test_content(
    status="failed",
    name="tests/functional/test_batching.py::TestBatchModelInference::()::test_run_inference_auto",
    duration=19.781059503555299,
    run_index=0,
    call_details={
        "name": "call",
        "outcome": "failed",
        "log": "test_batching.py            65 ERROR    response has invalid output",
        "duration": 1.3711514472961426,
        "longrepr": "self = <test_batching.TestBatchModelInference object at 0x7f13e0753940>\n"
                    "resnet_multiple_batch_sizes = (('/tmp/ovms_models/saved_models/resnet_V1_50/1/"
                    "resnet_V1_50.bin', '/tmp/ovms_models/saved_models/resnet_V1_50/1/"
                    "resne...1_50_batch8/1/resnet_V1_50_batch8.bin', '/tmp/ovms_models/saved_models/"
                    "resnet_V1_50_batch8/1/resnet_V1_50_batch8.xml'))\nstart_server_batch_model = "
                    "(<Container: 39a1d703aa>, {'grpc_port': '9000', 'rest_port': '5500'})\n"
                    "create_grpc_channel = <function create_grpc_channel.<locals>._create_channel at "
                    "0x7f13e06780d0>\n\n    def test_run_inference(self, resnet_multiple_batch_sizes,\n"
                    "                           start_server_batch_model,\n                           "
                    "create_grpc_channel):\n        \"\"\"\n            <b>Description</b>\n"
                    "            Submit request to gRPC interface serving a single resnet model\n    \n"
                    "            <b>input data</b>\n            - directory with the model in IR"
                    " format\n            - docker image with ie-serving-py service\n    \n            "
                    "<b>fixtures used</b>\n            - model downloader\n            - service "
                    "launching\n    \n            <b>Expected results</b>\n            - response "
                    "contains proper numpy shape\n    \n            \"\"\"\n    \n        _, "
                    "ports = start_server_batch_model\n        print(\"Downloaded model files:\", "
                    "resnet_multiple_batch_sizes)\n    \n        # Connect to grpc service\n        "
                    "stub = create_grpc_channel('localhost:{}'.format(ports[\"grpc_port\"]),\n"
                    "                                   PREDICTION_SERVICE)\n    \n        "
                    "batch_input = np.ones((8, 3, 224, 224), np.float32)\n        in_name = "
                    "'map/TensorArrayStack/TensorArrayGatherV3'\n        out_name = 'softmax_tensor'\n"
                    "        output = infer(batch_input, input_tensor=in_name,\n                       "
                    "grpc_stub=stub, model_spec_name='resnet',\n                       "
                    "model_spec_version=None,\n                       output_tensors=[out_name])\n"
                    "        print(\"output shape\", output[out_name].shape)\n        "
                    "# LOGGER.error('!!! error')\n>       assert output[out_name].shape == (1118, "
                    "1001), LOGGER.error(ERROR_SHAPE)\nE       AssertionError: None\nE       assert "
                    "(8, 1001) == (1118, 1001)\nE         At index 0 diff: 8 != 1118\nE         Use -v"
                    " to get the full diff\n\ntests/functional/test_batching.py:65: AssertionError"
                })

TEST_COUNT = 6
TEST_RESULTS = {
    "report": {
        "summary": SUMMARY_DICT,
        "environment": ENVIRONMENT_DICT,
        "created_at": START_DATE_STR,
        "tests": [TEST_PASSED, TEST_NOT_IMPLEMENTED, TEST_SKIPPED, TEST_FAILED_NO_LOGS, TEST_ERROR,
                  TEST_FAILED_WITH_LOGS]
    }
}

TEST_PASSED_OUTPUT = {
    "duration": 22.588816165924072,
    "end_date": datetime.strptime("2020-05-05 16:14:06.104621", date_format),
    "name": "tests/functional/test_batching.py::TestBatchModelInference::()::"
            "test_run_inference",
    "status": "PASS",
    "logs": "",
    "stacktrace": "",
    "order": 0}

TEST_NOT_IMPLEMENTED_OUTPUT = {
    "duration": 0.0008215904235839844,
    "end_date": datetime.strptime("2020-05-05 16:13:43.516627", date_format),
    "name": "tests/functional/test_reshaping.py::TestModelReshaping::()::"
            "test_single_local_model_reshaping_fixed_rest[column_name-shape0-True]",
    "status": "NOT_IMPLEMENTED",
    "logs": "",
    "stacktrace": "",
    "order": 59}

TEST_SKIPPED_OUTPUT = {
    "duration": 0.0008215904235839844,
    "end_date": datetime.strptime("2020-05-05 16:13:43.516627", date_format),
    "name": "tests/functional/test_reshaping.py::TestModelReshaping::()::"
            "test_single_local_model_reshaping_fixed_rest[row_name-shape0-True]",
    "status": "SKIPPED",
    "logs": "",
    "stacktrace": "",
    "order": 58}

TEST_FAILED_NO_LOGS_OUTPUT = {
    "duration": 16.86748719215393,
    "end_date": datetime.strptime("2020-05-05 16:14:00.383292", date_format),
    "name": "tests/functional/test_batching.py::TestBatchModelInference::()::"
            "test_run_inference_bs4",
    "status": "FAIL",
    "logs": "",
    "stacktrace": "Invalid input shape",
    "order": 1}

TEST_ERROR_OUTPUT = {
    "duration": 15.61942172050476,
    "end_date": datetime.strptime("2020-05-05 16:13:59.135227", date_format),
    "name": "tests/functional/test_multi_models.py::TestMultiModelInference::()::"
            "test_run_inference: setup error",
    "status": "FAIL",
    "logs": "",
    "stacktrace": "An error occurred (403)",
    "order": 42}

TEST_FAILED_WITH_LOGS_OUTPUT = {
    "duration": 19.781059503555298,
    "end_date": datetime.strptime("2020-05-05 16:14:03.296865", date_format),
    "name": "tests/functional/test_batching.py::TestBatchModelInference::()::"
            "test_run_inference_auto",
    "status": "FAIL",
    "logs": "test_batching.py            65 ERROR    response has invalid output",
    "stacktrace": "AssertionError",
    "order": 0}


class TestParseTestsResults(object):
    test_run_id = ObjectId()

    @pytest.fixture(scope="function")
    def mock_db_client(self):
        class MockClient(DBClient):
            def __init__(self, *args, **kwargs):
                self.database = mongomock.MongoClient().db
        return MockClient

    def test_parse_tests_results(self):
        parsed_results = parse_test_run(TEST_RESULTS)
        assert parsed_results["start_date"] == datetime.strptime(START_DATE_STR, date_format)
        assert parsed_results["end_date"] == datetime.strptime(END_DATE_STR, date_format)
        assert parsed_results["test_count"] == TEST_COUNT
        assert parsed_results["total_test_count"] == TEST_COUNT
        assert parsed_results["finished"]

    @mock.patch("e2e.mongo_reporter.run_reporter.config.database_url", "test_uri")
    def test_save_to_database(self, mock_db_client):
        with mock.patch("e2e.mongo_reporter.base_reporter.DBClient", mock_db_client):
            parsed_results = parse_test_run(TEST_RESULTS)
            reporter = RunReporter(document_id=self.test_run_id, environment=ENVIRONMENT)
            test_run_document = save_to_database(parsed_results=parsed_results, reporter=reporter,
                                                 test_type=TEST_TYPE, components_list=COMPONENT_LIST)
            assert test_run_document["test_type"] == MarkRunType.test_mark_to_test_run_type(TEST_TYPE)
            assert test_run_document["start_date"] == datetime.strptime(START_DATE_STR, date_format)
            assert test_run_document["end_date"] == datetime.strptime(END_DATE_STR, date_format)
            assert test_run_document["total_test_count"] == TEST_COUNT
            assert test_run_document["test_session_build_number"] == config.test_session_build_number
            assert test_run_document["components"].sort() == COMPONENT_LIST.sort()
            assert test_run_document["test_session_build_number"] == config.test_session_build_number
            assert test_run_document["product_build_number"] == EnvironmentInfo.get_build_number()
            assert test_run_document["environment_version"] == EnvironmentInfo.get_version_number()
            assert test_run_document["system"] == CurrentOsInfo.get_os_distname()

    def test_parse_passed_test_results(self):
        reporter = RunReporter(document_id=self.test_run_id, environment=ENVIRONMENT)
        parsed_test = parse_test_results(TEST_PASSED, reporter, START_DATE_PARSED,
                                         test_type=TEST_TYPE, components_list=COMPONENT_LIST)
        assert_test_parsed(parsed_test, TEST_PASSED_OUTPUT)

    def test_parse_not_implemented_test_results(self):
        reporter = RunReporter(document_id=self.test_run_id, environment=ENVIRONMENT)
        parsed_test = parse_test_results(TEST_NOT_IMPLEMENTED, reporter, START_DATE_PARSED,
                                         test_type=TEST_TYPE, components_list=COMPONENT_LIST)
        assert_test_parsed(parsed_test, TEST_NOT_IMPLEMENTED_OUTPUT)

    def test_parse_skipped_test_results(self):
        reporter = RunReporter(document_id=self.test_run_id, environment=ENVIRONMENT)
        parsed_test = parse_test_results(TEST_SKIPPED, reporter, START_DATE_PARSED,
                                         test_type=TEST_TYPE, components_list=COMPONENT_LIST)
        assert_test_parsed(parsed_test, TEST_SKIPPED_OUTPUT)

    def test_parse_failed_no_logs_test_results(self):
        reporter = RunReporter(document_id=self.test_run_id, environment=ENVIRONMENT)
        parsed_test = parse_test_results(TEST_FAILED_NO_LOGS, reporter, START_DATE_PARSED,
                                         test_type=TEST_TYPE, components_list=COMPONENT_LIST)
        assert_test_parsed(parsed_test, TEST_FAILED_NO_LOGS_OUTPUT)

    def test_parse_error_test_results(self):
        reporter = RunReporter(document_id=self.test_run_id, environment=ENVIRONMENT)
        parsed_test = parse_test_results(TEST_ERROR, reporter, START_DATE_PARSED,
                                         test_type=TEST_TYPE, components_list=COMPONENT_LIST)
        assert_test_parsed(parsed_test, TEST_ERROR_OUTPUT)

    def test_parse_failed_with_logs_test_results(self):
        reporter = RunReporter(document_id=self.test_run_id, environment=ENVIRONMENT)
        parsed_test = parse_test_results(TEST_FAILED_WITH_LOGS, reporter, START_DATE_PARSED,
                                         test_type=TEST_TYPE, components_list=COMPONENT_LIST)
        assert_test_parsed(parsed_test, TEST_FAILED_WITH_LOGS_OUTPUT)

    def test_parse_date(self):
        assert START_DATE_PARSED == parse_date(START_DATE_STR)

    @mock.patch("e2e.mongo_reporter.run_reporter.config.database_url", "test_uri")
    def test_update_test_results(self, mock_db_client):
        with mock.patch("e2e.mongo_reporter.base_reporter.DBClient", mock_db_client):
            reporter = RunReporter(document_id=self.test_run_id, environment=ENVIRONMENT)
            parsed_test = parse_test_results(TEST_PASSED, reporter, START_DATE_PARSED,
                                             test_type=TEST_TYPE, components_list=COMPONENT_LIST)
            assert_test_parsed(parsed_test, TEST_PASSED_OUTPUT)
            update_test_results(document=parsed_test, reporter=reporter)
