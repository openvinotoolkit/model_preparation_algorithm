#
# INTEL CONFIDENTIAL
# Copyright (c) 2021 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
try:
    import mock
except ImportError:
    from unittest import mock

from e2e.logger import step
from e2e.assertions import assert_raises_exception
from e2e.docker_subnet_manager import DockerSubnetManager

SUBNET_POOL_ZERO = 0
SUBNET_POOL = 1
SUBNET_POOL_MORE = 5
SUBNET_POOL_256 = 256

EXPECTED_SUBNET_EMPTY_RESERVED_LIST = ["172.28.0.0/24"]
EXPECTED_SUBNET_RESERVED_SUBNET = ["172.28.1.0/24"]
EXPECTED_SUBNET_RESERVED_SUBNET_MORE = ["172.28.3.0/24"]

MOCK_RESERVED_SUBNETS_EMPTY = []
MOCK_RESERVED_SUBNETS = ["172.28.0.0/24"]
MOCK_RESERVED_SUBNETS_MORE = ["172.28.0.0/24", "172.28.1.0/24", "172.28.2.0/24"]

RELEASED_SUBNET = "172.28.1.0/24"


class NetworkMock:
    def __init__(self, subnet, name):
        self.short_id = name
        self.attrs = {
            "IPAM": {
                "Config": [
                    {
                        "Subnet": subnet
                    }
                ]}
        }


class NetworkCollectionMock:
    def __init__(self, list_of_subnets):
        self.list_of_subnets = list_of_subnets

    def list(self):
        return [NetworkMock(subnet, subnet) for subnet in self.list_of_subnets]


class APIMock:
    def __init__(self, mock_list_of_subnets):
        self.mock_list_of_subnets = mock_list_of_subnets

    def remove_network(self, short_id):
        subnet = next(filter(lambda s: s.short_id == short_id, self.mock_list_of_subnets), None)
        if subnet is not None:
            self.mock_list_of_subnets.remove(subnet)
        else:
            raise Exception(f"Network {short_id} not found")


class DockerClientMock:
    def __init__(self, list_of_subnets):
        self.list_of_subnets = list_of_subnets
        self.networks = NetworkCollectionMock(self.list_of_subnets)
        self.api = APIMock(self.networks.list())


class TestDockerSubnetManager:

    @mock.patch("e2e.docker_subnet_manager.DockerClient",
                mock.Mock(return_value=DockerClientMock(MOCK_RESERVED_SUBNETS_EMPTY)))
    def test_subnet_manager_get_subnet_when_reserved_subnet_empty_lists(self):
        step('Testing if docker subnet manager get subnet properly when reserved subnet empty list.')
        manager = DockerSubnetManager(subnet_pool=SUBNET_POOL)
        subnet = manager.get_subnet()
        assert type(subnet) is str, \
            f"Not expected type found. \n Expected: {str}, found: {type(subnet)}."
        assert subnet in EXPECTED_SUBNET_EMPTY_RESERVED_LIST, \
            f"Not expected subnet generated. \n Expected: {EXPECTED_SUBNET_EMPTY_RESERVED_LIST}, got: {subnet}."
        manager.reserved_subnet.remove(subnet)

    @mock.patch("e2e.docker_subnet_manager.DockerClient",
                mock.Mock(return_value=DockerClientMock(MOCK_RESERVED_SUBNETS)))
    def test_subnet_manager_get_subnet_when_reserved_subnet(self):
        step('Testing if docker subnet manager get subnet properly when reserved one subnet.')
        manager = DockerSubnetManager(subnet_pool=SUBNET_POOL_MORE)
        subnet = manager.get_subnet()
        assert type(subnet) is str, \
            f"Not expected type found. \n Expected: {str}, found: {type(subnet)}."
        assert subnet in EXPECTED_SUBNET_RESERVED_SUBNET, \
            f"Not expected subnet generated. \n Expected: {EXPECTED_SUBNET_RESERVED_SUBNET}, got: {subnet}."

    @mock.patch("e2e.docker_subnet_manager.DockerClient",
                mock.Mock(return_value=DockerClientMock(MOCK_RESERVED_SUBNETS_MORE)))
    def test_subnet_manager_get_subnet_when_more_reserved_subnet(self):
        step('Testing if docker subnet manager get subnet properly when reserved more than one subnet.')
        manager = DockerSubnetManager(subnet_pool=SUBNET_POOL_MORE)
        subnet = manager.get_subnet()
        assert type(subnet) is str, \
            f"Not expected type found. \n Expected: {str}, found: {type(subnet)}."
        assert subnet in EXPECTED_SUBNET_RESERVED_SUBNET_MORE, \
            f"Not expected subnet generated. \n Expected: {EXPECTED_SUBNET_RESERVED_SUBNET_MORE}, got: {subnet}."

    @mock.patch("e2e.docker_subnet_manager.DockerClient",
                mock.Mock(return_value=DockerClientMock(MOCK_RESERVED_SUBNETS_EMPTY)))
    def test_subnet_manager_get_more_subnets(self):
        step('Testing if docker subnet manager has correct number of subnets when getting subnets.')
        subnets = []
        manager = DockerSubnetManager(subnet_pool=SUBNET_POOL_MORE)
        for num in range(SUBNET_POOL_MORE):
            subnet = manager.get_subnet()
            subnets.append(subnet)
        assert len(subnets) == SUBNET_POOL_MORE, \
            f"Not expected subnet length. \n Expected: {SUBNET_POOL_MORE}, got: {len(subnets)}."

        for subnet in MOCK_RESERVED_SUBNETS_EMPTY[:]:
            manager.reserved_subnet.remove(subnet)

    @mock.patch("e2e.docker_subnet_manager.DockerClient",
                mock.Mock(return_value=DockerClientMock(MOCK_RESERVED_SUBNETS_EMPTY)))
    def test_method_created_pool_size(self):
        step('Testing if docker subnet manager has correct length when creating pool size.')
        manager = DockerSubnetManager(subnet_pool=SUBNET_POOL_MORE)
        list_length = len(manager.define_range_of_allowed_subnets())
        assert list_length == SUBNET_POOL_MORE, \
            f"Not expected subnet length. \n Expected: {SUBNET_POOL_MORE}, got: {list_length}."

    @mock.patch("e2e.docker_subnet_manager.DockerClient",
                mock.Mock(return_value=DockerClientMock(MOCK_RESERVED_SUBNETS_MORE)))
    def test_method_docker_reserved_subnet_list(self):
        step('Testing if docker subnet manager has correct length of reserved subnet list.')
        manager = DockerSubnetManager(subnet_pool=SUBNET_POOL_MORE)
        list_length = len(manager.docker_reserved_subnet_list())
        mocked_reserved_subnet_list = len(MOCK_RESERVED_SUBNETS_MORE)
        assert list_length == mocked_reserved_subnet_list, \
            f"Not expected subnet length. \n Expected: {mocked_reserved_subnet_list}, got: {list_length}."

    @mock.patch("e2e.docker_subnet_manager.DockerClient",
                mock.Mock(return_value=DockerClientMock(MOCK_RESERVED_SUBNETS_EMPTY)))
    def test_subnet_manager_wrong_pool_size_zero(self):
        step('Testing if subnet manager report about wrong pool size.')
        assert_raises_exception(output=f"Not expected subnet_range size given for manager "
                                       f"{SUBNET_POOL_ZERO}, should be > 0.",
                                       callable_obj=DockerSubnetManager, exception=AssertionError,
                                       subnet_pool=SUBNET_POOL_ZERO)

    @mock.patch("e2e.docker_subnet_manager.DockerClient",
                mock.Mock(return_value=DockerClientMock(MOCK_RESERVED_SUBNETS_EMPTY)))
    def test_subnet_manager_wrong_pool_size_256(self):
        step('Testing if subnet manager report about wrong pool size.')
        assert_raises_exception(output=f"Not expected subnet_range size given for manager "
                                       f"{SUBNET_POOL_256}, should be <= 255",
                                       callable_obj=DockerSubnetManager, exception=AssertionError,
                                       subnet_pool=SUBNET_POOL_256)

    @mock.patch("e2e.docker_subnet_manager.DockerClient",
                mock.Mock(return_value=DockerClientMock(MOCK_RESERVED_SUBNETS)))
    def test_subnet_manager_overlaps_pool_size(self):
        step('Testing if subnet manager report about wrong pool size.')
        manager = DockerSubnetManager(subnet_pool=SUBNET_POOL)
        assert_raises_exception(output=f"Subnet pool {SUBNET_POOL} has been used up. "
                                       f"Consider release subnet or increase pool size.",
                                       callable_obj=manager.get_subnet, exception=Exception)

    @mock.patch("e2e.docker_subnet_manager.DockerClient",
                mock.Mock(return_value=DockerClientMock(MOCK_RESERVED_SUBNETS_MORE)))
    def test_method_release_subnet_from_reserved_subnet_list(self):
        step('Testing if docker subnet manager release subnet method has correct behaviour')
        manager = DockerSubnetManager(subnet_pool=SUBNET_POOL_MORE)
        for subnet in manager.reserved_subnet[:]:
            manager.release_subnet(subnet)
        assert manager.reserved_subnet == MOCK_RESERVED_SUBNETS_EMPTY, \
            f"Not expected len of reserved subnet. " \
            f"\n Expected: {MOCK_RESERVED_SUBNETS_EMPTY}, got: {manager.reserved_subnet}."

    @mock.patch("e2e.docker_subnet_manager.DockerClient",
                mock.Mock(return_value=DockerClientMock(MOCK_RESERVED_SUBNETS)))
    def test_method_release_subnet_when_subnet_not_on_the_list(self):
        step('Testing if subnet manager report about wrong pool size.')
        manager = DockerSubnetManager(subnet_pool=SUBNET_POOL_MORE)
        assert_raises_exception(output=f"Subnet {RELEASED_SUBNET} not in reserved subnet list:"
                                       f"{manager.reserved_subnet}, choose another subnet to release",
                                callable_obj=manager.release_subnet, subnet=RELEASED_SUBNET, exception=Exception)

    @mock.patch("e2e.docker_subnet_manager.DockerClient",
                mock.Mock(return_value=DockerClientMock(MOCK_RESERVED_SUBNETS_EMPTY)))
    def test_method_release_subnet_when_empty_list(self):
        step('Testing if subnet manager report about wrong pool size.')
        manager = DockerSubnetManager(subnet_pool=SUBNET_POOL_MORE)
        assert_raises_exception(output=f"Subnet {RELEASED_SUBNET} not in reserved subnet list:"
                                       f"{manager.reserved_subnet}, choose another subnet to release",
                                callable_obj=manager.release_subnet, subnet=RELEASED_SUBNET, exception=Exception)
