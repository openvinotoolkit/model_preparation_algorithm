#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
try:
    import mock
except ImportError:
    from unittest import mock

import pytest

from e2e import config
from e2e.environment_info import EnvironmentInfo, \
        DEFAULT_FULL_VERSION_NUMBER, DEFAULT_BUILD_NUMBER
from e2e.base_info import BaseInfo

PRODUCT_BUILD_NUMBER = '5641'


class MockDefaultConfig:
    product_build_number = None
    product_version = None
    product_build_number_from_env = False
    product_version_number_from_env = False
    info_module = "e2e.base_info.BaseInfo"


class MockBuildNumberConfig:
    product_build_number = PRODUCT_BUILD_NUMBER
    product_version = "0.0.0-{}-{}".format(config.product_version_suffix, PRODUCT_BUILD_NUMBER)
    product_build_number_from_env = config.product_build_number_from_env
    product_version_number_from_env = True
    info_module = "e2e.base_info.BaseInfo"


class MockBuildNumberConfigEnv:
    product_build_number = PRODUCT_BUILD_NUMBER
    product_version = "0.5.0-{}-{}".format(config.product_version_suffix, PRODUCT_BUILD_NUMBER)
    product_build_number_from_env = True
    product_version_number_from_env = config.product_version_number_from_env
    info_module = "e2e.base_info.BaseInfo"


class MockBuildNumberEnv:
    product_build_number = None
    product_version = None
    product_build_number_from_env = True
    product_version_number_from_env = True
    info_module = "e2e.base_info.BaseInfo"


class TestEnvironmentInfo:

    @pytest.fixture
    def base_info(self, monkeypatch):
        mock_base_info = mock.Mock()
        mock_base_info.return_value = mock_base_info
        mock_base_info.glob_version = MockBuildNumberConfigEnv.product_version
        monkeypatch.setattr("e2e.base_info.BaseInfo", mock_base_info)
        return mock_base_info

    def test_build_number_from_environment_version(self):
        assert "1235" == EnvironmentInfo._build_number_from_environment_version("0.8.0-oss-1235")

    def test_version_number_from_environment_version(self):
        assert "0.8.0-{}".format(config.product_version_suffix) \
               == EnvironmentInfo._version_number_from_environment_version("0.8.0-{}-1235"
                                                                           .format(config.product_version_suffix))

    @mock.patch("e2e.environment_info.config", MockDefaultConfig)
    @mock.patch("e2e.environment_info.EnvironmentInfo.env_info", BaseInfo())
    def test_get_build_number_when_environment_unreachable_and_default_config(self):
        assert EnvironmentInfo.get_build_number() is DEFAULT_BUILD_NUMBER

    @mock.patch("e2e.environment_info.config", MockBuildNumberEnv)
    @mock.patch("e2e.environment_info.EnvironmentInfo.env_info", BaseInfo())
    def test_get_build_number_when_environment_unreachable_and_build_number_from_env_variable_set(self):
        assert EnvironmentInfo.get_build_number() is "0"

    @mock.patch("e2e.environment_info.config", MockBuildNumberConfigEnv)
    @mock.patch("e2e.environment_info.EnvironmentInfo.env_info", BaseInfo())
    def test_get_build_number_when_environment_unreachable_and_build_number_variable_set(self):
        assert "0" == EnvironmentInfo.get_build_number()

    @mock.patch("e2e.environment_info.config", MockBuildNumberEnv)
    @mock.patch("e2e.environment_info.EnvironmentInfo.env_info", BaseInfo())
    def test_get_build_number_when_environment_ok_and_build_number_from_env_variable_set(self, base_info):
        base_info.glob_version = "0.8.0-{}-0".format(config.product_version_suffix)
        assert "0" == EnvironmentInfo.get_build_number()

    @mock.patch("e2e.environment_info.config", MockBuildNumberConfig)
    @mock.patch("e2e.environment_info.EnvironmentInfo.env_info.glob_version",
                "0.8.0-{}-{}".format(config.product_version_suffix, PRODUCT_BUILD_NUMBER))
    @mock.patch("e2e.environment_info.EnvironmentInfo.env_info", BaseInfo())
    def test_get_build_number_when_environment_ok_and_build_number_variable_set(self):
        product_build_number = EnvironmentInfo.get_build_number()
        if config.product_build_number_from_env:
            assert PRODUCT_BUILD_NUMBER == product_build_number
        else:
            assert MockBuildNumberConfig().product_build_number == product_build_number

    @mock.patch("e2e.environment_info.config", MockDefaultConfig)
    @mock.patch("e2e.environment_info.EnvironmentInfo.env_info", BaseInfo())
    def test_get_version_number_when_environment_unreachable_and_default_config(self):
        assert EnvironmentInfo.get_version_number() is DEFAULT_FULL_VERSION_NUMBER

    @mock.patch("e2e.environment_info.config", MockBuildNumberEnv)
    @mock.patch("e2e.environment_info.EnvironmentInfo.env_info", BaseInfo())
    def test_get_version_number_when_environment_unreachable_and_version_number_from_env_variable_set(self, base_info):
        assert EnvironmentInfo.get_version_number() == "0.0.0-{}".format(config.product_version_suffix)

    @mock.patch("e2e.environment_info.config", MockBuildNumberConfig)
    @mock.patch("e2e.environment_info.EnvironmentInfo.env_info", BaseInfo())
    def test_get_version_number_when_environment_unreachable_and_version_number_variable_set(self, base_info):
        assert '-'.join(MockBuildNumberConfig.product_version.split('-')[:2]) == EnvironmentInfo.get_version_number()

    @mock.patch("e2e.environment_info.config", MockBuildNumberEnv)
    @mock.patch("e2e.environment_info.EnvironmentInfo.env_info", BaseInfo())
    def test_get_version_number_when_environment_ok_and_version_number_from_env_variable_set(self, base_info):
        base_info.glob_version = "0.0.0-{}-0".format(config.product_version_suffix)
        assert "0.0.0-{}".format(config.product_version_suffix) == EnvironmentInfo.get_version_number()

    @mock.patch("e2e.environment_info.config", MockBuildNumberConfig)
    @mock.patch("e2e.environment_info.EnvironmentInfo.env_info", BaseInfo())
    def test_get_version_number_when_environment_ok_and_version_number_variable_set(self, base_info):
        base_info.glob_version = "0.0.0-{}-0".format(config.product_version_suffix)
        version_number = EnvironmentInfo.get_version_number()
        assert "0.0.0-{}".format(config.product_version_suffix) == version_number
