#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

from unittest import TestCase

from e2e.command_wrappers import Grep


class TestGrep(TestCase):
    DEFAULT = ["|", "grep", "--regexp='dummy'", "--ignore-case", "--basic-regexp"]

    def test_basic(self):
        self.assertListEqual(self.DEFAULT, Grep(pattern="dummy"))

    def test_pattern(self):
        self.assertRaises(RuntimeError, Grep, pattern=None)
        self.assertRaises(RuntimeError, Grep, pattern=[None])

    def test_ignore_case(self):
        self.assertRaises(RuntimeError, Grep, ignore_case="ignore")

    def test_invert_match(self):
        self.assertCountEqual(self.DEFAULT + ["--invert-match"], Grep(pattern="dummy", invert_match=True))

    def test_word_regexp(self):
        self.assertCountEqual(self.DEFAULT + ["--word-regexp"], Grep(pattern="dummy", word_regexp=True))

    def test_line_regexp(self):
        self.assertCountEqual(self.DEFAULT + ["--line-regexp"], Grep(pattern="dummy", line_regexp=True))

    def test_count(self):
        self.assertCountEqual(self.DEFAULT + ["--count"], Grep(pattern="dummy", count=True))

    def test_max_count(self):
        self.assertCountEqual(self.DEFAULT + ["--max-count=5"], Grep(pattern="dummy", max_count=5))
        self.assertCountEqual(self.DEFAULT, Grep(pattern="dummy", max_count=None))

    def test_only_matching(self):
        self.assertCountEqual(self.DEFAULT + ["--only-matching"], Grep(pattern="dummy", only_matching=True))

    def test_quiet(self):
        self.assertCountEqual(self.DEFAULT + ["--quiet"], Grep(pattern="dummy", quiet=True))

    def test_no_messages(self):
        self.assertCountEqual(self.DEFAULT + ["--no-messages"], Grep(pattern="dummy", no_messages=True))

    def test_line_number(self):
        self.assertCountEqual(self.DEFAULT + ["--line-number"], Grep(pattern="dummy", line_number=True))

    def test_a(self):
        self.assertCountEqual(self.DEFAULT + ["--after-context=10"], Grep(pattern="dummy", a=10))

    def test_b(self):
        self.assertCountEqual(self.DEFAULT + ["--before-context=12"], Grep(pattern="dummy", b=12))

    def test_c(self):
        self.assertCountEqual(self.DEFAULT + ["--context=7"], Grep(pattern="dummy", c=7))

    def test_group_separator(self):
        self.assertCountEqual(self.DEFAULT + ["--group-separator='---------------------'"],
                              Grep(pattern="dummy", group_separator="---------------------"))

    def test_variant(self):
        no_basic = self.DEFAULT.copy()
        no_basic.remove("--basic-regexp")
        self.assertCountEqual(no_basic + [Grep.Variant.FIXED_STRINGS.value],
                              Grep(pattern="dummy", variant=Grep.Variant.FIXED_STRINGS))
        self.assertCountEqual(no_basic + [Grep.Variant.PERL.value],
                              Grep(pattern="dummy", variant=Grep.Variant.PERL))
        self.assertCountEqual(no_basic + [Grep.Variant.EXTENDED.value],
                              Grep(pattern="dummy", variant=Grep.Variant.EXTENDED))
        self.assertCountEqual(self.DEFAULT, Grep(pattern="dummy", variant=Grep.Variant.BASIC))
