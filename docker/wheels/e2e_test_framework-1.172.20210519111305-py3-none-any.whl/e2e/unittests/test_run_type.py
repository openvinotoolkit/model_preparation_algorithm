#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

import pytest

from e2e.markers import MarkRunType


class TestRunType:

    @pytest.mark.parametrize("test_type_mark,expected_run_type",
                             [(MarkRunType.TEST_MARK_SMOKE, MarkRunType.TEST_MARK_SMOKE.run_type),
                              (MarkRunType.TEST_MARK_REGRESSION, MarkRunType.TEST_MARK_REGRESSION.run_type),
                              (MarkRunType.TEST_MARK_OTHER, MarkRunType.TEST_MARK_OTHER.run_type),
                              (MarkRunType.TEST_MARK_LONG, MarkRunType.TEST_MARK_LONG.run_type),
                              (MarkRunType.TEST_MARK_STRESS_AND_LOAD, MarkRunType.TEST_MARK_STRESS_AND_LOAD.run_type),
                              (MarkRunType.TEST_MARK_INITIAL, MarkRunType.TEST_MARK_INITIAL.run_type),
                              (MarkRunType.TEST_MARK_MANUAL, MarkRunType.TEST_MARK_MANUAL.run_type),
                              (MarkRunType.TEST_MARK_HW_SPECIFIC, MarkRunType.TEST_MARK_HW_SPECIFIC.run_type)])
    def test_test_mark_to_test_run_type(self, test_type_mark, expected_run_type):
        run_type = MarkRunType.test_mark_to_test_run_type(test_type_mark)
        assert run_type == expected_run_type

    def test_mark(self):
        assert MarkRunType("api_regression") == MarkRunType.TEST_MARK_REGRESSION
