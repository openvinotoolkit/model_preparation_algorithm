#
# INTEL CONFIDENTIAL
# Copyright (c) 2021 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import os

from jira import Project as ProjectOrig

from e2e.logger import get_logger

try:
    import mock
except ImportError:
    from unittest import mock

try:
    import simplejson as json
except ImportError:
    import json

from e2e.jira.jira_client import JiraClient as JiraClientOrig,\
    BugFactory as BugFactoryOrig,\
    TaskFactory as TaskFactoryOrig

logger = get_logger(__name__)


def load_json(path):
    data_jira_path = [os.path.abspath(os.curdir), "e2e", "unittests", "data", "jira"]
    data_jira_path = os.path.join(*data_jira_path)
    try:
        with open(f"{data_jira_path}/{path}.json") as mocked_json_output:
            r_json = json.load(mocked_json_output)
    except ValueError as e:
        logger.error("%s\n%s" % (e, mocked_json_output.read()))
        raise e
    return r_json


class GetJsonMock:
    def _get_json(self, path, params=None, base=JiraClientOrig.JIRA_BASE_URL):  # noqa
        return load_json(path)


class ProjectMock(ProjectOrig):
    def find(self, id, params=None):
        return load_json(f"project/{id}")


class BugFactoryMock(GetJsonMock, BugFactoryOrig):
    JIRA_SERVER_AUTH = False


class TaskFactoryMock(GetJsonMock, TaskFactoryOrig):
    JIRA_SERVER_AUTH = False


class JiraClientMock(GetJsonMock, JiraClientOrig):
    JIRA_SERVER_AUTH = False

    def project(self, id):
        """Get a project Resource from the server.

        :param id: ID or key of the project to get
        """
        return self._find_for_resource(ProjectMock, id)


JiraClient = JiraClientMock
BugFactory = BugFactoryMock
TaskFactory = TaskFactoryMock


class TestJiraClient:

    def test_jira_client(self):
        jira_client = JiraClient()
        projects = jira_client.projects()
        assert next(filter(lambda project: project.key == "CVS", projects), None) is not None

    def test_field_by_name(self, field_name="Exposure"):
        jira_client = JiraClient()
        exposure = jira_client.field_by_name(field_name)
        assert field_name in exposure.get("clauseNames", [])
        assert exposure.get("name", None) == field_name

    def test_bug_factory(self):
        bug_factory = BugFactory()
        bug_type = bug_factory.type
        assert bug_type.name == BugFactory.ISSUE_TYPE_NAME
        meta = bug_factory.projects_meta
        assert meta is not None
        bug_fields = bug_factory.issue_fields  # type: dict
        epic_link = bug_factory.field_by_name("Epic Link")
        assert epic_link.get("id") in bug_fields
        bug_required_fields = bug_factory.required_issue_fields
        exposure = bug_factory.field_by_name("Exposure")
        assert exposure.get("id") in bug_required_fields
        assert epic_link.get("id") not in bug_required_fields

    def test_task_factory(self):
        task_factory = TaskFactory()
        task_type = task_factory.type
        assert task_type.name == TaskFactory.ISSUE_TYPE_NAME
        meta = task_factory.projects_meta
        assert meta is not None
        task_fields = task_factory.issue_fields  # type: dict
        epic_link = task_factory.field_by_name("Epic Link")
        assert epic_link.get("id") in task_fields
        task_required_fields = task_factory.required_issue_fields
        summary = task_factory.field_by_name("Summary")
        assert summary.get("id") in task_required_fields
        assert epic_link.get("id") not in task_required_fields
