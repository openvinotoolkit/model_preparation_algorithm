#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import os
import time

try:
    import mock
except ImportError:
    from unittest import mock

import pytest

from e2e.log_grabber import check_str_in_recent_audit_logs, \
    get_text_between_parenthesis, is_recent


def audit_log_sample():
    return (
        "type=NAUTA_BACKUP msg=root(1502277948.019): Backup script ERROR: "
        "(1, 'Backup script finished with non zero exit code')\n"
        "type=NAUTA_BACKUP msg=root(1502279577.067): Backup script ERROR: "
        "(1, 'Backup script finished with non zero exit code')\n"
        "type=NAUTA_BACKUP msg=root({}): Backup script ERROR: "
        "(1, 'Backup script finished with non zero exit code')\n"
    ).format(time.time()-60)


@pytest.fixture
def fresh_line():
    return audit_log_sample().split('\n')[2]


@pytest.fixture
def au_logs(tmpdir):
    file_path = os.path.join(str(tmpdir), 'audit.log')
    with open(file_path, 'w+') as au_log:
        au_log.writelines([audit_log_sample()])
    return file_path


def test_check_str_in_recent_audit_logs(au_logs):
    download_audit_log_files_patch = 'e2e.log_grabber.download_audit_log_files'
    with mock.patch(download_audit_log_files_patch, return_value=None):
        result = check_str_in_recent_audit_logs(text='Backup script ERROR',
                                                log_file_path=au_logs)
    assert result is True


@pytest.mark.parametrize(
    ('text', 'expected_content'), [
        ('(123213)', '123213'),
        ('sadasd', None),
        ('dsadas(sadasd', None),
        ('dsadad)dasdas', None),
        ('dasd()dasda', ''),
        ('daad(1231jljk)31231', '1231jljk')
    ]
)
def test_get_text_between_parenthesis(text, expected_content):
    result = get_text_between_parenthesis(text)
    assert result == expected_content


@pytest.mark.parametrize(
    ('line', 'expected'), [
        (audit_log_sample().split('\n')[0], False),
        (None, False),
        ('test_data', False)
    ]
)
def test_is_recent(line, expected):
    assert is_recent(line) == expected


def test_is_recent_fresh_line(fresh_line):
    assert is_recent(fresh_line)
