from typing import List
from unittest import TestCase

from e2e.object_model.mount import MountWindows

MOUNT_OUTPUT = r"""New connections will not be remembered.


Status       Local     Remote                    Network

-------------------------------------------------------------------------------
OK           Y:        \\10.91.120.97.lab.sclab.intel.com\input
                                                Microsoft Windows Network
             Z:        \\ftp.sclab.intel.com\home\user\fileshare\data
                                                NFS Network
The command completed successfully.

""".splitlines()

MIXED_MOUNT_OUTPUT = r"""New connections will not be remembered.


Status       Local     Remote                    Network

-------------------------------------------------------------------------------
OK           D:        \\short\input             Microsoft Windows Network
OK           Y:        \\10.91.120.97.lab.sclab.intel.com\input
                                                Microsoft Windows Network
             Z:        \\ftp.sclab.intel.com\home\user\fileshare\data
                                                NFS Network
The command completed successfully.

""".splitlines()


class TestMountWindows(TestCase):
    def test_parse_mount_output(self):
        output = MountWindows.parse_mount_output(MOUNT_OUTPUT)  # type: List[dict]
        assert len(output) == 1  # skipping NFS Network due to cls.NETWORK_TYPES_TO_SKIP
        assert len(output[0].keys()) == 4

    def test_parse_mixed_mount_output(self):
        output = MountWindows.parse_mount_output(MIXED_MOUNT_OUTPUT)  # type: List[dict]
        assert len(output) == 2  # skipping NFS Network due to cls.NETWORK_TYPES_TO_SKIP
        assert len(output[0].keys()) == 4
        assert len(output[1].keys()) == 4
