#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
try:
    import mock
except ImportError:
    from unittest import mock

from e2e.logger import step
from e2e.port_manager import PortManager
from e2e.assertions import assert_raises_exception

STARTING_PORT = 9500
EXPECTED_PORTS = [9500, 9501]
POOL_SIZE = 1
POOL_SIZE_MORE = 3
POOL_SIZE_ZERO = 0


class MockSocket:

    def bind(self, address):
        pass

    def close(self):
        pass

    def setsockopt(self, *args):
        pass


class MockSocketError:
    PORT_HISTORY = []

    def bind(self, address):
        self.PORT_HISTORY.append(address[1])
        if len(self.PORT_HISTORY) < 2:
            raise OSError(98, 'Address already in use.')
        else:
            pass

    def close(self):
        pass

    def setsockopt(self, *args):
        pass


class TestPortManager:

    @mock.patch("socket.socket", MockSocket)
    def test_port_manager_get_port(self):
        step('Testing if port manager get port properly.')
        manager = PortManager("test_port_manager_get_port", starting_port=STARTING_PORT, pool_size=POOL_SIZE)
        port = manager.get_port()
        assert type(port) is int, "Not expected type found. \n Expected: {}, found: {}.".format(type(port), int)
        assert port in EXPECTED_PORTS, \
            "Not expected port generated. \n Expected: {}, got: {}.".format(STARTING_PORT, port)
        manager.release_port(port)

    @mock.patch("socket.socket", MockSocket)
    def test_port_manager_get_more_ports(self):
        ports = []
        step('Testing if port manager gets ports properly.')
        manager = PortManager("test_port_manager_get_more_ports", starting_port=STARTING_PORT, pool_size=POOL_SIZE_MORE)
        for num in range(POOL_SIZE_MORE):
            port = manager.get_port()
            ports.append(port)
        assert len(ports) == POOL_SIZE_MORE
        for port in ports:
            manager.release_port(port)

    @mock.patch("socket.socket", MockSocket)
    def test_port_manager_run_out_of_ports(self):
        ports = []
        step('Testing if port manager catch run out of ports case.')
        manager = PortManager("test_port_manager_run_out_of_ports", starting_port=STARTING_PORT,
                              pool_size=POOL_SIZE_MORE)

        for num in range(POOL_SIZE_MORE):
            port = manager.get_port()
            ports.append(port)

        assert_raises_exception(output="Ports pool {} has been used up. Consider release ports or increase pool size."
                                .format(manager.name),
                                callable_obj=manager.get_port, exception=Exception)

        for port in ports:
            manager.release_port(port)

    @mock.patch("socket.socket", MockSocketError)
    def test_port_manager_port_already_in_use_pool_size_one(self):

        step('Testing if port manager report that ports pool has been used up with pool size equal to 1')
        manager = PortManager("test_port_manager_port_already_in_use_pool_size_one", starting_port=STARTING_PORT,
                              pool_size=POOL_SIZE)
        assert_raises_exception(output="Ports pool {} has been used up. Consider release ports or increase pool size."
                                .format(manager.name),
                                callable_obj=manager.get_port, exception=Exception)

    @mock.patch("socket.socket", MockSocket)
    def test_port_manager_wrong_pool_size(self):

        step('Testing if port manager report about wrong pool size.')
        name = "test_port_manager_wrong_pool_size"
        assert_raises_exception(output="Not expected pool size given for manager {}, should be > 0.".format(name),
                                callable_obj=PortManager, exception=AssertionError,
                                name=name,
                                starting_port=STARTING_PORT, pool_size=POOL_SIZE_ZERO)
