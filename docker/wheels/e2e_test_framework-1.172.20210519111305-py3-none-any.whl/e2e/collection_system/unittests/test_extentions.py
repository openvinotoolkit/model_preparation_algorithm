#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

import json
import uuid
import random
import time

from e2e.collection_system.extentions import *
from e2e.collection_system.core import CollectionManager
from e2e.collection_system.core import Collector

def test_import():
    assert MemoryDownloader
    assert SensorDownloader
    assert LoggerExporter
    assert MongoExporter
    assert JsonExporter
    assert Histogramer
    assert Statisticer

def test_json_exporter():
    filename = str(uuid.uuid4()) + ".json"
    exporter = JsonExporter(filename=filename)
    manager = CollectionManager()
    manager.register_exporter(exporter)
    exporter.prepare()
    exporter.finish()

def test_mongo_exporter():
    exporter = MongoExporter()
    manager = CollectionManager()
    manager.register_exporter(exporter)
    exporter.prepare()
    exporter.finish()

def test_sensor_downloader():
    puller = SensorDownloader(name="temp", address="localhost", user="root", password="")
    puller.enable_sensor("pack1", "coretemp-isa-0001", "Package id 1", "temp1_input")
    puller.enable_sensor("core0", "coretemp-isa-0001", "Core 0", "temp2_input")
    manager = CollectionManager()
    manager.register_collector(puller)

def test_memory_downloader():
    puller = MemoryDownloader(name="mem", address="localhost", user="root", password="")
    manager = CollectionManager()
    manager.register_collector(puller)

def test_pipe_1():
    manager = CollectionManager()
    collector = RandomCollector(name="rand", interval=0.1)
    manager.register_collector(collector)

    exporter = LoggerExporter("collsys-logger")
    manager.register_exporter(exporter)

    manager.start()
    for _ in range(3):
        time.sleep(0.333)
        manager.flush()
    manager.stop()

    counters = manager.get_counters()
    collecting_counter, exporting_counter, _ = counters
    assert collecting_counter
    assert exporting_counter
    
def test_pipe_2():
    manager = CollectionManager()
    collector = Collector(name="manual")
    manager.register_collector(collector)

    metadata = {
        "timestamp": time.time(),
        "key": random.randint(1, 100)
    }
    
    filename = str(uuid.uuid4()) + ".json"
    exporter_json = JsonExporter(filename=filename,
                                 metadata=metadata)
    manager.register_exporter(exporter_json)

    exporter_mongo = MongoExporter(metadata=metadata)
    manager.register_exporter(exporter_mongo)

    manager.start()
    sample_number = 1000
    for n in range(sample_number):
        collector.log_internal_metric("no", n, flush=True)
    collector.log_final_metric("total", sample_number)
    collector.log_final_metric("status-1", "ok")
    collector.log_final_metric("status-2", None)
    collector.log_final_metric("status-3", False)
    collector.log_final_metric("status-4", True)
    manager.stop()

    with open(filename) as fd:
        jdata = json.load(fd)
        content = dict(jdata)

    assert "final_results" in content
    assert "internal_results" in content
    assert type(content["final_results"]) is dict
    assert type(content["internal_results"]) is list
    assert len(content["internal_results"]) == sample_number
    assert len(content["final_results"]) == 5

def test_pipe_3():
    manager = CollectionManager()
    histogramer = Histogramer("hist", "val", delta=200)
    statisticer = Statisticer("stat", "val")
    for n in range(4):
        name = f"rand{n}"
        collector = RandomCollector(name=name, interval=0.001)
        histogramer.register_collector(collector)
        statisticer.register_collector(collector)
        manager.register_collector(collector)
    manager.register_analyzer(histogramer)
    manager.register_analyzer(statisticer)
    
    exporter = LoggerExporter("collsys-logger")
    manager.register_exporter(exporter)

    manager.start()
    for _ in range(3):
        time.sleep(0.2)
        manager.flush()
    manager.stop()

    counters = manager.get_counters()
    collecting_counter, exporting_counter, _ = counters
    assert collecting_counter
    assert exporting_counter
