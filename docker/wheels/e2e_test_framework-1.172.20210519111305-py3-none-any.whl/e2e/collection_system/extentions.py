#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

import os
import re
import math
import uuid
import pymongo

from e2e.mongo_reporter.base_reporter import BaseReporter

from e2e.collection_system.core import Analyzer
from e2e.collection_system.core import DeamonCollector
from e2e.collection_system.core import DeamonExporter

from e2e.collection_system.downloader import DownloaderHandler

from e2e.collection_system.utils import FakeMongoCollection
from e2e.collection_system.utils import item_type_internal
from e2e.collection_system.utils import classify_item

from e2e.logger import get_logger

    
class DockerStatsDownloader(DownloaderHandler):
    _script = "docker-stats-downloader.py"
    _executor = "python3"

    def __init__(self, name, address, user=None, password=None, timestamp=None, interval=10):        
        DownloaderHandler.__init__(self, name, address, user, password, timestamp, interval)
        self.__cpu_sum = 0.0
        self.__cpu_max = 0.0
        self.__mem_sum = 0.0
        self.__mem_max = 0.0

    def process_batch(self):
        try:
            data_dict = DownloaderHandler.process_batch(self)
        except Exception as err:
            logger = get_logger(self._name)
            logger.warning(f"{err}")
            data_source = self.get_raw_batch()
            logger.warning(data_source)
            return

        if not isinstance(data_dict, dict):
            logger = get_logger(self._name)
            logger.warning("output cannot be converted to dict!")
            data_source = self.get_raw_batch()
            logger.warning(data_source)
            return
        self._checkpoints += 1

        mem_sum = 0.0
        cpu_sum = 0.0
        for key, value in data_dict.items():
            self.log_internal_metric(key, value)
            if "mem" in key:
                mem_sum += value
            if "cpu" in key:
                cpu_sum += value
        self.__mem_sum += mem_sum
        self.__cpu_sum += cpu_sum
        if cpu_sum > self.__cpu_max:
            self.__cpu_max = cpu_sum
        if mem_sum > self.__mem_max:
            self.__mem_max = mem_sum
        offset = data_dict["offset"]
        self.flush_internals(offset=offset)

    def calculate_final_metrics(self):
        DownloaderHandler.calculate_final_metrics(self)
        if self._checkpoints > 0.0:
            mem_mean = self.__mem_sum / self._checkpoints
            cpu_mean = self.__cpu_sum / self._checkpoints
            self.log_final_metric(f"mem_mean", round(mem_mean, 2))
            self.log_final_metric(f"cpu_mean", round(cpu_mean, 2))
        self.log_final_metric(f"cpu_max", self.__cpu_max)
        self.log_final_metric(f"mem_max", self.__mem_max)
        return self.final_metrics

class MemoryDownloader(DownloaderHandler):
    _script = "memory-downloader.py"
    _executor = "python3"

    def __init__(self, name, address, user=None, password=None, timestamp=None, interval=10):        
        DownloaderHandler.__init__(self, name, address, user, password, timestamp, interval)

        # all memory and swap amount is expressed in kB
        self.__swap_used_max = 0.0
        self.__swap_used_mass = 0.0
        self.__swap_used_mass2 = 0.0
        self.__swap_free_mass = 0.0
        self.__swap_total = 0.0
        
        self.__mem_used_max = 0.0
        self.__mem_used_mass = 0.0
        self.__mem_used_mass2 = 0.0
        self.__mem_free_mass = 0.0
        self.__mem_free_min = None
        self.__mem_total = 0.0
        
    def process_batch(self):
        try:
            data_dict = DownloaderHandler.process_batch(self)
        except Exception as err:
            logger = get_logger(self._name)
            logger.warning(f"{err}")
            data_source = self.get_raw_batch()
            logger.warning(data_source)
            return

        if not isinstance(data_dict, dict):
            logger = get_logger(self._name)
            logger.warning("output cannot be converted to dict!")
            data_source = self.get_raw_batch()
            logger.warning(data_source)
            return

        for key, value in data_dict.items():
            self.log_internal_metric(key, value)
        self._checkpoints += 1

        if data_dict["swap_used"] > self.__swap_used_max:
            self.__swap_used_max = data_dict["swap_used"]
        self.__swap_used_mass += data_dict["swap_used"]
        self.__swap_used_mass2 += data_dict["swap_used"] ** 2
        self.__swap_free_mass += data_dict["swap_free"]
        self.__swap_total = data_dict["swap_total"]

        if data_dict["mem_used"] > self.__mem_used_max:
            self.__mem_used_max = data_dict["mem_used"]
        self.__mem_used_mass += data_dict["mem_used"]
        self.__mem_used_mass2 += data_dict["mem_used"] ** 2
        self.__mem_free_mass += data_dict["mem_free"]
        self.__mem_total = data_dict["mem_total"]

        if self.__mem_free_min is None or self.__mem_free_min > data_dict["mem_free"]:
            self.__mem_free_min = data_dict["mem_free"]

        offset = data_dict["offset"]
        self.flush_internals(offset=offset)

    def calculate_final_metrics(self):
        DownloaderHandler.calculate_final_metrics(self)

        if self._checkpoints > 0.0:
            self.log_final_metric(f"mem_free_min", self.__mem_free_min)

            swap_used_mean = float(self.__swap_used_mass) / self._checkpoints
            swap_used_mean2 = float(self.__swap_used_mass2) / self._checkpoints
            swap_free_mean = float(self.__swap_free_mass) / self._checkpoints
            mem_used_mean = float(self.__mem_used_mass) / self._checkpoints
            mem_used_mean2 = float(self.__mem_used_mass2) / self._checkpoints
            mem_free_mean = float(self.__mem_free_mass) / self._checkpoints

            self.log_final_metric(f"swap_used_mean", round(swap_used_mean, 2))
            self.log_final_metric(f"swap_free_mean", round(swap_free_mean, 2))
            self.log_final_metric(f"mem_used_mean", round(mem_used_mean, 2))
            self.log_final_metric(f"mem_free_mean", round(mem_free_mean, 2))
            
            swap_used_var = swap_used_mean2 - swap_used_mean ** 2
            mem_used_var = mem_used_mean2 - mem_used_mean ** 2
            
            self.log_final_metric(f"swap_used_stdev", round(math.sqrt(swap_used_var), 2))
            self.log_final_metric(f"mem_used_stdev", round(math.sqrt(mem_used_var), 2))
            
        self.log_final_metric(f"swap_used_max", self.__swap_used_max)
        self.log_final_metric(f"mem_used_max", self.__mem_used_max)
        self.log_final_metric(f"swap_total", self.__swap_total)
        self.log_final_metric(f"mem_total", self.__mem_total)
        return self.final_metrics


class SensorDownloader(DownloaderHandler):
    _script = "sensor-downloader.py"
    _executor = "python3"

    def __init__(self, name, address, user=None, password=None, timestamp=None, interval=2):
        DownloaderHandler.__init__(self, name, address, user, password, timestamp, interval)

        self.__group_means = {}
        self.__groups = {}
        self.__counters = {}
        self.__sensors = {}
        self.__masses = {}
        self.__maxes = {}

    def enable_sensors_group(self, prefix, *args):
        if prefix in self.__groups:
            logger = get_logger(self._name)        
            logger.warning(f"{prefix} is already registered!")
        self.__groups[prefix] = args

    def __data_decompose(self, data, path=[]):
        for key, branch in data.items():
            new_path = path + [key]
            if isinstance(branch, (str, int, float)):
                yield new_path
            elif type(branch) is dict:
                yield from self.__data_decompose(branch, new_path)
            else:
                logger = get_logger(self._name)
                info = f"unexpected data in {new_path}!"
                logger.warning(info)
        
    def __parse_sensors_group(self, prefix, rekeys, data):
        counter = 0
        self.__group_means[prefix] = []
        for branch in self.__data_decompose(data):
            if len(branch) != len(rekeys):
                continue
            for rekey, key in zip(rekeys, branch):
                if rekey[0] != "^":
                    rekey = f"^{rekey}"
                if rekey[-1] != "$":
                    rekey = f"{rekey}$"
                if not re.findall(rekey, key):
                    break
            else:
                name = f"{prefix}{counter}"
                self.__group_means[prefix].append(name)
                self.enable_sensor(name, *branch)
                counter += 1

    def __parse_sensors_groups(self, data):
        for prefix, rekeys in self.__groups.items():
            self.__parse_sensors_group(prefix, rekeys, data)
        self.__groups = {}
            
    def enable_sensor(self, key, *args):
        logger = get_logger(self._name)        
        if key in self.__sensors:
            logger.warning(f"{key} is already registered!")

        sensor_config = " / ".join(args)
        logger.info(f"init sensor: {key} -> {sensor_config}")
        self.__sensors[key] = args
        self.__counters[key] = 0
        self.__masses[key] = 0.0
        self.__maxes[key] = 0.0

    def process_batch(self):
        try:
            data_dict = DownloaderHandler.process_batch(self)
        except:
            logger = get_logger(self._name)
            data_source = self.get_raw_batch()
            logger.debug(data_source)
            return

        if not isinstance(data_dict, dict):
            return
        if self.__groups:
            self.__parse_sensors_groups(data_dict)
        self._checkpoints += 1

        flush, nokey = False, False
        for key, sensor_keys in self.__sensors.items():
            value = data_dict
            for sensor_key in sensor_keys:
                try:
                    value = value[sensor_key]
                except KeyError:
                    nokey = True
                    break
            if nokey:
                continue           
            if isinstance(value, (int, float, str)):
                self.log_internal_metric(key, value)
                if isinstance(value, (int, float)):
                    self.__masses[key] += value
                    self.__counters[key] += 1
                    if value > self.__maxes[key]:
                        self.__maxes[key] = value
                flush = True
        if flush:
            offset = data_dict["offset"]
            self.flush_internals(offset=offset)

    def calculate_final_metrics(self):
        DownloaderHandler.calculate_final_metrics(self)

        max_mean = 0.0
        for key in self.__sensors.keys():
            if self.__counters[key] == 0:
                continue
            mean = self.__masses[key] / self.__counters[key]
            self.log_final_metric(f"{key}_mean", round(mean, 3))
            self.log_final_metric(f"{key}_max", self.__maxes[key])

        for prefix, group in self.__group_means.items():
            counter, mass, maxv = 0, 0.0, 0.0
            for key in group:
                if self.__maxes[key] > maxv:
                    maxv = self.__maxes[key]
                counter += self.__counters[key]
                mass += self.__masses[key]
            if counter:
                mean = round(mass / counter, 3)
                self.log_final_metric(f"{prefix}_mean", mean)
                self.log_final_metric(f"{prefix}_max", maxv)
        return self.final_metrics


class RandomCollector(DeamonCollector):
    __script = "e2e/collection_system/scripts/demo_random.sh"
    __executor = "bash"

    def __init__(self, name=None, timestamp=None, interval=0.1):
        cmd = f"{self.__executor} {self.__script} {interval}"
        assert os.path.exists(self.__script), f"no script {self.__script}"        
        DeamonCollector.__init__(self, name, timestamp, cmd)
        self.__internal_counter = 0
        self.__mass2 = 0.0
        self.__mass = 0.0
        
    def get(self):
        item = self.queue.get()
        if classify_item(item) == item_type_internal:
            self.__mass2 += item["val"] ** 2
            self.__mass += item["val"]
            self.__internal_counter += 1
        self._counter += 1
        return item

    def analyze(self, line):
        ts, val = line.split("->")
        self.flush_internals(float(ts))
        self.log_internal_metric("val", float(val))

    def calculate_final_metrics(self):
        try:
            n = self.__internal_counter
            mean = self.__mass / n
            var = self.__mass2 / n - mean ** 2
            stdev = math.sqrt(var)
            cv = 100 * stdev / mean
            self.log_final_metric("average", mean)
            self.log_final_metric("stdev", stdev)
            self.log_final_metric("cv", cv)
        except ZeroDivisionError:
            pass

        return self.final_metrics


class Histogramer(Analyzer):
    def __init__(self, name, key, delta=0.001, start=0.0, stop=None):
        Analyzer.__init__(self, name)
        self.__histogram = {}
        self.__key = key

        self.__delta = float(delta)
        self.__start = float(start)
        self.__stop = stop
        if stop is not None:
            self.__stop = float(stop)

        self.__used_counter = 0
        self.__lost_counter = 0        
        self.__total_mass = 0.0

    def put(self, source, item):
        if source not in self._sources:
            return 0

        value = item[self.__key]
        self.__total_mass += value
        if self.__stop is not None:
            if value > self.__stop:
                self.__lost_counter += 1
                return 1
        if value < self.__start:
            self.__lost_counter += 1
            return 1
        self.__used_counter += 1

        value -= self.__start
        value += self.__delta / 2
        index = int(value / self.__delta)
        try:
            self.__histogram[index] += 1
        except KeyError:
            self.__histogram[index] = 1
        return 1

    def calculate_final_metrics(self):
        prefix = f"{self._name}_{self.__key}"
        output = {
            f"{prefix}_start": self.__start,
            f"{prefix}_delta": self.__delta
        }

        total = self.__used_counter + self.__lost_counter
        if total > 0:
            ave = float(self.__total_mass) / total
            output[f"{prefix}_average"] = ave

        for index, value in self.__histogram.items():
            output[f"{prefix}", index] = value
        return output

class Statisticer(Analyzer):
    def __init__(self, name, key):
        Analyzer.__init__(self, name)
        self.__key = key

        self.__extra_metrics = {}
        self.__samples = []
        self.__mass = 0.0
        self.__mass2 = 0.0
        self.__counter = 0
        self.__duration = 0.0
        
    def request_extra_metric(self, label, func):
        self.__extra_metrics[label] = func

    def put(self, source, item):
        if source not in self._sources:
            return 0

        offset = item["offset"]
        if self.__duration < offset:
            self.__duration = offset
        value = item[self.__key]
        self.__samples.append(value)
        self.__mass2 += value ** 2
        self.__mass += value
        self.__counter += 1

    def calculate_final_metrics(self):
        metrics = {
            "total": self.__mass,
            "counter": self.__counter,
            "duration": self.__duration
        }

        if self.__counter > 0:
            sorted_samples = list(sorted(self.__samples))
            mean = self.__mass / self.__counter
            median = sorted_samples[int(self.__counter/2)]
            var = self.__mass2 / self.__counter - mean ** 2
            stdev = math.sqrt(var)
            cv = 100 * stdev / mean

            metrics["first"] = self.__samples[0]
            metrics["min"] = sorted_samples[0]
            metrics["max"] = sorted_samples[-1]
            metrics["median"] = median
            metrics["average"] = mean
            metrics["mean"] = mean
            metrics["stdev"] = stdev
            metrics["cv"] = cv

        p_counter = 2
        while 10 ** p_counter <= self.__counter:
            index = int(self.__counter * (1.0 - 0.1 ** p_counter) - 1)
            p_label = f"p{p_counter}x9"
            p_value = sorted_samples[index]
            metrics[f"{p_label}"] = p_value
            p_counter += 1

        output = {}
        prefix = f"{self._name}"
        for label, func in self.__extra_metrics.items():
            output[f"{prefix}_{label}"] = func(**metrics)
        if "mean" in metrics and "average" in  metrics: 
            del metrics["mean"]

        prefix = f"{self._name}_{self.__key}"
        for key, val in metrics.items():
            output[f"{prefix}_{key}"] = val
        return output


class LoggerExporter(DeamonExporter):
    def __init__(self, name, interval=1, accept="all"):
        DeamonExporter.__init__(self, interval, accept)
        self.__logger = get_logger(name)        

    def process_internal(self, item):
        def data_formater(source, offset, **kwargs):
            # source and offset excluding from kwargs
            return ", ".join([f"{k}: {v}" for k, v in kwargs.items()])

        source = item["source"]
        offset = item["offset"]
        data = data_formater(**item)
        line = f"{source}({offset}) -> {data}"
        self.__logger.info(line)

    def process_final(self, item):
        fsort = lambda x: x if type(x) is tuple else (str(x), 0)
        for key in sorted(item.keys(), key=fsort):
            val = item[key]
            if type(key) is tuple:
                label = " -> ".join(map(str, key))
                self.__logger.info(f"{label} -> {val}")
            else:
                self.__logger.info(f"{key} -> {val}")


class JsonExporter(DeamonExporter):
    def __init__(self, filename, interval=1, metadata={}, accept="all"):
        DeamonExporter.__init__(self, interval, accept)

        assert "internal_results" not in metadata, "internal results cannot be used as metadata"
        assert "final_results" not in metadata, "final results cannot be used as metadata"

        self.__metadata = metadata
        self.__filename = filename
        self.__fd = None
        
    def prepare(self):
        self.__fd = open(self.__filename, "w")
 
        self.__fd.write("{\n")
        self.__end = ""
        for key, val in self.__metadata.items():
            if type(val) is str:
                val = f"\"{val}\""
            self.__fd.write(f"{self.__end}\t\"{key}\": {val}")
            self.__end = ",\n"
        self.__fd.write(f"{self.__end}\t\"internal_results\": [\n")
        self.__end = ""

    def process_internal(self, item):
        irstr = str(item).replace("'", "\"")
        self.__fd.write(f"{self.__end}\t\t{irstr}")
        self.__end = ",\n"

    def process_final(self, item):
        finals = self.clean_finals(item)
        self.__end = "\n"

        self.__fd.write("\n\t],\n")
        self.__fd.write("\t\"final_results\": {")
        fsort = lambda x: x if type(x) is tuple else (str(x), 0)
        for key in sorted(finals.keys(), key=fsort):
            val = finals[key]
            if type(val) is str:
                val = f"\"{val}\""
            elif val is None:
                val = "null"
            elif val is False:
                val = "false"
            elif val is True:
                val = "true"

            if type(key) is str:
                key = f"\"{key}\""
            elif type(key) is tuple:
                key = "_".join(map(str, key))
                key = f"\"{key}\""

            self.__fd.write(f"{self.__end}\t\t{key}: {val}")
            self.__end = ",\n"
        self.__fd.write("\n\t}\n")

    def finish(self):
        self.__fd.write("}\n")
        self.__fd.close()
          

class MongoExporter(DeamonExporter, BaseReporter):
    default_collection_name = "test_metrics"
    default_port_number = 27017
    
    def __init__(self, db_url=None, collection=None, metadata={}, interval=1, accept="all"):
        DeamonExporter.__init__(self, interval, accept)
        
        assert "internal_results" not in metadata, "internal results cannot be used as metadata"
        assert "final_results" not in metadata, "final results cannot be used as metadata"

        self.__metadata = metadata.copy()
        self.__metadata["internal_results"] = []
        self.__metadata["final_results"] = {}

        self.__coll_name = self.default_collection_name
        if collection is not None:
            self.__coll_name = collection
            
        if db_url is not None:
            # for example:
            # mongodb://validationreports.sclab.intel.com/ovms_develop_test_results
            # mongodb://validationreports.sclab.intel.com:27017/ovms_develop_test_results
            
            assert "mongodb://" in db_url, "Error! db url should start from mongodb://"
            _, substantial_part = db_url.split("//")
            address, db_name= substantial_part.split("/")
            if ":" in address:
                host, port = address.split(":")
            else:
                port = self.default_port_number
                host = address
            self.__address = f"mongodb://{host}:{port}/"
            self.__db_name = db_name.strip()
        else:
            self.__address = None

        self.__collection = None
        self.__docid = None

    def prepare(self):
        if self.__address is None:
            # only to test in unittests
            self.__collection = FakeMongoCollection()
        else:            
            client = pymongo.MongoClient(self.__address)
            database = client[self.__db_name]            
            self.__collection = database[self.__coll_name]

        ack = self.__collection.insert_one(self.__metadata)
        self.__docid = ack.inserted_id if ack else None

    def process_internal(self, item):
        query = {"_id": self.__docid}
        cmd = {"$push": {"internal_results": item}}
        self.__collection.update_one(query, cmd)

    def update_metadata(self, key, val):
        query = {"_id": self.__docid}
        assert key != "internal_results"        
        assert key != "final_results"
        cmd = {"$set": {key: val}}
        self.__collection.update_one(query, cmd)

    def process_final(self, item):
        query = {"_id": self.__docid}
        data = dict()
        for key, val in item.items():
            skey = key
            if isinstance(key, (tuple, list)):
                skey = "_".join(map(str, key))
            data[skey] = val
        cmd = {"$set": {"final_results": data}}
        self.__collection.update_one(query, cmd)
