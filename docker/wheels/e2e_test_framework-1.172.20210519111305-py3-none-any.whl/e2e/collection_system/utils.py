#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

import json

item_type_end = "end"
item_type_final = "final"
item_type_internal = "internal"


def classify_item(item):
    # output can be: end, internal, or final

    if item is None:
        return item_type_end
    elif type(item) is not dict:
        raise TypeError("wrong data type")
    elif "source" in item and "offset" in item:
        return item_type_internal
    else:
        return item_type_final


def load_histogram(filename, source, label):
    with open(filename, "r") as fd:
        data = json.load(fd)

    results = data["final_results"]
    assert f"{source}_{label}_delta" in results
    assert f"{source}_{label}_start" in results    
    delta = results[f"{source}_{label}_delta"]
    start = results[f"{source}_{label}_start"]
    
    histogram = {}
    for key, val in results.items():
        parts = key.split("_")
        if parts[0] != source or parts[1] != label:
            continue 
        try:
            index = int(parts[2])
        except (ValueError, TypeError, IndexError):
            continue
        histogram[index] = int(val)
    output = {}
    maxinum = max(histogram.keys())
    for index in range(maxinum+1):
        argument = start + index * delta
        try:
            output[argument] = histogram[index]
        except KeyError:
            output[argument] = 0
    return output


class StateManager:
    __allowed_changes = {
        "manager": {
            "started": ("inited",),
            "stopped": ("inited", "started")
        },
        "collector": {
            "registered": ("inited",),
            "started": ("registered",),
            "stopped": ("registered", "started")
        },
        "exporter": {
            "registered": ("inited",),
            "started": ("registered",),
            "stopped": ("registered", "started")
        }       
    }

    def __init__(self, prototype, name):
        assert prototype in self.__allowed_changes.keys()
        self.__prototype = prototype
        self.__state = "inited"
        self.__name = name

    def __repr__(self):
        return f"{self.__name} {self.__prototype} state: {self.__state}"

    def get_state(self):
        return self.__state

    def assert_init(self, info=None):
        if info is None:
            info = f"{self.__name} has to be inited"
        assert self.__state == "inited", info

    def assert_register(self, info=None):
        if info is None:
            info = f"{self.__name} has to be registered"
        assert self.__state == "registered", info

    def assert_start(self, info=None):
        if info is None:
            info = f"{self.__name} has to be started"
        assert self.__state == "started", info

    def assert_stop(self, info=None):
        if info is None:
            info = f"{self.__name} has to be stopped"
        assert self.__state == "stopped", info

    def assert_no_init(self, info=None):
        if info is None:
            info = f"{self.__name} cannot be inited"
        assert self.__state != "inited", info

    def assert_no_register(self, info=None):
        if info is None:
            info = f"{self.__name} cannot be registered"
        assert self.__state != "registered", info

    def assert_no_start(self, info=None):
        if info is None:
            info = f"{self.__name} cannot be started"
        assert self.__state != "started", info

    def assert_no_stop(self, info=None):
        if info is None:
            info = f"{self.__name} cannot be stopped"
        assert self.__state != "stopped", info

    def __get_next_allowed(self, state):
        return self.__allowed_changes[self.__prototype][state]

    def register(self):
        allowed_states = self.__get_next_allowed("registered")
        info = f"when {self.__prototype} registers, {self.__state} has to be one of {allowed_states}"
        assert self.__state in allowed_states, info
        self.__state = "registered"

    def start(self):
        allowed_states = self.__get_next_allowed("started")
        info = f"when {self.__prototype} starts, {self.__state} has to be one of {allowed_states}"
        assert self.__state in allowed_states, info
        self.__state = "started"

    def stop(self):
        allowed_states = self.__get_next_allowed("stopped")
        info = f"when {self.__prototype} stops, {self.__state} has to be one of {allowed_states}"
        assert self.__state in allowed_states, info
        self.__state = "stopped"


class Namer:
    def __init__(self, name):
        assert name, "name has to be set."
        assert name.isalnum(), f"name {name} should be alphanumeric."
        self._name = name

    def get_name(self):
        return self._name

    def assert_name(self, collector):
        name = collector.get_name()
        assert self._name != name


class FakeMongoCollection:
    def insert_one(self, init_data): pass
    def update_one(self, key, data): pass


class TeeFileLogger:
    def __init__(self, fd, logger):
        self.log = logger
        self.fd = fd

    def close(self):
        self.fd.close()

    def write(self, content):
        for line in content.split("\n"):
            self.log.info(line)
        self.fd.write(line)
   
