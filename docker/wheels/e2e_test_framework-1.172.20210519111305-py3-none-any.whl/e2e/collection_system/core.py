#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

### Output data schema:
#
#  identification columns and metadata:
#
#  timestamp | final results (map): {source_} | internal results (list of maps): {offset, source, ...}
#

import os
import sys
import time

import shlex
import select
import fcntl

from queue import Empty
from multiprocessing import Process
from multiprocessing import Queue as QueueFunc

from subprocess import Popen
from subprocess import PIPE

from retry.api import retry_call
from e2e.logger import get_logger

from e2e.collection_system.utils import classify_item
from e2e.collection_system.utils import StateManager
from e2e.collection_system.utils import Namer

from e2e.collection_system.utils import item_type_end
from e2e.collection_system.utils import item_type_final
from e2e.collection_system.utils import item_type_internal


class Collector(Namer):
    def __init__(self, name=None, timestamp=None, queue=None):
        Namer.__init__(self, name)

        self.state_manager = StateManager("collector", name)
        self._counter = 0

        typename = type(self).__name__
        self.logger = get_logger(f"collsys.{typename}.{name}")
        self.logger.info("init collector")

        self.queue = queue if queue is not None else QueueFunc()
        ts = time.time() if timestamp is None else timestamp
        self.__born_timestamp = float(ts)

        self.init_internal_entity(self.__born_timestamp)
        self.final_metrics = {}

    def set_end_flag(self, queue):
        self.__end_flag = queue

    def __repr__(self):
        src = self._name
        crr_cnt = self.queue.qsize()
        state = self.state_manager.get_state()
        out = f"{crr_cnt}/{self._counter} - "
        out += f"{type(self).__name__} - {src} ({state})"
        return out

    def get(self):
        item = self.queue.get()
        self._counter += 1
        return item

    def init_internal_entity(self, timestamp=None):
        if timestamp is None:
            timestamp = float(time.time())
        offset = timestamp - self.__born_timestamp
        self.__internal_data_buffer = {
            "source": self._name,
            "offset": offset
        }
        return timestamp

    def log_internal_metric(self, key, val, flush=False, timestamp=None, offset=None):
        self.state_manager.assert_start()
        self.__internal_data_buffer[key] = val
        if flush and timestamp is not None:
            self.flush_internals(timestamp=timestamp)
        elif flush and offset is not None:
            self.flush_internals(offset=offset)
        elif flush:
            self.flush_internals()
        
    def flush_internals(self, timestamp=None, offset=None):
        if not self.__end_flag.empty():
            # this means that manager is stopping
            # and data is no longer accepted
            return None

        if offset is not None:
            self.__internal_data_buffer["offset"] = offset
        elif timestamp is not None:
            offset = timestamp - self.__born_timestamp
            self.__internal_data_buffer["offset"] = offset

        if len(self.__internal_data_buffer) > 2:
            self.queue.put(self.__internal_data_buffer)
        return self.init_internal_entity()

    def log_final_metric(self, key, val):
        self.state_manager.assert_no_init()
        prefixed_key = f"{self._name}_{key}"
        self.final_metrics[prefixed_key] = val

    def calculate_final_metrics(self):
        return self.final_metrics


class DeamonCollector(Collector):
    def __init__(self, name=None, timestamp=None, cmd=""):
        Collector.__init__(self, name, timestamp)
        self.__process = None
        self.__cmd = cmd

    def flush_stdout(self):
        try:
            lines = self.__process.stdout.readlines()
        except ValueError:
            return 0

        counter = 0
        for line in lines:
            line = line.decode(sys.stdout.encoding, 'ignore')
            self.analyze(line)
            counter += 1
        self._counter += counter
        return counter

    def analyze(self, line):
        raise NotImplementedError("Abstract Class!")

    def start(self):
        if self.__process is not None: return None
        self.logger.info(f"try to execute: {self.__cmd}")
        self.__process = Popen(shlex.split(self.__cmd), stdout=PIPE)
        fflags = fcntl.fcntl(self.__process.stdout, fcntl.F_GETFL) | os.O_NONBLOCK
        fcntl.fcntl(self.__process.stdout, fcntl.F_SETFL, fflags)
        self.state_manager.start()
        return self.__process

    def stop(self):
        self.__process.kill()
        self.__process.communicate()
        self.flush_stdout()
        self.flush_internals()
        self.state_manager.stop()

        
class DeamonExporter:
    def __init__(self, interval=1, accept="all"):
        assert accept in ("all", "internal", "final")
        if accept == "internal":
            self.process_final = lambda item: None
        if accept == "final":
            self.process_internal = lambda item: None
        self.excluding_sources = set()
        self.queue = QueueFunc()

        typename = type(self).__name__
        self.logger = get_logger(f"collsys.{typename}")
        self.logger.info("init exporter")

        assert int(interval) > 0, "interval has to be > 0"
        self.interval = int(interval)

        self.state_manager = StateManager("exporter", typename)
        self.counter = 0

    def __repr__(self):
        c = self.queue.qsize()
        out = f"{c}/{self.counter} - "
        state = self.state_manager.get_state()
        out += f"{type(self).__name__} ({state})"
        return out

    def flush(self):
        try:
            item = self.queue.get(False)
        except Empty:
            return True

        itemtype = classify_item(item)
        if itemtype == item_type_final:
            self.process_final(item)
        elif itemtype == item_type_internal:
            self.process_internal(item)
        elif itemtype == item_type_end:
            return False
        else:
            # this block will be called when extended collector
            # produces unexpected data format / structure. 
            raise AssertionError("internal error! Wrong data.")
        return True

    def exclude_collector(self, name):
        info = "Error! Broadcast data cannot be excluded."
        assert name is not None, info
        self.excluding_sources.add(name)

    def clean_finals(self, finals):
        new_finals = {}
        for key, val in finals.items():
            if type(key) is str:
                source = key.split("_")[0]
            elif type(key) is tuple:
                source = key[0].split("_")[0]
            else:
                info = "extention emits not supported keys"
                raise ValueError(info)
            if source not in self.excluding_sources:
                new_finals[key] = val
        return new_finals

    def process_internal(self, item): pass
    def process_final(self, item): pass

    def run(self, queue):
        self.prepare()
        while self.flush():
            if queue.empty():
                time.sleep(self.interval)
            else:
                self.counter += 1
        self.finish()

    def prepare(self): pass
    def finish(self): pass


class Analyzer(Namer):
    def __init__(self, name):
        Namer.__init__(self, name)
        self._sources = {}

        typename = type(self).__name__
        self.logger = get_logger(f"collsys.{typename}.{name}")

    def __repr__(self):
        typename = type(self).__name__
        name = self._name
        out = f"{typename} - {name}"
        for k, v in self._sources:
            out += f" {k}({v})"
        return out
        
    def register_collector(self, collector, role=None):
        info = "collector has to be Collector type"
        assert isinstance(collector, (Collector,)), info
        source = collector.get_name()

        if source in self._sources:
            self.logger.warning(f"reregistration of {source}")
        self._sources[source] = role

    def put(self, source, item):
        return source in self._sources

    def calculate_final_metrics(self):
        return {}


class CollectionManager:
    __attemps_to_finish_export = 5

    def __init__(self):
        self.__analyzers = []
        self.__exporters = []
        self.__collectors = []
        self.__export_processes = []
        self.__state_manager = StateManager("manager", "main")

        self.__collecting_counter = 0
        self.__exporting_counter = 0
        self.__acollend_counter = 0

        self.__poller = select.poll()
        self.__end_flag = QueueFunc()
        self.__finals_buffer = {}
        
        typename = type(self).__name__
        self.__logger = get_logger(f"collsys.{typename}")
        self.__logger.info("init manager")
        
    def get_counters(self, key=None):
        cc = self.__collecting_counter
        ec = self.__exporting_counter
        ac = self.__acollend_counter
        if key is None:
            return cc, ec, ac
        elif key == "acollend":
            return ac
            
    def __repr__(self):
        cs = self.create_collecting_status()
        ns = self.create_analyzing_status()
        es = self.create_exporting_status()
        state = self.__state_manager.get_state()
        out = "*** Manager ***\n"
        out += f"state: {state}\n"
        out += f"{cs}\n"
        out += f"{ns}\n"
        out += f"{es}\n***\n"
        return out

    def register_exporter(self, exporter):
        info = "exporter has to be DeamonExporter type"
        assert isinstance(exporter, (DeamonExporter,)), info
        exporter.state_manager.register()
        self.__exporters.append(exporter)
        
        typename = type(exporter).__name__
        self.__logger.info(f"register {typename}")

    def register_collector(self, collector):
        info = "collector has to be Collector type"
        assert isinstance(collector, (Collector,)), info
        for ca in self.__collectors + self.__analyzers:
            collector.assert_name(ca)
        self.__collectors.append(collector)
        collector.set_end_flag(self.__end_flag)
        collector.state_manager.register()

        typename = type(collector).__name__
        self.__logger.info(f"register {typename}")

    def register_analyzer(self, analyzer):
        info = "analyzer has to be Analyzer type"
        assert isinstance(analyzer, (Analyzer,)), info
        for ca in self.__collectors + self.__analyzers:
            analyzer.assert_name(ca)
        self.__analyzers.append(analyzer)
 
        typename = type(analyzer).__name__
        self.__logger.info(f"register {typename}")
        
    def __call_deamon_methods(self, method, *args, **kwargs):
        def check_deamon_collector(collector):
            return isinstance(collector, (DeamonCollector,))

        for collector in filter(check_deamon_collector, self.__collectors):
            if method == "start":
                proc = collector.start()
                assert proc is not None
                self.__poller.register(proc.stdout, select.POLLIN)

            elif method == "stop":
                collector.stop()

            elif method == "flush_stdout":
                collector.flush_stdout()

            else: raise AssertionError(f"no supported method: {method}")

    def log_collecting_status(self):
        status = self.create_collecting_status()
        self.__logger.info(status)

    def create_collecting_status(self):
        out = "*** Collectors"
        for c in self.__collectors:
            out += f"\n* {c}"
        return out

    def log_exporting_status(self):
        status = self.create_exporting_status()
        self.__logger.info(status)

    def create_exporting_status(self):
        out = "*** Exporters"
        for e in self.__exporters:
            out += f"\n* {e}"
        return out

    def log_analyzing_status(self):
        status = self.create_analyzing_status()
        self.__logger.info(status)

    def create_analyzing_status(self):
        out = "*** Analyzers"
        for a in self.__analyzers:
            out += f"\n* {a}"
        return out

    def start_deamon_collectors(self):
        self.__call_deamon_methods("start")

    def stop_deamon_collectors(self):
        self.__call_deamon_methods("stop")

    def flush_deamon_collectors(self):
        self.__call_deamon_methods("flush_stdout")

    def wait_for_deamon_collectors(self, timeout):
        return self.__poller.poll(timeout * 1E2)

    def raise_working_exporter(self, exporter):
        items_in_queue = exporter.queue.qsize()
        if items_in_queue > 1:
            typename = type(exporter).__name__
            self.__logger.info(f"wait for {typename}")
            raise ChildProcessError
    
    def wait_for_exporters(self):        
        unfinished_exports = []
        time.sleep(0.5)
        for exporter in self.__exporters:
            try:
                retry_call(self.raise_working_exporter, fargs=[exporter],
                           tries=self.__attemps_to_finish_export, delay=1,
                           exceptions=ChildProcessError, logger=None)
            except ChildProcessError:
                typename = type(self).__name__
                unfinished_exports.append(typename)
                items_in_queue = exporter.queue.qsize()
                info = f"{items_in_queue} not processed items in {typename}."
                self.__logger.warning(info)

        if unfinished_exports:
            cnt = len(unfinished_exports)
            estr = ", ".join(unfinished_exports)
            info = f"{cnt} exporter(s) ({estr}) did not finish job properly."
            self.__logger.warning(info)

    def start_exporters(self):
        for exporter in self.__exporters:
            typename = type(exporter).__name__
            self.__logger.info(f"start {typename}...")
            p = Process(target=exporter.run, args=(exporter.queue,))
            self.__export_processes.append(p)
            exporter.state_manager.start()
            p.deamon = True
            p.start()
        self.__logger.info(f"finish starting exporters...")

    def analyze_item(self, item, source):
        for analyzer in self.__analyzers:
            analyzer.put(source, item)
            
    def get_finals(self, key=None, source=None):
        if key is None:
            if source is not None:
                self.__logger.warning("Source is ignored!")
            return self.__finals_buffer
        if source is not None:
            key = f"{source}_{key}"
        return self.__finals_buffer[key]

    def export_item(self, item, source):
        if item is not None:
            self.__finals_buffer.update(item)
        def exclude_exporter(exporter):
            return source not in exporter.excluding_sources

        exported = False
        for exporter in filter(exclude_exporter, self.__exporters):
            exporter.queue.put(item)
            exporter.counter += 1
            exported = True
        if exported:
            self.__exporting_counter += 1
            
    def flush(self):
        # forward data through piplines
        self.flush_deamon_collectors()
        for collector in self.__collectors:
            source = collector.get_name()
            while not collector.queue.empty():
                item = collector.get()
                itemtype = classify_item(item)

                if itemtype == item_type_internal:
                    self.__collecting_counter += 1
                    self.analyze_item(item, source)
                    self.export_item(item, source)

                elif itemtype == item_type_final:
                    for key, val in item.items():
                        collector.log_final_metric(key, val)

                elif itemtype == item_type_end:
                    self.__acollend_counter += 1

    def stop_exporters(self):
        self.export_item(None, None)
        self.flush()
        for exporter in self.__exporters:
            exporter.state_manager.stop()

    def stop_collectors(self):
        self.__end_flag.put(None)
        time.sleep(0.1)
        self.stop_deamon_collectors()
        self.flush()
        time.sleep(0.1)

        common_finals = {}
        for collector in self.__collectors:
            finals = collector.calculate_final_metrics()
            common_finals.update(finals)
        for analyzer in self.__analyzers:
            finals = analyzer.calculate_final_metrics()
            common_finals.update(finals)
        self.export_item(common_finals, None)

    def start(self):
        self.__logger.info("start in")
        self.start_exporters()
        self.__logger.info("start daemon collectors...")
        self.start_deamon_collectors()
        self.__state_manager.start()
        def check_not_deamon_collector(collector):
            return not isinstance(collector, (DeamonCollector,))
        for collector in filter(check_not_deamon_collector, self.__collectors):
            collector.state_manager.start()
        self.__logger.info("start out")

    def stop(self):
        self.flush()
        self.__logger.info("stop in")
        self.__logger.info("wait for collectors...")
        self.stop_collectors()
        self.__logger.info("wait for exporters...")
        self.wait_for_exporters()
        self.stop_exporters()
        for proc in self.__export_processes:
            proc.join()
        self.__state_manager.stop()
        self.__logger.info("stop out")
