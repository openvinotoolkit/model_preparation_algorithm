#
# INTEL CONFIDENTIAL
# Copyright (c) 2021 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import re
import time

from e2e.collection_system.downloader import DownloaderScriptBase


class _MemoryDownloader(DownloaderScriptBase):
    commands = ["free -k"]

    def reprint_output(self, output):
        print("{")
        for n, line in enumerate(output):
            raw_line = line.strip()
            prefix = None

            if re.findall("^Mem", raw_line):
                prefix = "mem"

            elif re.findall("^Swap", raw_line):
                prefix = "swap"

            if prefix is not None:
                dig_line = re.sub(r"[^0-9]+", ":", raw_line)
                parts = dig_line.split(":")

                total = int(parts[1])
                used = int(parts[2])
                free = int(parts[3])

                print(f"   \"{prefix}_total\": {total},")
                print(f"   \"{prefix}_used\": {used},")
                print(f"   \"{prefix}_free\": {free},")
                
        # add timestamp/offset in the first significant line
        offset = round(time.time() - self.start_time, 3)
        print(f"   \"offset\": {offset}")
        print("}")

downloader = _MemoryDownloader()
downloader.run_in_loop()
