#
# INTEL CONFIDENTIAL
# Copyright (c) 2021 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import re
import os
import sys
import time
from abc import ABC, abstractmethod

from e2e.ssh_lib import JumpClient
from e2e import config as e2e_config

import e2e.collection_system.core
from e2e.collection_system.core import DeamonCollector
from e2e.logger import get_logger


class DownloaderHandler(DeamonCollector): 
    _root = os.path.dirname(e2e.collection_system.core.__file__)
    _executor = None
    _script = None

    def __init__(self, name, address, user=None, password=None, timestamp=None, interval=2):
        path = os.path.join(self._root, self._script)
        assert os.path.exists(path), f"{path} is empty"
        cmd = f"{self._executor} {path} -i {interval} -a {address}"
        cmd += "" if password is None else f" -u {password}"
        cmd += "" if user is None else f" -u {user}"

        DeamonCollector.__init__(self, name, timestamp, cmd)
        self.__init_new_batch()
        self._checkpoints = 0

    def analyze(self, line):
        # check log is added by command wrapper
        if re.findall("^[0-9]{4}-[0-9]{2}-[0-9]{2}", line):
            return

        self.__batch.append(line)
        self.__counter += line.count("{")
        if self.__counter > 0:
            self.__dict_detection = True            
        self.__counter -= line.count("}")

        if self.__counter == 0 and self.__batch:
            if self.__dict_detection:
                self.process_batch()
            self.__init_new_batch()

    def __init_new_batch(self):
        self.__dict_detection = False
        self.__counter = 0
        self.__batch = []

    def calculate_final_metrics(self):
        self.log_final_metric("checkpoints", self._checkpoints)
        return self.final_metrics

    def get_raw_batch(self):
        content = filter(lambda line: line[0] != "#", self.__batch)
        return "".join(content)

    def process_batch(self):
        data_source = self.get_raw_batch()
        data_dict =  eval(data_source)
        return data_dict
        
class DownloaderScriptBase(ABC):
    commands = []

    def __init__(self):
        self.cmd_options = {}
        self.user = self.__get_arg_value("-u", e2e_config.env_user)
        self.password = self.__get_arg_value("-p", e2e_config.env_pass)
        self.interval = int(self.__get_arg_value("-i", 5))
        self.timeout = self.__get_arg_value("-t", "inf")
        self.address = self.__get_arg_value("-a")
        self.handler = JumpClient(remote_username=self.user,
                                  remote_password=self.password,
                                  remote_host=self.address,
                                  tty_required=True)
        self.time_to_stop = 0
        if self.timeout != "inf":
            self.time_to_stop = time.time() + int(self.timeout)  
        self.start_time = time.time()

    def __get_arg_value(self, key, default=None):
        try:
            n = sys.argv.index(key)
            value = sys.argv[n+1]
            self.cmd_options[key] = value
            return value
        except ValueError:
            assert default is not None, f"{key} is None"
            self.cmd_options[key] = default
            return default

    def run_in_loop(self):
        kwargs = {"remote_command": self.commands}
        counter = 0
        while True:
            print(f"# start step {counter}")
            output, code, _ = self.handler.execute_ssh_command(**kwargs)
            if code != 0:
                raise ValueError(f"command returned code: {code}")
            self.reprint_output(output)
            if self.time_to_stop:
                if time.time() > self.time_to_stop:
                    break

            time.sleep(self.interval)
            print(f"# stop step {counter}")
            counter += 1

    @abstractmethod
    def reprint_output(self, output):
        raise NotImplementedError()
