#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
"""Module that implements api admin calls."""
import urllib.parse


from e2e import config
from requests.models import Response

from e2e.http_client import HttpMethod
from e2e.http_client.http_client import HttpClient


def get(client: HttpClient) -> Response:
    """GET /

    Returns main uaa endpoint

    Args:
      client: HttpClient that will perform the request

    Returns:
      Response
    """
    return client.request(HttpMethod.GET, path="", raw_response=True,
                          msg="Get uaa main endpoint ")


def token(client: HttpClient, username: str, password: str) -> Response:
    """POST /

    Returns the logged-in user's access token

    Args:
    client: HttpClient that will perform the request
    username: user that we are going generating token for
    password: password of mentioned user

    Returns:
    Response
    """

    """
    When this project will use UAA:
            params = {'client_id': 'nauta-user',
                  'client_secret': '',
                  'grant_type': 'password',
                  'username': username,
                  'password': password,
                  'response_type': 'id_token'}
    """

    params = {'client_id': 'SUCZFpKCEmTzqkb2IsTDVnnyfo5DKDPO',
              'grant_type': 'password',
              'username': username,
              'password': password,
              'connection': 'Username-Password-Authentication',
              'scope': 'openid'}

    params = urllib.parse.urlencode(params)
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    return client.request(HttpMethod.POST, path=config.api_token_endpoint,
                          headers=headers, data=params)


def logout(client: HttpClient) -> Response:
    """GET /

    Logout from UAA
    Particular cookie in session object will expire after that call

    Args:
    client: HttpClient that will perform the request

    Returns:
    Response
    """

    return client.request(HttpMethod.GET, path='logout.do', msg="Logout from Uaa ")


def get_token(client: HttpClient) -> Response:
    """GET /

    Returns login html-template uaa endpoint

    Args:
    client: HttpClient that will perform the request

    Returns:
    Response
    """

    return client.request(HttpMethod.GET, path='login', msg="Login to Uaa ")


def login(client: HttpClient, email: str, password: str, uaa_token: str) -> Response:
    """POST /

    Returns the logged in user in the session

    Args:
    client: HttpClient that will perform the request
    email: To login
    password: To login
    uaa_token: To meet the requirements of the UAA

    Returns:
    Response
    """

    payload = {'X-Uaa-Csrf': uaa_token,
               'username': email, 'password': password}

    return client.request(HttpMethod.POST, path='login.do', msg="Login to Uaa by POST", data=payload)


def force_reset_password(client: HttpClient, password: str, uaa_token: str) -> Response:
    """POST /

    Returns login uaa endpoint

    Args:
    client: HttpClient that will perform the request
    password: To change password after login
    uaa_token: To meet the requirements of the UAA

    Returns:
    Response
    """

    payload = {'_csrf': uaa_token,
               'password': password, 'password_confirmation': password}

    return client.request(HttpMethod.POST, path='force_password_change', msg="Login to Uaa by POST", data=payload)
