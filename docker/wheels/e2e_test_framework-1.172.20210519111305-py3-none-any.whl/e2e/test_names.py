#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

import os
import random
import re
import socket
import string
from datetime import datetime

from e2e import config


class E2EObjectName:
    _date_format, _time_format, _ms_format = "%d", "%H%M%S", "%f"
    _NON_ALPHA_NUM = r'[^a-z0-9]+'
    MAXIMAL_OBJECT_NAME = 32

    def __init__(self, short=False, prefix=config.tests_owner, separator='_'):
        worker_id = os.environ.get("PYTEST_XDIST_WORKER", "")
        self._prefix = self.prefix(prefix)
        self._prefix = "{}{}".format(worker_id, self._prefix)
        self._separator = separator
        self._short = short
        self._now = datetime.now()

    def __str__(self):
        separator = '' if self._short else self._separator
        parts = [self._prefix] + self.stem
        name = separator.join(parts).lower()
        return re.sub(self._NON_ALPHA_NUM, separator, name)

    def prefix(self, prefix=config.tests_owner):
        max_prefix = 12
        hostname = socket.gethostname().split(".", 1)[0].lower()
        hostname = re.sub(self._NON_ALPHA_NUM, "", hostname)
        prefix = re.sub(self._NON_ALPHA_NUM, "", str(prefix))
        if len(prefix + hostname) <= max_prefix:
            return prefix + hostname
        shorter = min(prefix, hostname, key=len)
        longer = hostname if shorter == prefix else prefix
        shorter_len = min(len(shorter), max_prefix//2)
        if shorter == prefix:
            if hostname.isdigit():
                return prefix[:shorter_len] + hostname[len(hostname)-(max_prefix-shorter_len):]
            else:
                return prefix[:shorter_len] + hostname[:max_prefix-shorter_len]
        else:
            if hostname.isdigit():
                return prefix[:max_prefix-shorter_len] + hostname[len(hostname)-shorter_len:]
            else:
                return prefix[:max_prefix-shorter_len] + hostname[:shorter_len]

    @property
    def stem(self) -> list:
        seed = [
            self._now.strftime(self._date_format),
            self._now.strftime(self._time_format),
            self._now.strftime(self._ms_format)
        ]

        if config.unique_id:
            seed[-1] = '{:0>6}'.format(config.unique_id)

        return seed[:2] if self._short else seed

    def build(self) -> str:
        return str(self)[-self.MAXIMAL_OBJECT_NAME:]

    def as_email(self) -> str:
        email_format = config.test_user_email.replace('@', '+{}@')
        email = email_format.format(self.build())
        if len(email.split("@")[0]) > 64:
            email = self.shorten_email_address(email)
        return email

    def shorten_email_address(self, email) -> str:
        year_month = self._now.strftime("%Y%m")
        return email.replace(year_month, "")


def is_test_object_name(name):
    """Return True if object's name matches pattern for test names, False otherwise."""
    if name is None:
        return False  # there are users with username=None
    test_name_regex = r'^.*[0-9]{2,8}(.*)[0-9]{6}\1([0-9]{6,})?(@gmail.com)?$'
    return re.match(test_name_regex, name) is not None


def generate_test_object_name(email=False, short=False,
                              prefix=config.tests_owner,
                              separator="_"):
    # TODO add global counter
    name = E2EObjectName(short=short, prefix=prefix, separator=separator)
    return name.as_email() if email else name.build()


def adjust_test_object_name_to_length(name, length):
    if len(name) > length:
        return name[:length]
    else:
        return "{}{}".format(name, ''.join(random.choice(string.digits) for _ in range(length-len(name))))
