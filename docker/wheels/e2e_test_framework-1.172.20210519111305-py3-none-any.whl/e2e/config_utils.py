#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

import os

from ipaddress import ip_address as raise_value_exception_if_not_ip_address

PROXY_KEYS = ["http_proxy", "https_proxy", "HTTP_PROXY", "HTTPS_PROXY"]

ONE_K = 1024
ONE_M = ONE_K * ONE_K

MAX_LOGGED_COMMAND_RUN_OUTPUT_LENGTH_DEFAULT = 10 * ONE_M


class Environment:
    UNKNOWN = "head.xip.io"

    def __init__(self, name: str = None, dns: str = None, ip: str = None) -> None:
        self._env_dns = None
        self._env_ip = None
        self._addresses = set()
        self._name = name
        self._env_main = None
        self._API = None
        self.env_dns = dns
        self.env_ip = ip

    @property
    def name(self):
        return self._name if self._name is not None else self.env_main

    @property
    def env_main(self):
        if self._env_dns is not None:
            return self._env_dns
        elif self.env_ip is not None:
            return self.env_ip
        else:
            return self.env_dns

    @env_main.setter
    def env_main(self, dns_or_ip):
        try:
            raise_value_exception_if_not_ip_address(dns_or_ip)
            self.env_ip = dns_or_ip
            self._env_dns = None
        except ValueError:
            self.env_ip = None
            self._env_dns = dns_or_ip

    @property
    def env_dns(self):
        return self._env_dns if self._env_dns is not None else self.UNKNOWN

    @env_dns.setter
    def env_dns(self, dns):
        if self._env_dns in self._addresses:
            self._addresses.remove(self._env_dns)
        self._env_dns = dns
        if self._env_dns is not None:
            self._addresses.add(self._env_dns)

    @property
    def env_ip(self):
        return self._env_ip

    @env_ip.setter
    def env_ip(self, ip):
        if self._env_ip in self._addresses:
            self._addresses.remove(self._env_ip)
        self._env_ip = ip
        if self._env_ip is not None:
            self._addresses.add(self._env_ip)

    @property
    def addresses(self):
        return set(self._addresses)

    def add(self, host_or_ip):
        if host_or_ip is not None:
            self._addresses.add(host_or_ip)

    def remove(self, host_or_ip):
        if host_or_ip is not None and host_or_ip in self._addresses:
            self._addresses.remove(host_or_ip)

    @property
    def api(self):
        return self._API if self._API is not None else self.env_main

    @api.setter
    def api(self, api):
        self._API = api


def delete_empty_env_variables():
    """
    Delete from os.environ items whose key starts with TT_ and whose values are empty.
    When tests are run on TeamCity, empty environment variables are set.
    """
    empty_variables = []
    for key_name, value in os.environ.items():
        if key_name.startswith("TT_") and value == "":
            empty_variables.append(key_name)
    for key_name in empty_variables:
        del os.environ[key_name]


def delete_environment_proxy_variables():
    """
    Delete from os.environ all element specific for http(s) proxies
    """
    variables_to_remove = []
    for key_name, value in os.environ.items():
        if key_name in PROXY_KEYS:
            variables_to_remove.append(key_name)
    for key_name in variables_to_remove:
        del os.environ[key_name]


def get_bool(key_name, fallback=None):
    value = os.environ.get(key_name, fallback)
    if value != fallback:
        value = value.lower()
        if value == "true":
            value = True
        elif value == "false":
            value = False
        else:
            raise ValueError("Value of {} env variable is '{}'. Should be 'True' or 'False'.".format(key_name, value))
    return value


def get_int(key_name, fallback=None):
    value = os.environ.get(key_name, fallback)
    if value != fallback:
        try:
            value = int(value)
        except ValueError:
            raise ValueError("Value '{}' of {} env variable cannot be cast to int.".format(value, key_name))
    return value


def get_float(key_name, fallback=None):
    value = os.environ.get(key_name, fallback)
    if value != fallback:
        try:
            value = float(value)
        except ValueError:
            raise ValueError("Value '{}' of {} env variable cannot be cast to float.".format(value, key_name))
    return value


def assert_config_value_set(variable_name):
    attr = globals().get(variable_name)
    assert attr is not None, "Configuration variable '{}' not set.".format(variable_name)


def get_list(key_name, delimiter=',', fallback=None):
    value = os.environ.get(key_name, fallback)
    if value != fallback:
        value = value.split(delimiter)
    elif not value:
        value = []
    return value


def get_url(variable_name, address, protocol, prefix=None, port=None):
    url = os.environ.get(variable_name)
    if url is None and address is not None:
        port = ":{}".format(port) if port is not None else ""
        prefix = "{}.".format(prefix) if prefix is not None else ""
        url = "{}://{}{}{}".format(protocol, prefix, address, port)
    return url
