#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
"""Class for getting time and date from appliance"""

from datetime import timedelta, datetime

from e2e.command_wrappers.date import Date
from e2e.ssh_lib import JumpClient


class DateTime:
    """Data and time"""
    ISO_8601_DATE_TIME_WITH_SECONDS_FORMAT = r"%Y-%m-%dT%H:%M:%S%z"
    JOURNAL_SINCE_UNTIL_DATE_TIME_FORMAT = r"%Y-%m-%d %H:%M:%S"
    AUSEARCH_SINCE_UNTIL_DATE_TIME_FORMAT = r"%x %T"
    TIME_TOLERANCE_MIN = timedelta(minutes=3)
    TEST_SESSION_START = None  # type: datetime

    def __init__(self, head_client: JumpClient):
        self.client = head_client
        assert self.client is not None, "Lack of jump client, is None"

    def _get_date_time(self, date: Date):
        """get head date time."""
        expected_output_lines = 1
        output, ret_code, pid = self.client.execute_ssh_command(date)
        assert ret_code == 0, "non zero ret code"
        assert len(output) == expected_output_lines, "output too long"
        date_time = str(output[0]).strip()
        assert len(date_time), "Cannot get date time"
        return date_time

    def get_date_time_with_format(self, format_=JOURNAL_SINCE_UNTIL_DATE_TIME_FORMAT):
        """get head date time in format accepted by JournalCtl until and since options."""
        return self._get_date_time(Date(format_=format_))

    def get_date_time_for_journal_ctl(self) -> str:
        """get head date time as a datetime object."""
        return self.get_date_time_with_format(self.JOURNAL_SINCE_UNTIL_DATE_TIME_FORMAT)

    @staticmethod
    def cleaner(time: timedelta):
        time -= timedelta(microseconds=time.microseconds)
        return time

    @staticmethod
    def compare_time(server_time, local_time):
        if server_time >= local_time:
            return server_time - local_time < DateTime.TIME_TOLERANCE_MIN
        else:
            return local_time - server_time < DateTime.TIME_TOLERANCE_MIN
