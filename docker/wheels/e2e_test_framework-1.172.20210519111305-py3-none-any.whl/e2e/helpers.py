#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
from abc import ABCMeta
from collections import defaultdict
from typing import Any, Tuple, List, Generator

from e2e.config_utils import ONE_K


def find_duplicates(elements):
    seen = set()
    dupes = defaultdict(lambda: 1)

    for x in elements:
        if x not in seen:
            seen.add(x)
        else:
            dupes[x] += 1
    return dict(dupes)


class SingletonMeta(type):
    """
    Metaclass for defining Singleton Classes

    src:
    https://www.datacamp.com/community/tutorials/python-metaclasses

    Singleton Design using a Metaclass

    This is a design pattern that restricts the instantiation of a class to only one object.
    This could prove useful for example when designing a class to connect to the database.
    One might want to have just one instance of the connection class.
    """
    _instances = {}

    def __call__(cls, *args: Any, **kwargs: Any) -> Any:
        if cls not in cls._instances:
            cls._instances[cls] = super().__call__(*args, **kwargs)
        return cls._instances[cls]


class NamedSingletonMeta(type):
    """
    Metaclass for defining Named Singleton Classes (extension for Singleton Classes)

    src:
    https://www.datacamp.com/community/tutorials/python-metaclasses

    Singleton Design using a Metaclass

    This is a design pattern that restricts the instantiation of a class to only one object.
    This could prove useful for example when designing a class to connect to the database.
    One might want to have just one instance of the connection class.
    """
    _instances = defaultdict(dict)

    def __call__(cls, name: str, *args: Any, **kwargs: Any) -> Any:
        name = name.lower()
        if name not in cls._instances[cls]:
            cls._instances[cls][name] = super().__call__(name, *args, **kwargs)
        return cls._instances[cls][name]


class SingletonABCMeta(SingletonMeta, ABCMeta):
    pass


class Chunks(Generator):
    """
    generator yielding tuple: no of part, number of parts, and part of the input list
    """
    def __init__(self, seq: List[str], max_number_of_elements: int = 1000) -> None:
        super().__init__()
        self.seq = tuple(seq)
        assert max_number_of_elements > 0, "Incorrect number of elements, should be more than zero"
        self.chunk_len = max_number_of_elements
        self.no_of_chunks = (len(self.seq) // self.chunk_len) + 1
        self.current_chunk = 0
        self.index_iterator = iter(range(0, len(self.seq), self.chunk_len))

    def __next__(self) -> Tuple[int, int, list]:
        return self.send(None)

    def __iter__(self) -> 'Chunks':
        return self

    def send(self, ignored_value) -> Tuple[int, int, list]:
        index = next(self.index_iterator)
        return_chunk = self.current_chunk, self.no_of_chunks, list(self.seq[index:index + self.chunk_len])
        self.current_chunk += 1
        return return_chunk

    def throw(self, typ, val=None, tb=None):
        raise StopIteration

    def close(self) -> None:
        raise GeneratorExit


def list_trimmer(seq: list, max_number_of_elements: int = 4 * ONE_K):
    if len(seq) > max_number_of_elements:
        first_element = ["Too long output was trimmed! Original len {}, showing first and last {} lines:"
                         .format(len(seq), max_number_of_elements // 2)]
        seq = first_element + seq[:max_number_of_elements // 2] + ["", "[...]", ""] + seq[-max_number_of_elements // 2:]
    return seq


def line_trimmer(line: str, max_number_of_elements: int = 1 * ONE_K // 4):
    if len(line) > max_number_of_elements:
        line = "t: " + \
               line[:max_number_of_elements // 2] + \
               "[...]" + \
               line[-max_number_of_elements // 2:]
    return line


def log_trimmer(logs: str):
    logs_list = logs.split(sep="\n")
    logs_list = [line_trimmer(line) for line in logs_list]
    logs_trimmed = list_trimmer(seq=logs_list, max_number_of_elements=ONE_K)
    logs = "\n".join(logs_trimmed)
    return logs
