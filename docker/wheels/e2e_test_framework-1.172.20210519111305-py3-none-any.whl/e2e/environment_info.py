#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
"""Implementation that stores basic details about environment"""
import importlib

from e2e import config
from e2e.logger import get_logger

logger = get_logger(__name__)

DEFAULT_BUILD_NUMBER = 0
DEFAULT_SHORT_VERSION_NUMBER = "0.0.0"
DEFAULT_RELEASE_TYPE = "snapshot"
DEFAULT_FULL_VERSION_NUMBER = "{}-{}-{}".format(DEFAULT_SHORT_VERSION_NUMBER, config.product_version_suffix,
                                                DEFAULT_BUILD_NUMBER)
DEFAULT_INSTALL_PACKAGE_NAME = None
DEFAULT_SCM_REPOSITORY_STATE = None


class EnvironmentInfo(object):
    """Stores details about environment such as build number, version number
    and allows their retrieval"""
    module_class_string = config.info_module
    module_name, class_name = module_class_string.rsplit(".", 1)
    module = importlib.import_module(module_name)
    class_info = getattr(module, class_name)
    env_info = class_info()

    @classmethod
    def get_build_number(cls):
        """Retrieves build number from the environment info"""
        if config.product_build_number_from_env:
            return cls._retrieve_build_number_from_environment()
        if config.product_build_number:
            return config.product_build_number
        return DEFAULT_BUILD_NUMBER

    @classmethod
    def get_version_number(cls):
        """Retrieves version number from the environment info"""
        if config.product_version_number_from_env:
            return cls._retrieve_version_number_from_environment()
        if config.product_version:
            return config.product_version
        return DEFAULT_FULL_VERSION_NUMBER

    @classmethod
    def get_install_package_name(cls):
        """Retrieves install package name from the environment info"""
        if config.install_package_name_from_env:
            return cls._retrieve_install_package_name_from_environment()
        if config.install_package_name:
            return config.install_package_name
        return DEFAULT_INSTALL_PACKAGE_NAME

    @classmethod
    def get_scm_repository_state(cls):
        """Retrieves install package name from the environment info"""
        if config.scm_repository_state_from_env:
            return cls._retrieve_scm_repository_state_from_environment()
        if config.scm_repository_state:
            return config.scm_repository_state
        return DEFAULT_SCM_REPOSITORY_STATE

    @classmethod
    def get_environment_name(cls):
        """Retrieves the environment name that will be reported for a test run"""
        return config.environment.name

    @classmethod
    def get_os_distname(cls):
        """Retrieves the operating system distribution name"""
        return cls.env_info.os_distname

    @classmethod
    def get_release_type(cls):
        """Retrieves release type"""
        if config.release_type:
            return config.release_type
        return DEFAULT_RELEASE_TYPE

    @classmethod
    def _retrieve_version_number_from_environment(cls):
        return cls._version_number_from_environment_version(cls.env_info.version)

    @classmethod
    def _retrieve_build_number_from_environment(cls):
        return cls._build_number_from_environment_version(cls.env_info.version)

    @classmethod
    def _retrieve_install_package_name_from_environment(cls):
        return cls.env_info.install_package_name

    @classmethod
    def _retrieve_scm_repository_state_from_environment(cls):
        return cls.env_info.scm_repository_state

    @classmethod
    def _build_number_from_environment_version(cls, environment_version):
        return environment_version.split("-")[-1]

    @classmethod
    def _version_number_from_environment_version(cls, environment_version):
        return '-'.join(environment_version.split('-')[:2])
