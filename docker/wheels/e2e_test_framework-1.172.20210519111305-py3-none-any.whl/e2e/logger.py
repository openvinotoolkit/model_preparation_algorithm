#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import inspect
import json
import logging
import os
import sys
import traceback
import weakref
from datetime import datetime
from typing import cast, List, Union, TYPE_CHECKING

import requests

from e2e import config
from e2e.constants.logger_type import LoggerType
from e2e.current_os_info import CurrentOsInfo
from e2e.helpers import Chunks
from e2e.logging_filters import SensitiveKeysStrippingFilter

if TYPE_CHECKING:
    from _pytest.nodes import Item

SEPARATOR = "=" * 20
FIXTURE_SEPARATOR = "*" * 20


log_username = f"- [{config.host_os_user}] " if config.log_username else ""
worker_count = config.get_int("PYTEST_XDIST_WORKER_COUNT", 0)
worker_id = os.environ.get("PYTEST_XDIST_WORKER", "")
worker_string = f"[{worker_id}] " if worker_count > 0 else ""
logger_format = config.logger_format(worker_string, log_username)


class E2eFileHandler(logging.FileHandler):
    def __init__(self, item: Union["Item", str] = None,
                 mode='a', encoding=None, delay=False):
        self.filename = item if isinstance(item, str) else self.log_file_name(item)
        file_path = os.path.join(config.test_log_directory, self.filename)
        if item is not None:
            item._log_file_name = self.filename
        super().__init__(file_path, mode, encoding, delay)
        fmt = logging.Formatter(logger_format)
        self.setFormatter(fmt)

    @staticmethod
    def safe_node_id(item: "Item"):
        node_id = "__".join(item.nodeid.split("/"))
        node_id = "..".join(node_id.split("::"))
        return node_id

    @classmethod
    def log_file_name(cls, item: "Item" = None):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        worker = f"_{worker_id}" if worker_count > 0 else ""
        prefix = f"{cls.safe_node_id(item)}" if item is not None else "api_tests"
        file_name = f"{prefix}{worker}_{timestamp}.log"
        return file_name

    @staticmethod
    def __opener(file, flags):
        try:
            import os
            import win32file
            import win32security
            import msvcrt
        except ImportError:
            return None
        secur_att = win32security.SECURITY_ATTRIBUTES()
        secur_att.Initialize()
        handle = win32file.CreateFile(file,
                                      win32file.GENERIC_READ | win32file.GENERIC_WRITE,
                                      win32file.FILE_SHARE_DELETE |
                                      win32file.FILE_SHARE_READ |
                                      win32file.FILE_SHARE_WRITE,
                                      secur_att,
                                      win32file.OPEN_ALWAYS,
                                      win32file.FILE_ATTRIBUTE_NORMAL,
                                      None)
        detached_handle = handle.Detach()
        file_descriptor = msvcrt.open_osfhandle(detached_handle, os.O_APPEND | os.O_TEXT)
        return file_descriptor

    def _open(self):
        opener = self.__opener if CurrentOsInfo.get_os_name() == "Windows" else None
        return open(self.baseFilename, self.mode, encoding=self.encoding, opener=opener)


class E2eLogger(logging.Logger):
    """src: https://stackoverflow.com/a/22586200"""
    MIN_NUMBER_OF_LINES_TO_PRESENT_FINAL_MSG = 20
    VERBOSE = 5

    def __init__(self, name, level=logging.NOTSET):
        super().__init__(name, level)
        # noinspection PyTypeChecker
        self.last_record = None  # type: weakref.ReferenceType
        logging.addLevelName(self.VERBOSE, "VERBOSE")

    def makeRecord(self, name, level, fn, lno, msg, args, exc_info,
                   func=None, extra=None, sinfo: Union[None, bool] = None):
        record = super().makeRecord(name, level, fn, lno, msg, args, exc_info, func, extra, sinfo)
        self.last_record = weakref.ref(record)  # type: weakref.ReferenceType
        return record

    def _log(self, level, msg, args, exc_info=None, extra=None, stack_info=False,
             list_of_strings: List[str] = None,
             chunk_len: int = 1000,
             chunk_msg: str = None,
             final_msg: str = None):
        super()._log(level, msg, args, exc_info, extra, stack_info)
        self.log_list_of_strings(level, chunk_msg, args, exc_info, extra,
                                 stack_info, list_of_strings, chunk_len, final_msg)

    def findCaller(self, stack_info: bool = False, stacklevel: int = 1):
        last_record = self.last_record() if self.last_record is not None else None  # type: logging.LogRecord
        if last_record is not None:
            return last_record.pathname, last_record.lineno, last_record.funcName, last_record.stack_info
        else:
            return super().findCaller(stack_info=stack_info)

    def log_list_of_strings(self, level, chunk_msg, args, exc_info=None, extra=None, stack_info=False,
                            list_of_strings: List[str] = None,
                            chunk_len: int = 1000,
                            final_msg: str = None):
        fn, lno, func, sinfo = self.findCaller(stack_info=stack_info)
        if list_of_strings is not None and len(list_of_strings):
            chunks = Chunks(list_of_strings, max_number_of_elements=chunk_len)
            if chunks.no_of_chunks > 1:
                chunk_msg = chunk_msg.rstrip() if chunk_msg is not None else "Presenting chunk"
                chunk_msg = " ".join([chunk_msg.rstrip(), "({index}/{no_of_chunks}):\n{chunk}\n"])
            else:
                chunk_msg = "\n{chunk}\n"
            list_chunk = []
            for chunk_number, no_of_chunks, list_chunk in chunks:
                formatted_chunk_msg = chunk_msg.format(index=chunk_number,
                                                       no_of_chunks=no_of_chunks,
                                                       chunk="\n".join(list_chunk))
                chunk_record = self.makeRecord(self.name, level, fn, lno, formatted_chunk_msg, args,
                                               exc_info, func, extra, sinfo)
                self.handle(chunk_record)
            else:
                if len(list_chunk) > self.MIN_NUMBER_OF_LINES_TO_PRESENT_FINAL_MSG:
                    final_msg = final_msg.rstrip() if final_msg is not None else "End of presenting chunks"
                    if chunks.no_of_chunks > 1:
                        final_msg = " ".join([final_msg, "Presented {no_of_chunks} chunks.".
                                             format(no_of_chunks=chunks.no_of_chunks)])
                    final_record = self.makeRecord(self.name, level, fn, lno, final_msg, args,
                                                   exc_info, func, extra, sinfo)
                    self.handle(final_record)

    def verbose(self, msg, *args, **kwargs):
        if self.isEnabledFor(self.VERBOSE):
            self._log(self.VERBOSE, msg, args, **kwargs)


logging.setLoggerClass(E2eLogger)

__LOGGING_LEVEL = config.logging_level


class StdAndFileHandler(object):
    def __init__(self, stream, file_handler):
        self.stream = stream
        self.file_handler = file_handler

    def write(self, msg):
        self.stream.write(msg)
        self.file_handler.stream.write(msg)

    def flush(self):
        self.stream.flush()
        self.file_handler.stream.flush()


requests.urllib3.disable_warnings()

if worker_count > 0:
    sh = logging.StreamHandler()
else:
    sh = logging.StreamHandler(sys.stdout)
fh = E2eFileHandler()
# noinspection PyArgumentList
logging.basicConfig(format=logger_format, handlers=[sh, fh])

std_and_file_handler = StdAndFileHandler(sys.stdout, fh)


def excepthook(etype, value, tb):
    s = "".join(traceback.format_exception(etype, value, tb))
    std_and_file_handler.write(s)


sys.excepthook = excepthook


def change_log_file_path(log_file_dir):
    logger = logging.getLogger()
    new_log_file_path = os.path.join(log_file_dir, fh.filename)
    if fh in logger.handlers:
        fh.close()  # close opened log file
        logger.removeHandler(fh)
        try:
            os.rename(fh.baseFilename, new_log_file_path)  # try to move created log file to new directory
        except OSError:
            logger.exception(f"Can't move log file '{fh.baseFilename}' to '{new_log_file_path}'.")
    new_file_handler = E2eFileHandler(new_log_file_path)
    std_and_file_handler.file_handler = new_file_handler
    logger.addHandler(new_file_handler)


def set_level(level_name):
    global __LOGGING_LEVEL
    __LOGGING_LEVEL = getattr(logging, level_name)
    # set logging level to all already-defined loggers
    manager = logging.Logger.manager  # type: 'logging.Manager'
    for _, logger in manager.loggerDict.items():
        if not isinstance(logger, logging.PlaceHolder):
            logger.setLevel(__LOGGING_LEVEL)
    # set custom logging levels to third-party library loggers
    logging.getLogger("requests.packages.urllib3.connectionpool").setLevel(__LOGGING_LEVEL)
    logging.getLogger("googleapiclient.discovery").setLevel(logging.WARNING)


def get_logger(name) -> E2eLogger:
    logger = logging.getLogger(name)
    logger.addFilter(SensitiveKeysStrippingFilter())
    logger.setLevel(__LOGGING_LEVEL)
    return cast(E2eLogger, logger)


def log_command(command, replace=None):
    logger = get_logger(LoggerType.SHELL_COMMAND)
    msg = "Execute {}".format(" ".join(command))
    if replace is not None:
        msg = msg.replace(*replace)
    logger.info(msg)


def _format_message_body(msg_body, logged_body_length=None):
    limit = int(config.logged_response_body_length) if logged_body_length is None else logged_body_length
    if limit > 0 and  len(msg_body) > limit:
        half = limit // 2
        msg_body = f"{msg_body[:half]}[...]{msg_body[-half:]}"
    elif limit == 0:
        msg_body = "[...]"
    return msg_body


def log_http_request(prepared_request, username, description="", data=None):
    prepared_body = prepared_request.body[:5000] if prepared_request.body else prepared_request.body
    body = prepared_body if not data else json.dumps(data)
    msg_body = _format_message_body(body) if body is not None else ""
    msg = [
        description,
        "----------------Request------------------",
        f"Client name: {username}",
        f"URL: {prepared_request.method} {prepared_request.url}",
        f"Headers: {prepared_request.headers}",
        f"Body: {msg_body}",
        "-----------------------------------------"
    ]
    get_logger(LoggerType.HTTP_REQUEST).debug("\n".join(msg))


def log_http_response(response, logged_body_length=None, history_depth=1):
    """If logged_body_length < 0, full response body is logged"""
    if history_depth > 0 and len(response.history) > 1:
        for history_response in response.history:
            log_http_response(response=history_response,
                              logged_body_length=logged_body_length,
                              history_depth=history_depth - 1)

    msg_body = _format_message_body(response.text, logged_body_length)
    msg = [
        "\n----------------Response------------------",
        f"Status code: {response.status_code}",
        f"Headers: {response.headers}",
        f"Content: {msg_body}",
        "-----------------------------------------\n"
    ]
    get_logger(LoggerType.HTTP_RESPONSE).debug("\n".join(msg))


def step(message):
    caller = inspect.stack()[1][3]
    _log_separator(logger_type=LoggerType.STEP_LOGGER, separator=SEPARATOR, caller=caller, message=message)


def log_fixture(message, separator=FIXTURE_SEPARATOR):
    caller = inspect.stack()[1][3]
    _log_separator(logger_type=LoggerType.FIXTURE_LOGGER, separator=separator, caller=caller, message=message)


def log_finalizer(message, separator=FIXTURE_SEPARATOR):
    caller = inspect.stack()[1][3]
    _log_separator(logger_type=LoggerType.FINALIZER_LOGGER, separator=separator, caller=caller, message=message)


def _log_separator(logger_type, separator, caller, message):
    get_logger(logger_type).info("{0} {1}: {2} {0}".format(separator, caller, message))
