#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import sys
import signal
import pytest

from e2e.exceptions import UnexpectedResponseError, CommandExecutionException


class SigtermCleaner:

    def __init__(self):
        self.test_objects = []
        signal.signal(signal.SIGTERM, self.sigterm_handle)

    def sigterm_handle(self, _signo, _stack_frame):
        while len(self.test_objects) > 0:
            item = self.test_objects.pop()
            try:
                item.cleanup()
            except (UnexpectedResponseError, AssertionError, CommandExecutionException):
                pass
        sys.exit(1)


@pytest.fixture(scope="session")
def sigterm_cleaner():
    return SigtermCleaner()
