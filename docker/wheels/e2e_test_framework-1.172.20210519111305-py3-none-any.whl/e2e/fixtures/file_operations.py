#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

import pytest
import os
from shutil import make_archive
from gitignore_parser import parse_gitignore

from e2e import command, config
from e2e.files.file_base import FileBase
from e2e.test_names import generate_test_object_name
from _pytest.fixtures import FixtureRequest


def temp_file(prefix):

    dir_name = generate_test_object_name(short=True)
    cwd = os.path.join(config.tmp_dir, dir_name)
    os.mkdir(cwd)
    file_name = generate_test_object_name(short=False, prefix=prefix)
    file_path = os.path.join(cwd, file_name)
    cmd = ["touch", file_name]
    out, _, _ = command.run(cmd, cwd=cwd)
    file_name = os.path.basename(file_path)
    assert len(out) == 0, out
    assert os.path.isfile(file_path), "Cannot create a file: \'{}\'".format(file_path)

    return file_name, file_path


def remove_temp_file(cwd):
    rm = ["rm", "-rf", cwd]
    command.run(rm)


def get_all_files_and_dirs(from_path):
    files_and_dirs = []
    for root, _, files in os.walk(from_path, topdown=True):
        files_and_dirs.append(root)
        for file in files:
            files_and_dirs.append(os.path.join(root, file))
    return files_and_dirs


def copy_dir_recursively(from_dir, dest_dir):
    for root, _, files in os.walk(from_dir, topdown=True):
        new_path_to_file = os.path.join(dest_dir, os.path.relpath(root, from_dir)) if root != from_dir else dest_dir
        if not os.path.exists(new_path_to_file):
            os.mkdir(new_path_to_file)
        for file in files:
            FileBase.copy_file(os.path.join(root, file), new_path_to_file)


def relpath_without_file_name(path, start):
    if os.path.isfile(path):
        relpath = os.path.relpath(os.path.dirname(path), start)
    else:
        relpath = os.path.relpath(path, start)
    return relpath


@pytest.fixture(scope="session", autouse=True)
def move_temp_files_to_artifacts_dir(request):
    def finalizer():
        if config.add_debug_artifacts:
            if config.artifacts_dir:
                all_files_and_dirs = get_all_files_and_dirs(config.tmp_dir)
                filter_function = parse_gitignore(config.artifactsinclude_path, config.tmp_dir)
                filtered_files_and_dirs = [file for file in all_files_and_dirs if filter_function(file)]
                debug_files_dir = os.path.join(config.tmp_dir, "debug_files")
                os.mkdir(debug_files_dir)

                for file in filtered_files_and_dirs:
                    new_path_to_file = os.path.join(debug_files_dir, relpath_without_file_name(file, config.tmp_dir))
                    if not os.path.exists(new_path_to_file):
                        os.makedirs(new_path_to_file)
                    if os.path.isfile(file):
                        FileBase.copy_file(file, new_path_to_file)
                    else:
                        copy_dir_recursively(file, new_path_to_file)

                zipped_debug_files = make_archive(debug_files_dir, "zip", debug_files_dir)
                FileBase.copy_file(zipped_debug_files, config.artifacts_dir)

    request.addfinalizer(finalizer)


@pytest.fixture(scope="session")
def temp_file_a(request: FixtureRequest):
    file_name, file_path = temp_file(prefix="a")

    def finalizer():
        remove_temp_file(os.path.dirname(file_path))
    request.addfinalizer(finalizer)
    return file_name, file_path


@pytest.fixture(scope="session")
def temp_file_b(request: FixtureRequest):
    file_name, file_path = temp_file(prefix="b")

    def finalizer():
        remove_temp_file(os.path.dirname(file_path))
    request.addfinalizer(finalizer)
    return file_name, file_path
