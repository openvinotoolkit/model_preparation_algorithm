#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import os
import time
from datetime import datetime
from urllib.parse import quote
from typing import Callable, Optional

import pytest
from _pytest.fixtures import FixtureRequest
from github import Github
from selenium import webdriver
from selenium.webdriver.chrome.webdriver import WebDriver

from e2e import config
from e2e import command
from e2e.command_wrappers import Command
from e2e.constants.logger_type import LoggerType
from e2e.constants.gui import CHROME_DRIVER
from e2e.constants.project_paths import Path
from e2e.gui_utils import save_screenshot
from e2e.logger import log_fixture, get_logger, log_finalizer
from e2e.port_manager import PortManager
from e2e.process_utils import get_pids, kill_process

# TODO: until unittest.TestCase subclassing is not removed,
#       session-scoped fixtures write to global variables
# TODO: logger in fixtures should have special format
from e2e.ssh_lib import JumpClient
from e2e.recording import Recording

logger = get_logger(LoggerType.FIXTURE_LOGGER)


@pytest.fixture(scope="session")
def port_manager():
    return PortManager("general", starting_port=config.starting_port, pool_size=config.ports_pool_size)


@pytest.fixture(scope="session", autouse=True)
def configure_junit_xml(pytestconfig):
    log_fixture("Configure junit xml")
    if hasattr(pytestconfig, '_xml'):
        pytestconfig._xml.add_global_property('TESTS_START_TIME',
                                              datetime.utcnow().strftime('%Y-%m-%d %H:%M:%SZ'))


@pytest.fixture(autouse=True)
def description_junit_xml(request, record_property):
    description = ""
    try:
        docstring = request.function.__doc__
        description = docstring.split('<b>')[1]
        if 'Description:' in description:
            description = description.replace('Description:', '')
            description = description.replace('</b>', '')
            description = description.strip()
        else:
            description = ""
    except (IndexError, AttributeError):
        pass

    record_property("description", description)


@pytest.fixture(scope="function")
def add_test_finalizer(request: FixtureRequest) -> Callable[..., None]:
    return request.addfinalizer


@pytest.fixture(scope="session", params=[config.environment.addresses])
def addresses(request) -> str:
    """Return list of addresses

    Returns:
      set of platform addresses
    """
    return request.param


@pytest.fixture(scope="session")
def github_client() -> Github:
    """Returns GitHub client instance

    Returns:
      Github client instance
    """
    return Github(config.github_token)


@pytest.fixture(scope="session")
def driver_session(request) -> WebDriver:
    """Returns driver representing Chrome browser object needed for GUI tests.
    Method sets prefs variable to download files and not open them in a new browser window.
    Method sets params variable to enable files download in driver headless mode.
    Returns:
        Chrome WebDriver
    """
    service_log_path = Path.chromedriver_log
    service_args = ['--verbose']
    prefs = {"plugins.always_open_pdf_externally": True,
             "download.default_directory": config.tmp_dir}
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_experimental_option("prefs", prefs)
    if config.selenium_headless:
        chrome_options.add_argument('--headless')
    chrome_options.add_argument('--disable-gpu')
    chrome_options.add_argument('--allow-running-insecure-content')
    chrome_options.add_argument('--ignore-certificate-errors')
    logger.info(f"Starting chrome driver with tmp folder: {config.tmp_dir} service log path: {service_log_path}")
    chrome_driver = webdriver.Chrome(chrome_options=chrome_options,
                                     service_args=service_args,
                                     service_log_path=service_log_path)
    chromedriver_version = chrome_driver.capabilities['chrome']['chromedriverVersion'].split(' ')[0]
    chrome_browser_version = chrome_driver.capabilities['browserVersion'] if \
        'browserVersion' in chrome_driver.capabilities else chrome_driver.capabilities['version']
    logger.info(f"Starting tests with Chrome Browser version: {chrome_browser_version}, "
                f"and ChromeDriver version: {chromedriver_version}")
    if chromedriver_version != chrome_browser_version:
        logger.warning(f"Version of Chrome Browser: {chrome_browser_version} "
                       f"could be incompatible with version of ChromeDriver: {chromedriver_version}")
    chrome_driver.command_executor._commands["send_command"] = ("POST", '/session/$sessionId/chromium/send_command')
    params = {'cmd': 'Page.setDownloadBehavior',
              'params': {'behavior': 'allow',
                         'downloadPath': config.tmp_dir}}
    chrome_driver.execute("send_command", params)
    chrome_driver.set_window_position(0, 0)
    chrome_driver.set_window_size(config.browser_width, config.browser_height)
    chrome_driver.implicitly_wait(30)

    def finalizer():
        chromedriver_pids = get_pids([CHROME_DRIVER])
        log_fixture("For chromedriver following pids were found: {}".format(chromedriver_pids))
        chrome_driver.quit()
        if chromedriver_pids:
            for pid in chromedriver_pids:
                kill_process(pid)

    request.addfinalizer(finalizer)
    time.sleep(10)
    return chrome_driver


@pytest.fixture(scope="session")
def driver_desktop(request) -> WebDriver:
    options = webdriver.ChromeOptions()
    if config.desktop_application:
        options.binary_location = config.desktop_application
    else:
        raise RuntimeError("TT_DESKTOP_APP is not set.")
    if config.desktop_application:
        chrome_driver = webdriver.Chrome(config.chrome_driver_windows,
                                         chrome_options=options)
    else:
        raise RuntimeError("TT_CHROME_DRIVER is not set.")

    def finalizer():
        chromedriver_pids = get_pids([CHROME_DRIVER])
        log_fixture("For chromedriver following pids were found: {}".format(chromedriver_pids))
        chrome_driver.quit()
        if chromedriver_pids:
            for pid in chromedriver_pids:
                kill_process(pid)

    request.addfinalizer(finalizer)
    time.sleep(10)
    return chrome_driver


def _finalize_gui_test(driver, file_name):
    save_screenshot(driver, file_name)
    if config.test_build_log_url:
        link = f"{config.test_build_log_url}artifact/test_log/{file_name}.png"
        logger.info(f"Link to screenshot of failed test: {link}")


def _remove_recording_if_test_passed(recording, request_node):
    remove_recording = True
    if request_node.rep_setup.failed:
        remove_recording = False
    elif request_node.rep_call.failed:
        remove_recording = False
    if remove_recording:
        rm_command = Command(command="rm").append("-fv").append(recording.file_path)
        log_finalizer("Command to remove recording: ", rm_command)
        command.run(rm_command)


@pytest.fixture(scope="function")
def screenshot(driver, request):
    timestamp = datetime.now().strftime('%m%d%H%M%S')
    file_name = f"{request.node.name}_{timestamp}"
    request.node._screenshot_file_name = file_name
    if config.recording:
        folder = config.artifacts_dir if config.artifacts_dir else Path.screenshot_dir
        os.makedirs(folder, exist_ok=True)
        recording = Recording(file_dir=folder, test_name=request.node.name, timestamp=timestamp)
        request.node._recording_file_name = recording.file_name
        recording.start()

    def finalizer():
        if config.recording:
            recording.stop()
            _remove_recording_if_test_passed(recording, request.node)
        if request.node.rep_setup.failed:
            _finalize_gui_test(driver=driver, file_name=file_name)
        elif request.node.rep_call.failed:
            _finalize_gui_test(driver=driver, file_name=file_name)
    request.addfinalizer(finalizer)


@pytest.fixture(scope="function")
def close_additional_tabs(driver, request):
    def finalizer():
        open_tabs = len(driver.window_handles)
        if open_tabs > 1:
            for i in range(1, open_tabs):
                driver.switch_to.window(driver.window_handles[1])
                driver.close()
        driver.switch_to.window(driver.window_handles[0])
    request.addfinalizer(finalizer)


@pytest.fixture(scope="session")
def jump_client() -> Optional[JumpClient]:
    """Creates JumpClient connected to head

    Returns:
      JumpClient connected to head
    """
    if config.env_priv_key == "":
        return None
    return JumpClient(remote_username=config.env_user,
                      priv_key=config.env_priv_key,
                      remote_host=config.environment.env_ip)


@pytest.fixture(scope="session", autouse=config.mongodb_docker_auto_start)
def mongodb_image():
    from e2e.object_model.docker import DockerContainer
    logger.debug(f"pulling {config.mongodb_docker_image}:{config.mongodb_docker_tag}")
    image = DockerContainer.client.pull(config.mongodb_docker_image,
                                        config.mongodb_docker_tag)
    logger.debug(f"pulling {config.mongodb_docker_image}:{config.mongodb_docker_tag}: Done")
    return image


@pytest.fixture(scope="session", autouse=config.mongodb_docker_auto_start)
def mongodb_container(session_context, mongodb_image):
    from e2e.object_model.docker import DockerContainer
    mongo = DockerContainer.run(session_context, mongodb_image,
                                ports={27017: config.mongodb_docker_port})
    return mongo
