#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import yaml
from e2e.logger import get_logger
from .args import parse_args
from .env_manager import EnvManager
from .exceptions import ReservationNotAvailableError
from .manager_config import ManagerConfig
from .manager import Manager
from .runner import reserve_and_run


def main():
    """Console script for manager."""

    log = get_logger(__name__)

    try:
        args = parse_args()
    except Exception as e:
        log.error(f"While parsing arguments: {e}")
        return 1

    if not args.reservation_action:
        log.info(f"Nothing to do")
        return

    log.debug("Starting reservation manager")
    reservation_mgr = manager_from_args(args)

    # Manage independent reservation
    try:
        if args.reservation_action == "create":
            reservation_mgr.independent.create()

        elif args.reservation_action == "remove":
            reservation_mgr.independent.remove()

        elif args.reservation_action == "cleanup":
            reservation_mgr.independent.cleanup()

        elif args.reservation_action == "command":
            return reserve_and_run(args.reservation_command, reservation_mgr)

        else:
            raise ValueError(f"Provided reservation action "
                             f"is not allowed: {args.reservation_action}")

    except ReservationNotAvailableError as e:
        log.error(f"{e}")
        return 1

    except Exception as e:
        log.error(f"During handling reservation: {e}")
        raise e


def manager_from_args(args):
    """
    Create and return new Manager instance
    from cli arguments or config file.

    params::
      - args - parsed argparse namespace
    """

    log = get_logger(__name__)

    config_path = args.config_path
    reservation_action = None

    config = None
    try:
        with open(config_path, 'r') as file:
            config = yaml.load(file, Loader=yaml.FullLoader)["config"]

    except FileNotFoundError as e:
        log.warning(f"Configuration file '{config_path}' not found")

    pool_range_start = 0
    pool_range_stop = 0
    pool_part_size = 0

    pool_part_ports_prefix = None
    pool_part_slices = None
    locks_dir = None

    try:

        # Port pool settings
        pool_range_start = int(config["pool_range"]["start"])
        pool_range_stop = int(config["pool_range"]["stop"])
        pool_part_size = int(config["pool_part_size"])

        # Pool parts envs settings
        pool_part_slices = config["envs"]["slices"]

        # Allow passing number of slices as int so it may be used
        # easier when only prefix is needed.
        # This behaviour will be possibly dropped in future.
        if isinstance(pool_part_slices, int):
            pool_part_slices = [None] * pool_part_slices

        # Don't force ports_prefix to be present
        try:
            pool_part_ports_prefix = config["envs"]["ports_prefix"]
        except KeyError:
            pass

        locks_dir = config["locks_dir"]

    except KeyError as ke:
        key = f"{ke}".replace("'", "")
        raise KeyError(f"Following key not found in configuration file "
                       f"'config/{key}'")

    except Exception as e:
        raise Exception(
            f"Unknown exception while reading configuration file: {e}")

    try:  # With CLI arguments, override config file
        if args.pool_range_start:
            pool_range_start = args.pool_range_start

        if args.pool_range_stop:
            pool_range_stop = args.pool_range_stop

        if args.pool_part_size:
            pool_part_size = args.pool_part_size

        if args.locks_dir:
            locks_dir = args.locks_dir

        reservation_action = args.reservation_action

        reservation_file_json = args.reservation_file_json
        reservation_file_env = args.reservation_file_env

        keep_env = args.keep_env

        command = None
        reserver = "independent"

        if args.reservation_action == "command":
            command = args.reservation_command
            reserver = args.reservation_command[0].replace("-", "_")

    except Exception as e:
        log.error(f"Getting settings from cli arguments: {e}")
        raise Exception(f"While getting CLI arguments: {e}")

    log.debug(f"All params:\n"
              f"pool_range_start: {pool_range_start}\n"
              f"pool_range_stop: {pool_range_stop}\n"
              f"pool_part_size: {pool_part_size}\n"
              f"pool_part_ports_prefix: {pool_part_ports_prefix}\n"
              f"pool_part_slices: {pool_part_slices}\n"
              f"locks_dir: {locks_dir}\n"
              f"reservation_action: {reservation_action}\n"
              f"reservation_file_json: {reservation_file_json}\n"
              f"reservation_file_env: {reservation_file_env}\n"
              f"command: {command}\n"
              f"keep_env: {keep_env}\n"
              f"reserver: {reserver}\n")

    env_mgr = EnvManager(
        pool_part_slices=pool_part_slices,
        pool_part_ports_prefix=pool_part_ports_prefix,
        keep_env=keep_env,
    )

    res_mgr_conf = ManagerConfig(
        pool_range_start=pool_range_start,
        pool_range_stop=pool_range_stop,
        pool_part_size=pool_part_size,
        locks_dir=locks_dir,
        reserver=reserver,
        port_lock_cleanup=(False if reservation_action == "create" else True),
        reservation_file_json=reservation_file_json,
        reservation_file_env=reservation_file_env,
    )

    res_mgr = Manager(res_mgr_conf, env_mgr)

    log.debug(f"env_mgr: {env_mgr}")
    log.debug(f"res_mgr_conf: {res_mgr_conf}")
    log.debug(f"res_mgr: {res_mgr}")

    return res_mgr
