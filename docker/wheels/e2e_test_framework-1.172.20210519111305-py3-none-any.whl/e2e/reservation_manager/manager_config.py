#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import os
from e2e.logger import get_logger


class ManagerConfig:
    """
    ManagerConfig

    params::
      - pool_range_start=30000
      - pool_range_stop=60000
      - pool_part_size=1000
      - locks_dir="/tmp"
      - locks_prefix="reservation_manager"
      - reserver="default"
      - port_lock_cleanup=True
      - reservation_file_json="reservation.json"
      - reservation_file_env="reservation.env"
    """
    def __init__(
            self,
            pool_range_start=30000,
            pool_range_stop=60000,
            pool_part_size=1000,
            locks_dir="/tmp",
            locks_prefix="reservation_manager",
            reserver=None,
            port_lock_cleanup=True,
            reservation_file_json="reservation.json",
            reservation_file_env="reservation.env",
    ):

        self.pool_range_start = pool_range_start
        self.pool_range_stop = pool_range_stop
        self.pool_part_size = pool_part_size

        self.locks_dir = locks_dir
        self.locks_prefix = locks_prefix

        if not reserver:
            self.reserver = "default"
        else:
            self.reserver = reserver

        self.port_lock_cleanup = port_lock_cleanup
        self.reservation_file_json = reservation_file_json
        self.reservation_file_env = reservation_file_env

        self.log = get_logger(__name__)
        self.validate()

    def validate(self):
        """
        Validate ManagerConfig.
        """

        assert (self.pool_range_start is not None
                and self.pool_range_stop is not None
                and self.pool_part_size is not None
                and self.locks_dir is not None), (
                    "Following values must be provided: "
                    "pool_range_start, "
                    "pool_range_stop, "
                    "pool_part_size, "
                    "locks_dir")

        assert self.pool_range_start > 1024, (
            "Port range start must be greater than "
            "1024")
        assert self.pool_range_stop > 1024, (
            "Port range stop must be greater than "
            "1024")
        assert self.pool_range_stop - self.pool_range_start > 0, (
            "Port range must be greater than 0")

        assert self.pool_part_size <= (
            self.pool_range_stop - self.pool_range_start), (
                "Port pool size must be smaller or equal to port range")

        assert os.path.exists(self.locks_dir), (
            f"Path for locks dir must exist: {self.locks_dir}")

        assert os.access(self.locks_dir, os.W_OK), (
            f"Path for locks dir must be writeable: {self.locks_dir}")

        assert len(self.reserver.split("-")) == 1, (
            f"Reserver invalid: cannot have dashed in name: {self.reserver}")
