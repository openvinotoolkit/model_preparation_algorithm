#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import os
import pathlib
import json
from e2e.logger import get_logger
from filelock import Timeout
from .exceptions import ReservationNotExistsError, ReservationNotAvailableError
from .locker import Locker


class Manager:
    """
    Class Manager is responsible for gathering information about
    possible port ranges, reserved ranges and supplying information
    for next available range.

    params::
      - res_mgr_conf - ManagerConfig
      - env_mgr      - EnvManager

    """
    def __init__(self, res_mgr_conf, env_mgr):
        """
        Get configuration from ManagerConfig and EnvManager,
        init internal variables to manage ports reservation,
        gather possible port ranges.
        """

        self.log = get_logger(__name__)

        self.config = res_mgr_conf
        self.env_mgr = env_mgr

        self.all_pool_parts = []
        self.calculate_all_pool_parts()

        self.log.debug(f"Calculated all possible port ranges, "
                       f"len: {len(self.all_pool_parts)}")

        self.log.debug("Create Locker instance")
        self.reservation_lock = Locker()

        self.reservations = []

        self.owned_reservation = None

    def calculate_all_pool_parts(self):
        self.all_pool_parts = []
        self.log.debug(
            f"Calculating all reservable port ranges with following: "
            f"pool range start: {self.config.pool_range_start}, "
            f"pool range stop: {self.config.pool_range_stop}, "
            f"pool part size: {self.config.pool_part_size}")

        for range_step in range(self.config.pool_range_start,
                                self.config.pool_range_stop,
                                self.config.pool_part_size):
            range_start = range_step
            range_stop = range_start + self.config.pool_part_size

            self.all_pool_parts.append(PoolPart(range_start, range_stop))

    def register_existing_reservations(self):
        reservation_files = [
            filename for filename in os.listdir(self.config.locks_dir)
            if os.path.isfile(os.path.join(self.config.locks_dir, filename))
            and self.config.locks_prefix in filename
        ]

        self.log.debug(f"Gathered reservation files: {reservation_files}; "
                       f"length: {len(reservation_files)}")

        for reservation_file in reservation_files:
            self.log.debug(f"Creating Reservation instance "
                           f"from string: {reservation_file}")
            try:
                reservation = Reservation.from_str(reservation_file)
                self.log.debug(f"Appending reservation instance "
                               f"'{reservation}' to reservations list")
                self.reservations.append(reservation)

            except AssertionError as e:
                self.log.error("While registering existing reservations")
                raise AssertionError(
                    f"Can't create reservation from string: {reservation_file}; "
                    f"exception: {e}")

    def _create_reservation_file(self, reservation):
        """
        Create and save information about reservation file.
        Concurently not safe.
        Exceptions:
        - pathlib.FileExistsError if file exists
        """

        reservation_lock_path = f"{self.config.locks_dir}/{reservation}"
        self.log.debug(
            f"Creating reservation lock file: {reservation_lock_path}")
        pathlib.Path(reservation_lock_path).touch(exist_ok=False)
        return reservation_lock_path

    def register_as_owned(self, reservation):
        """Registers as owned reservation in this instance."""
        self.owned_reservation = reservation
        self.env_mgr.register_reservation(reservation)

    def reserve(self, reservation_candidate):
        """Creates reservation file"""

        self.log.debug(f"Trying to create reservation for "
                       f"{reservation_candidate}")
        try:
            self._create_reservation_file(reservation_candidate)

        except FileExistsError as e:
            self.log.critical(
                f"Creating reservation. This should have not happened, "
                f"definitely a bug: {e}")
            raise e

    def get_available_reservation(self):
        """
        Get available reservation with respect to already existing
        reservations.
        Return None if not available.
        """

        self.log.debug("Get existing reservations")
        self.register_existing_reservations()

        for pool_range_candidate in self.all_pool_parts:
            self.log.debug(f"Considering pool range: {pool_range_candidate}")
            pool_range_valid = True
            for reservation in self.reservations:
                if pool_range_candidate.is_intersect_with(reservation):
                    pool_range_valid = False
                    break

            if not pool_range_valid:
                continue

            self.log.debug(f"Pool range is available for reservation: "
                           f"{pool_range_candidate}")

            available_reservation = Reservation(
                self.config.locks_prefix,
                pool_range_candidate,
                self.config.reserver,
            )
            return available_reservation
        return None

    def reserve_and_return(self):
        """
        Create reservation and return.
        Concurently safe.
        """

        self.log.debug("Locking reservation procedure")
        try:
            self.reservation_lock.acquire()
            self.log.debug("Reservation lock aquired")

            self.log.debug("Attempting reservation")
            reservation = self.get_available_reservation()
            if reservation:
                self.reserve(reservation)
                return reservation
            else:
                raise ReservationNotAvailableError()

        except Timeout as timeout:
            raise Timeout(f"Can't lock reservation procedure: {timeout}")
        except Exception as e:
            raise e
        finally:
            self.log.debug("Unlocking reservation procedure")
            self.reservation_lock.release()

    def get_owned_reservation(self):
        """Returns owned reservation or reserves if does not own any."""

        self.log.debug(f"Return owned reservation or create")

        if not self.owned_reservation:
            self.log.debug(
                f"Not registered any reservation, register and return")
            reservation = self.reserve_and_return()
            self.register_as_owned(reservation)
            return reservation

        return self.owned_reservation

    def _remove_reservation_file(self, reservation):
        """Remove reservation file"""
        reservation_lock_path = f"{self.config.locks_dir}/{reservation}"
        self.log.debug(
            f"Removing reservation lock path: {reservation_lock_path}")
        try:
            os.remove(reservation_lock_path)
        except FileNotFoundError as nfe:
            raise ReservationNotExistsError(
                f"Reservation file lock already removed")

    def release_reservation(self, reservation):
        """Delete reservation file"""
        self._remove_reservation_file(reservation)

    def get_reservation_json(self):
        """Return json data for owned reservation"""

        reservation_json = self.env_mgr.get_json()
        reservation_file = f"{self.config.locks_dir}/{self.owned_reservation}"
        reservation_json["reservation_file"] = reservation_file
        reservation_json["shell_envs_file"] = self.config.reservation_file_env
        return reservation_json

    def get_reservation_shell_envs(self):
        """Return shell env variables for owned reservation"""

        reservation_shell_envs = self.env_mgr.get_shell_envs()
        return reservation_shell_envs

    def reservation_from_json(self, json_path):
        """Return reservation from json data"""

        try:
            with open(json_path, "r") as json_file:
                json_data = json.load(json_file)
                self.log.debug(f"json_data: {json_data}")

                reservation_lock_path = json_data["reservation_file"]
                self.config.reservation_file_env = json_data["shell_envs_file"]
                self.log.debug(
                    f"reservation_lock_path: {reservation_lock_path}")

                self.env_mgr.locks_dir = os.path.dirname(reservation_lock_path)
                reservation_str = os.path.basename(reservation_lock_path)

                reservation = Reservation.from_str(reservation_str)
                return reservation

        except FileNotFoundError as e:
            raise FileNotFoundError(f"Reservation from json: {e}")

        except json.JSONDecodeError as de:
            raise json.JSONDecodeError(f"Loading reservation from json: {de}")

    @property
    def independent(self):
        class independent_class:
            def __init__(self, res_mgr):
                self.res_mgr = res_mgr
                self.log = get_logger(__name__)

            def create(self):
                """
                Create independent reservation, save info to json and shell env
                file to filepaths pointed by
                '--reservation-file-json' and '--reservation-file-env'.
                """
                reservation = self.res_mgr.get_owned_reservation()

                reservation_json = self.res_mgr.get_reservation_json()
                json_save_path = self.res_mgr.config.reservation_file_json

                res_shell_envs = self.res_mgr.get_reservation_shell_envs()
                shell_env_save_path = self.res_mgr.config.reservation_file_env

                # Open exclusively, if file exists - throw exception
                try:
                    with open(json_save_path, "x") as json_file:
                        json.dump(reservation_json,
                                  json_file,
                                  ensure_ascii=False,
                                  indent=4)
                except FileExistsError as fe:
                    self.res_mgr.release_reservation(reservation)
                    raise FileExistsError(f"Can't save reservation json: {fe}")

                try:
                    with open(shell_env_save_path, "x") as shell_env_file:
                        shell_env_file.write(res_shell_envs)

                except FileExistsError as fe:
                    self.res_mgr.release_reservation(reservation)
                    raise FileExistsError(
                        f"Can't save shell env variables: {fe}")

            def remove(self):
                """
                Remove independent reservation, use file pointed by
                '--reservation-file-json' to get required information.
                """

                # Get reservation file json
                json_path = self.res_mgr.config.reservation_file_json
                try:
                    reservation = self.res_mgr.reservation_from_json(json_path)
                except FileNotFoundError as e:
                    raise FileNotFoundError(f"Cannot find reservation: {e}")

                reservation_file_env = self.res_mgr.config.reservation_file_env

                try:
                    self.res_mgr.release_reservation(reservation)
                except ReservationNotExistsError:
                    pass
                except Exception as e:
                    self.log.error(f"Error releasing reservation: {e}")

                try:
                    os.remove(reservation_file_env)
                except FileNotFoundError as nfe:
                    self.log.warning(f"Removing reservation shell env : {nfe}")

                try:
                    os.remove(json_path)
                except FileNotFoundError as nfe:
                    self.log.warning(f"Removing reservation json: {nfe}")

            def cleanup(self):
                """Find all reservations in locks_dir, delete.
                Try to delete files pointed by
                '--reservation-file-json' and '--reservation-file-env'.
                """

                # Try with remove first because there can be reservation-file{json,env}
                try:
                    self.res_mgr.independent.remove()
                except Exception:
                    pass

                self.res_mgr.register_existing_reservations()
                existing_reservations = self.res_mgr.reservations
                for reservation in existing_reservations:
                    self.log.debug(f"Removing reservation: {reservation}")
                    try:
                        self.res_mgr.release_reservation(reservation)
                    except Exception as e:
                        raise Exception(f"Can't release reservation: {e}")

        return independent_class(self)


class PoolPart:
    """
    PoolPart represents reservable port pool part ranges.
    Range start is inclusive, range stop is exclusive.
    """
    def __init__(self, start, stop):
        """
        Create with defined port stop and start range.
        Stop port range value is exclusive.

        Throw an exception if failed to initialize:
        1. ValueError: range boundaries are not ints
        2. AssertionError: range boundaries are invalid
        """

        self.start = int(start)
        self.stop = int(stop)
        PoolPart.validate_range(self.start, self.stop)
        self.range = range(self.start, self.stop)

    def size(self):
        return self.stop - self.start

    @staticmethod
    def validate_range(range_start, range_stop):
        assert range_stop - range_start > 0, (
            "Invalid port range, must be greater than 0: "
            f"start: {range_start}; stop: {range_stop}")

    def is_intersect_with(self, pool_part):
        """
        Check if another PoolPart or Reservation instance
        is in intersect with this instance.
        """

        if type(pool_part) is PoolPart:
            self_is_subset = (self.range.start in pool_part.range
                              or self.range[-1] in pool_part.range)
            pool_part_is_subset = (pool_part.range.start in self.range
                                   or pool_part.range[-1] in self.range)
            return self_is_subset or pool_part_is_subset

        elif type(pool_part) is Reservation:
            res_pool_part = pool_part.pool_part.range

            self_is_subset = (self.range.start in res_pool_part
                              or self.range[-1] in res_pool_part)

            reservation_is_subset = (res_pool_part.start in self.range
                                     or res_pool_part[-1] in self.range)

            return self_is_subset or reservation_is_subset

    def __str__(self):
        return f"{self.start}-{self.stop}"


class Reservation:
    """
    PoolPart reservation.

    params::
      - locks_prefix (string)   - prefix for string representation and discovery
      - pool_part    (PoolPart) - create reservation for this pool part
      - reserved_by  (string)   - suffix for string representation

    """
    def __init__(self, locks_prefix, pool_part, reserved_by):
        self.locks_prefix = locks_prefix
        self.pool_part = pool_part
        self.reserved_by = reserved_by

    def __str__(self):
        return_str = (f"{self.locks_prefix}-{self.pool_part.start}-"
                      f"{self.pool_part.stop}-{self.reserved_by}")

        try:
            Reservation.validate_string(return_str)
            return return_str
        except AssertionError as e:
            raise AssertionError(
                f"Reservation method '__str__' returned invalid "
                f"string: {return_str}, exception: {e}")

    @staticmethod
    def validate_string(reservation):
        """Checks if string represents valid reservation"""
        splitted = reservation.split("-")

        assert len(splitted) == 4, (
            "Reservation string should consist of 4 elements: "
            "splitted with dash '-': "
            "'locks prefix', 'pool part start', "
            "'pool part stop', 'reserver identifier'")

        pool_part_start_str = splitted[1]
        pool_part_stop_str = splitted[2]

        try:
            pool_part_start = int(pool_part_start_str)
            pool_part_stop = int(pool_part_stop_str)
            PoolPart.validate_range(pool_part_start, pool_part_stop)
        except AssertionError as e:
            raise e

        except ValueError as e:
            raise AssertionError(
                f"Range boundaries invalid, start: {pool_part_start_str}, "
                f"stop: {pool_part_stop_str}; exception: {e}")

    @staticmethod
    def from_str(string):
        """Create Reservation instance from string"""

        try:
            Reservation.validate_string(string)
        except AssertionError as e:
            raise AssertionError(
                f"Validating Reservation instance from string: {string}, "
                f"exception: {e}")

        values = string.split("-")
        locks_prefix = values[0]
        pool_part_start = values[1]
        pool_part_stop = values[2]
        reserved_by = values[3]

        pool_part = PoolPart(
            pool_part_start,
            pool_part_stop,
        )

        return Reservation(
            locks_prefix,
            pool_part,
            reserved_by,
        )
