#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import subprocess
from e2e.logger import get_logger
from .exceptions import ReservationNotAvailableError


class Runner:
    """
    Manage running command, setup evironment variables
    accoarding to Manager.Reservation instance.
    """
    def __init__(self, command, env_mgr):
        """Prepare all necessary initialization to run command."""
        self.command = command
        self.env_mgr = env_mgr

        self.reservation = env_mgr.reservation
        self.log = get_logger(__name__)

    def run(self):
        """Run and pipe output"""

        self.log.debug(f"running with command: {self.command} and "
                       f"environment: {self.env_mgr.environment}")

        popen = subprocess.Popen(
            self.command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True,
            bufsize=1,
            env=self.env_mgr.environment,
        )

        for stdout_line in iter(popen.stdout.readline, ""):
            print(stdout_line, end="")

        popen.communicate()
        return popen.returncode


def reserve_and_run(command, reservation_mgr):
    """Use Manager to reserve port pool and run command"""

    log = get_logger(__name__)

    try:
        # Reservation
        log.debug(f"Trying to acquire port reservation")
        reservation = reservation_mgr.get_owned_reservation()
        log.info(f"Acquired port reservation: {reservation}")

        # Runner
        runner = Runner(command, reservation_mgr.env_mgr)

        return_code = runner.run()
        log.debug(f"Command returned code: {return_code}")

        if reservation_mgr.config.port_lock_cleanup:
            log.info(f"Releasing reservation: {reservation}")
            reservation_mgr.release_reservation(reservation)

        return return_code

    except ReservationNotAvailableError as e:
        raise e

    except Exception as e:
        log.error(f"Running command with reservation failed: {e}")
        raise e
