#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import json

from re import findall
from typing import List

from e2e.logger import get_logger

logger = get_logger(__name__)


class ConfigParser:
    CONFIG = "../config.py"
    EXCEPTIONS = [
        "TT_K8S"
    ]

    WITH_DEFAULT_DEFINED = "WITH_DEFAULT_DEFINED"
    WITH_DEFAULT_UNDEFINED = "WITH_DEFAULT_UNDEFINED"
    WITHOUT_DEFAULT = "WITHOUT_DEFAULT"

    UNDEFINED = "UNDEFINED"

    GET_REGEX = r'os.environ.get\((.*?)\)'
    GET_LIST_REGEX = r'get_list\((.*?)\)'
    GET_INT_REGEX = r'get_int\((.*?)\)'
    GET_BOOL_REGEX = r'get_bool\((.*?)\)'
    GET_URL_REGEX = r'get_url\((.*?)\)'
    GETS = [
        GET_REGEX,
        GET_LIST_REGEX,
        GET_INT_REGEX,
        GET_BOOL_REGEX,
        GET_URL_REGEX
    ]

    @staticmethod
    def _has_default_value(parameters):
        return ',' in parameters

    def __init__(self, path=None):
        if path is None:
            path = self.CONFIG
        with open(path, 'r') as config:
            gets_parameters = []
            config_content = config.read().replace('\n', ' ')
            for get_regex in self.GETS:
                gets_parameters += findall(get_regex, config_content)
        self._envs = {
            self.WITH_DEFAULT_DEFINED: {},
            self.WITH_DEFAULT_UNDEFINED: {},
            self.WITHOUT_DEFAULT: {}
                     }

        correct_parameters = list(gets_parameters)
        for exception in self.EXCEPTIONS:
            for parameters in gets_parameters:
                if exception in parameters:
                    correct_parameters.remove(parameters)

        for parameters in correct_parameters:
            if not self._has_default_value(parameters):
                env = parameters.strip('"'+"'")
                self._envs[self.WITHOUT_DEFAULT].update({env: ''})
            else:
                env = parameters[:parameters.find(',')].strip().strip('"'+"'")
                parameters = parameters[parameters.find(',') + 1:].strip()
                if self.UNDEFINED in parameters:
                    self._envs[self.WITH_DEFAULT_UNDEFINED].update({env: self.UNDEFINED})
                else:
                    self._envs[self.WITH_DEFAULT_DEFINED].update(({env: parameters}))

    @property
    def envs(self):
        return self._envs


class JSONParser:

    @staticmethod
    def try_to_parse_to_json(json_string: str):
        try:
            json_dict = json.loads(json_string)
        except json.JSONDecodeError as e:
            logger.exception("There was a problem with parsing following line to json:\n{}".format(json_string),
                             exc_info=e)
            raise e
        return json_dict

    @staticmethod
    def try_to_parse_log_lines_to_jsons(log_lines: List[str]):
        return [JSONParser.try_to_parse_to_json(log) for log in log_lines]
