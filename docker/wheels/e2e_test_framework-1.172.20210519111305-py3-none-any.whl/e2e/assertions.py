#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import difflib
import math
import os
import pprint
from contextlib import contextmanager
from datetime import datetime
from urllib.parse import quote

import pytest
import re
import grpc
import requests

from retry import retry
from retry.api import retry_call
from typing import Callable, Container, List, Type

from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.chrome.webdriver import WebDriver
from urllib3.exceptions import ProtocolError

from e2e.constants.logger_type import LoggerType
from e2e.exceptions import UnexpectedResponseError, CommandExecutionException, NotFoundException
from e2e.logger import get_logger

logger = get_logger(LoggerType.STEP_LOGGER)


def assert_http_status_code_with_retry(expected_code, tries, delay, callable_obj, *args, **kwargs):
    retry_call(assert_http_status_code, [expected_code, callable_obj, *args], fkwargs=kwargs,
               exceptions=AssertionError,
               tries=tries, delay=delay)


def assert_http_status_code(expected_code, callable_obj, *args, **kwargs):
    given_code = callable_obj(*args, **kwargs).status_code
    assert given_code == expected_code, "{expected} was expected, but {given} was given".format(expected=expected_code,
                                                                                                given=given_code)


@retry(AssertionError, tries=20, delay=3)
def assert_equal_with_retry(expected_value, callable_obj, *args, **kwargs):
    value = callable_obj(*args, **kwargs)
    assert value == expected_value


@retry(AssertionError, tries=20, delay=3)
def assert_not_in_with_retry(something, get_list_method, *args, **kwargs):
    """Use when deleting something takes longer"""
    obj_list = get_list_method(*args, **kwargs)
    assert something not in obj_list, "{} was found on the list".format(something)


@retry(AssertionError, tries=30, delay=2)
def assert_not_in_by_id_with_retry(identifier, get_list_method, *args, **kwargs):
    """Use when adding something takes longer"""
    obj_list = get_list_method(*args, **kwargs)
    ids = [o.id for o in obj_list]
    assert identifier not in ids, "{} was found on the list".format(identifier)


@retry(AssertionError, tries=30, delay=2)
def assert_in_with_retry(something, get_list_method, *args, **kwargs):
    """Use when adding something takes longer"""
    obj_list = get_list_method(*args, **kwargs)
    assert something in obj_list, "{} was not found on the list".format(something)


@retry(AssertionError, tries=30, delay=2)
def assert_in_by_id_with_retry(identifier, get_list_method, *args, **kwargs):
    """Use when adding something takes longer"""
    obj_list = get_list_method(*args, **kwargs)
    ids = [o.id for o in obj_list]
    assert identifier in ids, "{} was not found on the list".format(identifier)


def assert_raises_grpc_exception(status, error_message_phrase: str, callable_obj: Callable, *args, **kwargs):
    with pytest.raises(grpc.RpcError) as e:
        callable_obj(*args, **kwargs)
    status_code = e.value._state.code.value[0]
    error_msg = e.value._state.details
    assert error_message_phrase in error_msg, \
        "Expected output:\n{}\nnot found in exception {} value:\n{}".format(error_message_phrase, e.__class__.__name__,
                                                                            error_msg)
    assert status == status_code, "Not expected status code found: got: {}, expected: {}".format(status_code, status)


def assert_raises_http_exception(status: int, error_message_phrase: str, callable_obj: Callable, *args, **kwargs):
    with pytest.raises(UnexpectedResponseError) as e:
        callable_obj(*args, **kwargs)
    _assert_http_exception(exception=e, expected_status=status, expected_error_msg=error_message_phrase)


def _assert_http_exception(*, exception, expected_status, expected_error_msg):
    actual_status = exception.value.status
    actual_msg = exception.value.error_message
    status_correct = expected_status == actual_status
    if expected_error_msg == "":
        msg_correct = actual_msg == "" or actual_msg == "\"\""
    else:
        msg_correct = expected_error_msg in actual_msg
    assert status_correct and msg_correct, "Error is {} \"{}\",\nexpected {} \"{}\"".format(actual_status,
                                                                                            actual_msg,
                                                                                            expected_status,
                                                                                            expected_error_msg)


@retry(AssertionError, tries=2, delay=360)
def assert_greater_with_retry(get_list_method, list_to_compare, *args, **kwargs):
    obj_list = get_list_method(*args, **kwargs)
    assert len(obj_list) > len(list_to_compare)


@retry(AssertionError, tries=5, delay=10)
def assert_returns_http_success_with_retry(callable_obj, *args, **kwargs):
    response = None
    try:
        response = callable_obj(*args, **kwargs)
    finally:
        assert response is not None


def assert_no_errors(errors: list):
    assert len(errors) == 0, "\n".join([str(e) for e in errors])


def assert_unordered_list_equal(list1, list2, msg="Lists are not equal"):
    assert sorted(list1) == sorted(list2), msg


def assert_raises_command_execution_exception(return_code, output, callable_obj, *args, **kwargs):
    with pytest.raises(CommandExecutionException) as e:
        callable_obj(*args, **kwargs)
    return_code_correct = e.value.return_code == return_code
    assert_command_execution(output, return_code_correct, e, return_code)


def assert_raises_exception(exception: Type[BaseException], output, callable_obj, *args, **kwargs):
    with pytest.raises(exception) as e:
        callable_obj(*args, **kwargs)
    assert output in str(e.value),\
        "Expected output:\n{}\nnot found in exception {} value:\n{}"\
        .format(output, exception.__class__.__name__, str(e.value))


def assert_command_execution(output, return_code_correct, e, return_code):
    output_contains_string = output in e.value.output or output == ""
    assert return_code_correct and output_contains_string, \
        "Error is {0} \"{1}\", expected {2} \"{3}\"".format(e.value.return_code, e.value.output, return_code, output)


def assert_dict_values_set(dictionary, expected_keys_list):
    values_not_set = []
    for key in dictionary:
        if key in expected_keys_list and math.isnan(dictionary[key]):
            values_not_set.append(key)
    assert len(values_not_set) == 0, "Missing value(s): {}".format(values_not_set)


class ContainersNotEqualAssertion(AssertionError):
    pass


def assert_container_equal(first: Container, second: Container):
    if not first == second:
        raise ContainersNotEqualAssertion(
            'Containers content not equal:\n\n'
            .join(difflib.ndiff(pprint.pformat(first).splitlines(),
                                pprint.pformat(second).splitlines())))


def assert_date_close_enough_to_now(date, epsilon=0.5):
    current_date = datetime.now()
    assert abs(date - current_date).total_seconds() < epsilon, "{} != {} => {} >= {}"\
        .format(date, current_date, abs(date - current_date).total_seconds(), epsilon)


def assert_values_approximately_equal(v1, v2, epsilon=0.1):
    assert abs(v1 - v2) < epsilon


def assert_duration(value):
    duration_regex = r"([0-9]+ day[s]{0,1}, ){0,1}[0-9]{1,2}:[0-9]{1,2}:[0-9]{1,2}"
    match = re.search(duration_regex, value)
    assert match is not None, "Value {} is not in time duration format".format(value)


def assert_number(value):
    assert isinstance(int(value), int), "Value {} is not an integer".format(value)


def assert_greater_than_threshold(value, threshold):
    assert_number(value)
    assert int(value) > threshold, "Value {value} is not greater than threshold {threshold}".format(value=value,
                                                                                                    threshold=threshold)


@retry(AssertionError, tries=12, delay=5)
def assert_method_response_not_empty(callable_obj, *args, **kwargs):
    resp_list = callable_obj(*args, **kwargs)
    assert len(resp_list) > 0


def assert_list_contains_string(elements: List[str], string: str):
    for element in elements:
        if string in element:
            return element
    assert False, "List: {elements} doesn't contain string: {string}".format(elements=pprint.pformat(elements),
                                                                             string=string)


@retry(AssertionError, tries=15, delay=2)
def assert_directory_contains_file_with_pattern_with_retry(directory, pattern):
    return assert_list_contains_pattern(os.listdir(directory), pattern)


def assert_list_contains_pattern(elements: List[str], pattern):
    for element in elements:
        match = pattern.match(element)
        if match:
            return match
    assert False, "List: {elements} doesn't contain pattern: {pattern}".format(elements=pprint.pformat(elements),
                                                                               pattern=pattern)


def assert_element_on_page(driver: WebDriver, element: str, find_by="find_element_by_xpath"):
    try:
        getattr(driver, find_by)(element)
    except NoSuchElementException:
        raise NotFoundException("Element {} searched by {} wasn't found in page code".format(
            element, find_by))


def assert_element_not_on_page(driver: WebDriver, element: str, find_by="find_element_by_xpath"):
    try:
        getattr(driver, find_by)(element)
    except NoSuchElementException:
        logger.info("Element {} searched by {} successfully wasn't found in page code".format(
            element, find_by))


@contextmanager
def assert_exception_not_raised():
    try:
        yield
    except Exception as e:
        raise AssertionError(f"An unexpected exception `{e}` raised.")
