#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

import os
from datetime import datetime

from pip._internal.network.session import PipSession
from pip._internal.req import parse_requirements
from setuptools import setup, find_packages


def requirement(req):
    """field `req` has been changed to `requirement` - workaround to handle both"""
    if hasattr(req, "req"):
        return str(req.req)
    elif hasattr(req, "requirement"):
        return str(req.requirement)
    else:
        raise RuntimeError("Cannot find requirement field in requirement object: {}, {}\n{}"
                           .format(str(req), repr(req), dir(req)))


with open("e2e/README.md", "r") as fh:
    long_description = fh.read()

packages = find_packages(exclude=['data*', 'k8s*',  'tests*'], include=['e2e*'])
package_dir = {'e2e': 'e2e'}
package_data = {
    'e2e': ['reservation_manager/reservation_manager.yml'],
}

_year_format, _month_format, _date_format, _time_format = "%Y", "%m", "%d", "%H%M%S"
version = "{}.{}".format(os.environ.get("TT_PACKAGE_VERSION", "1.172"),
                         os.environ.get("TT_PACKAGE_BUILD_NUMBER", datetime.now().strftime(_year_format) +
                                        datetime.now().strftime(_month_format) +
                                        datetime.now().strftime(_date_format) +
                                        datetime.now().strftime(_time_format)))

session = PipSession()
requirements_parsed = parse_requirements("requirements.txt", session=session)
install_requires = [requirement(ir) for ir in requirements_parsed]

setup(name='e2e-test-framework',
      version=version,
      description="e2e testing framework",
      long_description=long_description,
      packages=packages,
      package_dir=package_dir,
      package_data=package_data,
      include_package_data=True,
      zip_safe=False,
      install_requires=install_requires,
      entry_points={
          'console_scripts': [
              'reservation_manager=e2e.reservation_manager.reservation_manager:main',
          ],
      })
