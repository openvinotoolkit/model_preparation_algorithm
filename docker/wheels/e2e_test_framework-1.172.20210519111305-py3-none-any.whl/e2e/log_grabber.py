#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
"""Module that allows to grab logs over ssh"""
import posixpath
import re
import tarfile
import time
from os import remove, makedirs, sep
from os.path import abspath, basename, join

from e2e import config
from e2e.logger import step
from e2e.ssh_lib.jump_client import JumpClient


def grab_logs(jump_client: JumpClient, configuration: list, compress: bool = False):
    """Download logs from host and compresses them to a specified directory.

    Each file is downloaded, added to tar compressed archive, and then removed.
    User must provide a configuration in a list. For example configuration
    check file config.py and the log_grabber_configuration structure.

    Args:
      jump_client: ssh client
      configuration: configuration. For example check log_grabber_configuration in config.py
      compress: if True logs will be compressed
    """
    for conf in configuration:
        # Create the destination directory for logs
        dest_dir = abspath(conf["destination_directory"]) + sep
        makedirs(dest_dir, exist_ok=True)

        files_to_compress = []
        # This provides list of files in format {file1,file2,file3} so scp
        # will download them in single command call
        if len(conf["log_files"]) == 1:
            files_to_download = conf["log_files"][0]
        else:
            files_to_download = "{" + ",".join(conf["log_files"]) + "}"

        # Copy files from the the remote
        jump_client.scp_from_remote(files_to_download, dest_dir)
        for log_file in conf["log_files"]:
            downloaded_log_file = join(dest_dir, basename(log_file))
            files_to_compress.append(downloaded_log_file)

        if compress is False:
            return

        tar_name = jump_client.kwargs["remote_host"]
        if conf["tar_name"] != "":
            tar_name += "." + conf["tar_name"]
        else:
            tar_name += ".tar.gz"
        dest_tar = join(dest_dir, tar_name)
        with tarfile.open(dest_tar, "w:gz") as tar:
            for log in files_to_compress:
                try:
                    tar.add(log, arcname=basename(log))
                except FileNotFoundError:
                    # Don't worry if the file wasn't downloaded, we need to compress
                    # other files
                    continue

                # Remove the log file as it is already in the archive
                remove(log)


def check_str_in_recent_audit_logs(text: str, log_file_path: str) -> bool:
    """Check if substring occurred in recent audit logs

    Args:
        text: substring to find
        log_file_path: path to file with logs
    Returns:
         bool: true if substring occurred in recent audit logs.
    """
    with open(log_file_path, 'r') as audit_logs:
        for line in audit_logs:
            if text in line and is_recent(line, max_delay=120):
                return True
        return False


def get_text_between_parenthesis(text: str) -> str or None:
    """Return substring with content of first parenthesis found in string
    If not found return None.

    Args:
        text: base string
    """
    res = re.search(r'\((.*?)\)', text)
    if res is not None:
        return res.group(1)
    return None


def is_recent(line: str, max_delay: int = 120) -> bool:
    """Validate timestamp and if newer than
    max delay return True"""
    try:
        timestamp = float(get_text_between_parenthesis(line))
        delta = time.time() - timestamp
        if delta < max_delay:
            return True
        return False
    except (ValueError, TypeError):
        return False


def download_audit_log_files(service_account_client: JumpClient):
    """Download audit log files from head"""
    jump_client = service_account_client

    step("List audit log files")
    audit_files, _ = jump_client.execute_ssh_command(["sudo", "ls", "-1tr", config.audit_logs_path])

    step("Remove previous logs in tmp if any")
    jump_client.execute_ssh_command(["sudo", "rm", "-f", config.audit_full_log_path])

    step("Merge audit logs into one")
    for audit_file in audit_files:
        jump_client.execute_ssh_command(["sudo", "cat", posixpath.join(config.audit_logs_path, audit_file),
                                         ">>", config.audit_full_log_path])

    step("Grabing logs from head")
    grab_logs(jump_client, config.log_grabber_configuration)

    step("Remove tmp audit log file on head")
    jump_client.execute_ssh_command(["sudo", "rm", config.audit_full_log_path])

    step("Finished log retrieval from head")
