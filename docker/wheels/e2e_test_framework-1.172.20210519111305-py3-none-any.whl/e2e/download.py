#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
from typing import Union, List

from e2e import config

from e2e.command import run
from e2e.command_wrappers.curl import Curl
from e2e.command_wrappers.wget import WGet


class Downloader:
    """Download files or folder"""
    @staticmethod
    def curl(url: str, file: str):
        """Download file url to file if provided

        Args:
          url: URL
          file: name of the file to save url content
        """
        cmd = Curl(url=url, file=file, verify=config.ssl_validation)
        run(cmd)

    @staticmethod
    def wget_file(url: str, file: str):
        """Download file url to file if provided using wget

        Args:
          url: URL
          file: name of the file to save url content
        """
        cmd = WGet(url=url, file=file, no_check_certificate=config.ssl_validation)
        return run(cmd)

    @staticmethod
    def wget_folder(url, no_clobber: bool = False, time_stamping: bool = False, no_proxy: bool = False,
                    ignore_case: bool = False, user: str = None, password: str = None,
                    no_directories: bool = False, no_host_directories: bool = False, directory_prefix: str = None,
                    cut_dirs: int = None,  content_on_error: bool = False,
                    no_check_certificate: bool = not config.ssl_validation,
                    recursive: bool = True, level: int = None, mirror: bool = False,
                    accept: Union[str, List[str]] = None, reject: Union[str, List[str]] = "index.htm*",
                    accept_regexp: str = None, reject_regexp: str = None,
                    include_dirs: Union[str, List[str]] = None, exclude_dirs: Union[str, List[str]] = None,
                    no_parent: bool = True):
        """Download folder from url using wget

        Args:
            url: URL
            no_clobber: skip downloads that would download to existing files (overwriting them)
            time_stamping: don't re-retrieve files unless newer than local
            no_proxy: explicitly turn off proxy
            ignore_case: ignore case when matching files/directories
            user: both ftp and http user
            password: both ftp and http password
            no_directories: don't create directories
            no_host_directories: don't create host directories
            directory_prefix: directory prefix where to save files
            cut_dirs: ignore NUMBER remote directory components
            content_on_error: output the received content on server errors
            no_check_certificate: don't validate the server's certificate
            recursive: specify recursive download (The default maximum depth is 5.)
            level: maximum recursion depth (inf or 0 for infinite, The default maximum depth is 5.)
            mirror: shortcut for -N -r -l inf --no-remove-listing
            accept: comma-separated list of accepted extensions
            reject: comma-separated list of rejected extensions
            accept_regexp: regex matching accepted URLs
            reject_regexp: regex matching rejected URLs
            include_dirs: list of allowed directories
            exclude_dirs: list of excluded directories
            no_parent: don't ascend to the parent directory
        """
        wget = WGet(url=url,
                    no_clobber=no_clobber, time_stamping=time_stamping,
                    no_proxy=no_proxy,
                    ignore_case=ignore_case,
                    user=user, password=password,
                    no_directories=no_directories, no_host_directories=no_host_directories,
                    directory_prefix=directory_prefix, cut_dirs=cut_dirs,
                    content_on_error=content_on_error, no_check_certificate=no_check_certificate,
                    recursive=recursive, level=level, mirror=mirror,
                    accept=accept, reject=reject,
                    accept_regexp=accept_regexp, reject_regexp=reject_regexp,
                    include_dirs=include_dirs, exclude_dirs=exclude_dirs,
                    no_parent=no_parent)
        return run(wget, shell=True)
