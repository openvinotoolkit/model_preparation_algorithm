#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
from typing import Union

from _pytest.nodes import Item

from e2e.config import repository_name
from .mark_meta import MarkMeta


def __run_type_number_generator():
    counter = 0
    while True:
        yield counter
        counter += 1


run_type_number_iterator = __run_type_number_generator()


class MarkRunType(MarkMeta):
    TEST_MARK_INITIAL = "initial", "run api-initial tests", "api_initial"
    TEST_MARK_UNIT = "unit", "run unit tests", "unit"
    TEST_MARK_COMPONENT = "component", "run component tests", "component"
    TEST_MARK_ON_COMMIT = "api_on_commit", "run api-on-commit tests", "api_on-commit"
    TEST_MARK_ON_MERGE_REQUEST = "api_on_merge", "run api_on_merge tests", "api_on_merge_request"
    TEST_MARK_GUI_ON_MERGE_REQUEST = "gui_on_merge", "run gui_on_merge tests", "gui_on_merge_request"
    TEST_MARK_SMOKE = "api_smoke", "run api-smoke tests", "api_smoke"
    TEST_MARK_REGRESSION = "api_regression", "run api-regression tests", "api_regression"
    TEST_MARK_ENABLING = "api_enabling", "run api-enabling tests", "api_enabling"
    TEST_MARK_MANUAL = "manual", "run api-manual tests", "api_manual"
    TEST_MARK_OTHER = "api_other", "run api-other tests", "api_other"
    TEST_MARK_GUI_SMOKE = "gui_smoke", "run gui-smoke tests", "gui_smoke"
    TEST_MARK_GUI_REGRESSION = "gui_regression", "run gui-regression tests", "gui_regression"
    TEST_MARK_GUI_ENABLING = "gui_enabling", "run gui-enabling tests", "gui_enabling"
    TEST_MARK_GUI_OTHER = "gui_other", "run gui-other tests", "gui_other"
    TEST_MARK_STRESS_AND_LOAD = "api_stress_and_load", "run api-stress-and-load tests", "api_stress-and-load"
    TEST_MARK_LONG = "api_long", "run api-long tests", "api_long"
    TEST_MARK_GUI_LONG = "gui_long", "run gui-long tests", "gui_long"
    TEST_MARK_PERFORMANCE = "api_performance", "run api-performance tests", "api_performance"
    TEST_MARK_HW_SPECIFIC = "api_hw_specific", "run api-hw-specific tests", "api_hw-specific"


    def __init__(self, mark: str, description: str = None, run_type: str = None) -> None:
        MarkMeta.__init__(self, mark, description)
        self.no = next(run_type_number_iterator)
        self.run_type = f"{repository_name}_{run_type}" if repository_name is not None else run_type

    @classmethod
    def test_mark_to_test_run_type(cls, test_type_mark: Union['MarkRunType', str]):
        if isinstance(test_type_mark, str):
            return MarkRunType(test_type_mark).run_type
        return test_type_mark.run_type

    @classmethod
    def get_test_type_mark(cls, item: Item):
        for mark in cls:  # type: 'MarkRunType'
            if item.get_closest_marker(mark.mark):
                return mark
        return None

    @classmethod
    def test_type_mark_to_int(cls, item):
        for mark in cls:  # type: 'MarkRunType'
            if item.get_closest_marker(mark.mark):
                return mark.no
        return cls.__len__()
