#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
from typing import Union

import os
import zipfile

from e2e.download import Downloader
from e2e.exceptions import BaseCommandExecutionException
from e2e.files.file_list import FileList
from e2e.object_model.mount import MountCtxMgr
from e2e.test_names import generate_test_object_name
from e2e import command, config

test_file_list = FileList()  # list of generated files during tests


class FileBase(object):

    def __init__(self, file_name=None, dir_path=None):
        self.file_name = generate_test_object_name(prefix=config.tmp_file_name_prefix) if file_name is None \
            else file_name
        self.dir_path = dir_path
        if self.dir_path is None:
            self.dir_path = config.tmp_dir_test_files
        os.makedirs(self.dir_path, exist_ok=True)
        self.file_path = os.path.join(self.dir_path, file_name)

    def save_file(self, data, flags: str = "w"):
        """
        Saves data: str - to a file and returns its path
        """
        with open(self.file_path, flags) as text_file:
            text_file.write(data)
        self.add()
        return self.file_path

    def save_list_to_file(self, data: list, flags: str = "w"):
        """
        Saves data: list - to a file and returns its path
        """
        try:
            with open(self.file_path, flags) as f:
                f.writelines(["\n".join(data)])
                f.writelines(["\n"])
            return self.file_path
        except IOError:
            return False

    def delete_file(self):
        """
        Delete file
        """
        if os.path.exists(self.file_path):
            os.remove(self.file_path)
        else:
            raise FileNotFoundError

    def add(self):
        """
        Adds a file to list of test files and returns its path
        """
        test_file_list.append(self.file_path)
        return self.file_path

    def zip_file(self):
        """
        Zips a file and returns its path
        """
        if os.path.exists(self.file_path):
            file_name = "{}.zip".format(self.file_name)
            zip_file_path = os.path.join(self.dir_path, file_name)
            with zipfile.ZipFile(zip_file_path, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
                zf.write(self.file_path)
            self.add()
            return zip_file_path

    def download_file(self, url):
        """
        Downloads a file from provided url and return its path
        Args:
            url: url
        """

        Downloader.curl(url=url, file=self.file_path)
        return self.file_path

    @staticmethod
    def copy_file(file_from_path: Union[MountCtxMgr, str],
                  to_path: Union[MountCtxMgr, str]):
        """
        Copy file to a specified destination
        Args:
            specified destination: path
        """
        def _cp_file(src, dst):
            cmd = ["cp", src, dst]
            out, ex_code, _ = command.run(cmd)
            src_file = src if not os.path.isdir(src) else None
            src_dir = src if os.path.isdir(src) else os.path.dirname(src)
            dst_file = dst if not os.path.isdir(dst) else os.path.join(dst, os.path.basename(src))
            dst_dir = dst if os.path.isdir(dst) else os.path.dirname(dst)
            assert os.path.exists(dst_file), "Destination not exist. Something went wrong while copying {}. " \
                                             "Destination content: \n{}\n\n" \
                                             "Source content: \n{}"\
                .format(src_file if src_file is not None else "<src dir>",
                        "\n".join(os.listdir(dst_dir)), "\n".join(os.listdir(src_dir)))
            return out, ex_code

        if isinstance(file_from_path, MountCtxMgr) and isinstance(to_path, MountCtxMgr):
            # TODO: implement copy if needed using temporary location.
            raise NotImplementedError
        elif isinstance(file_from_path, MountCtxMgr):
            with file_from_path as mounted:
                return _cp_file(mounted, to_path)
        elif isinstance(to_path, MountCtxMgr):
            with to_path as mounted:
                return _cp_file(file_from_path, mounted)
        else:
            return _cp_file(file_from_path, to_path)

    @staticmethod
    def list_files(path):
        """
        List files from a specified destination
        Args:
            specified destination: path
        """

        cmd = ["ls", path]
        out, _, _ = command.run(cmd)

        return out

    @staticmethod
    def remove_file(file_path: Union[MountCtxMgr], check_for_removal: bool = False):
        """
        Remove file from a specified destination
        Args:
            specified destination: file_path
        """
        with file_path as mounted:
            cmd = ["rm", mounted]
            try:
                out, _, _ = command.run(cmd)
            except BaseCommandExecutionException as ex:
                ex.output += "\nContents of dir with file to remove \n{}\n".\
                    format("\n".join(os.listdir(os.path.dirname(mounted))))
                raise ex
            if check_for_removal is True:
                assert not os.path.isfile(mounted)
            return out

    @staticmethod
    def file_size(absolute_file_path):
        if os.path.isfile(absolute_file_path):
            return os.path.getsize(absolute_file_path)
        else:
            return sum([FileBase.file_size(os.path.join(absolute_file_path, sub_file))
                        for sub_file in os.listdir(absolute_file_path)])
