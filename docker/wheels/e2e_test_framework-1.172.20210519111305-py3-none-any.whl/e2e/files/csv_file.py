#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

import csv

from e2e.files.file_base import FileBase


class CSVFile(FileBase):

    def generate(self, column_count=10, size=None, row_count=10):
        """
        Return path to the new file.
        Pass row_count or size (in bytes) - if both are passed, size takes precedence.
        """
        with open(self.file_path, "w", newline="") as csv_file:
            if size == 0 or column_count == 0:
                return self.add()
            csv_writer = csv.writer(csv_file, lineterminator='\n')
            csv_writer.writerow(["COL_{}".format(i) for i in range(column_count)])
            row = ["0123456789" for _ in range(column_count)]
            if size is not None:
                while csv_file.tell() < size:
                    csv_writer.writerow(row)
            else:
                for i in range(row_count):
                    csv_writer.writerow(row)
        return self.add()

    def get_csv_record_count(self):
        """
        Return number of rows in chosen csv file
        """
        with open(self.file_path, newline="") as csv_file:
            csv_reader = csv.reader(csv_file)
            row_count = sum(1 for _ in csv_reader)
        return row_count

    def get_csv_data(self):
        """
        Return data from chosen csv file
        """
        with open(self.file_path, newline="") as csv_file:
            return list(csv.reader(csv_file))

    def get_csv_first_row(self):
        """
        Return first row from chosen csv file
        """
        with open(self.file_path, newline="") as csv_file:
            csv_reader = csv.reader(csv_file)
            data = csv_reader.__next__()
        return data
