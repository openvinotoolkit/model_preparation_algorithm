#
# Copyright (c) 2018-2020 Intel Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import os

import cv2
import numpy as np

from e2e.logger import get_logger

logger = get_logger(__name__)


def load_npy(path):
    # optional preprocessing depending on the model
    data = np.load(path, mmap_mode='r', allow_pickle=False)
    data = data - np.min(data)  # Normalization 0-255
    data = data / np.ptp(data) * 255  # Normalization 0-255
    # images = images[:,:,:,::-1] # RGB to BGR
    print('Input ', os.path.basename(path), ' shape: ', data.shape, '; data range:', np.amin(data), ':', np.amax(data))
    return data


def load_npy_labels(path):
    if path is not None:
        labels = np.load(path, mmap_mode='r', allow_pickle=False)
        return labels


def adjust_to_batch_size(np_array, batch_size):
    if batch_size > np_array.shape[0]:
        array = np_array
        for _ in range(int(batch_size / np_array.shape[0]) - 1):
            np_array = np.append(np_array, array, axis=0)
        np_array = np.append(np_array, np_array[:batch_size % array.shape[0]], axis=0)
    else:
        np_array = np_array[:batch_size, ...]
    return np_array


def transpose_input(images, axes):
    tuple_axes = [int(ax) for ax in axes]
    return images.transpose(tuple_axes)


def crop_resize(img, cropx, cropy):
    y, x, c = img.shape
    if y < cropy:
        img = cv2.resize(img, (x, cropy))
        y = cropy
    if x < cropx:
        img = cv2.resize(img, (cropx, y))
        x = cropx
    startx = x//2-(cropx//2)
    starty = y//2-(cropy//2)
    return img[starty:starty+cropy, startx:startx+cropx, :]


def load_jpeg(path: str, size: tuple):
    height, width = size
    img = cv2.imread(path).astype(np.float32)  # BGR color format, shape HWC
    img = cv2.resize(img, (width, height))
    img = img.transpose(2, 0, 1)
    img = img.reshape(1, -1, height, width)
    logger.debug("Image  {}  shape:  {} ; data range: {} : {} ".format(path, img.shape, np.amin(img), np.amax(img)))
    return img


def load_labels(path):
    labels_extension = path.split(sep=".")[-1]
    if labels_extension == "npy":
        return load_npy_labels(path=path)
    elif labels_extension in ["txt", "json"]:
        raise NotImplementedError
    else:
        raise RuntimeError("Incorrect label data type: {}".format(labels_extension))


def load_data(data, size):
    if os.path.isfile(data):
        file_extension = os.path.basename(data).split(sep=".")[-1]
        if file_extension == 'npy':
            inputs = load_npy(data)
            return inputs
        elif file_extension in ['jpg', 'jpeg']:
            inputs = load_jpeg(data, size)
            return inputs
        else:
            raise AssertionError("incorrect input_data_type value: {}".format(file_extension))
    elif os.path.isdir(data):
        inputs = []
        images = os.listdir(data)
        file_extension = os.path.basename(images[-1]).split(sep=".")[-1].lower()
        if file_extension in ['jpg', 'jpeg']:
            for img in images:
                path = os.path.join(data, img)
                inputs.append(load_jpeg(path, size))
            assert images, "Lack of data to load with search path: {}".format(data)
            inputs = np.concatenate(inputs, axis=0)
            return inputs
        else:
            raise AssertionError("incorrect input_data_type value: {} for provided input path (dir): {}"
                                 .format(file_extension, data))
    return


def prepare_data(data, size, batch_size, transpose_axes=None):
    input_data = load_data(data=data, size=size)
    input_data = adjust_to_batch_size(np_array=input_data, batch_size=int(batch_size))
    if transpose_axes:
        input_data = transpose_input(images=input_data, axes=transpose_axes)
    return input_data
