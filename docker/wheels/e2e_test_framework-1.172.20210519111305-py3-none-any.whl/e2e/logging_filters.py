#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import re
from typing import Union

from e2e import config
import logging

import e2e.constants.framework_constants


class SensitiveKeysStrippingFilter(logging.Filter):
    instance = None
    sensitive_pairs = None  # type: dict
    sensitive_values_to_be_masked = None  # type: re

    def __new__(cls) -> 'SensitiveKeysStrippingFilter':
        if cls.instance is None:
            cls.instance = super().__new__(cls)
            cls.sensitive_pairs = cls.gather_sensitive_pairs()
            cls.sensitive_values_to_be_masked = list(cls.sensitive_pairs.values())
        return cls.instance

    @classmethod
    def build_sensitive_values_regexp(cls) -> re:
        return re.compile(
            "|".join([r"{value}".format(value=var)
                      for var in cls.sensitive_pairs.values()]))

    @classmethod
    def gather_sensitive_pairs(cls) -> dict:
        return dict([(var, getattr(config, var, None))
                     for var in dir(config)
                     if cls.is_matching_variable(var)])

    @staticmethod
    def is_matching_variable(var) -> bool:
        if config.sensitive_keys_to_be_masked.match(var):
            var_value = getattr(config, var, e2e.constants.framework_constants.UNDEFINED)
            if var_value is not e2e.constants.framework_constants.UNDEFINED and \
                    isinstance(var_value, str) and \
                    len(var_value) > 0:
                return True
        return False

    def filter(self, record: logging.LogRecord) -> bool:
        record.msg = self.strip_sensitive_data(record.msg)
        record.args = self.filter_args(record.args)
        return True

    def filter_args(self, args: Union[dict, tuple]) -> Union[dict, tuple]:
        if not isinstance(args, (dict, tuple)):
            return args
        if isinstance(args, dict):
            args = self.strip_sensitive_data(args)
        else:
            args = tuple(self.strip_sensitive_data(arg) for arg in args)
        return args

    def strip_sensitive_data(self, data: Union[dict, str]) -> Union[dict, str]:
        if config.strip_sensitive_data:
            if isinstance(data, str) and len(data) > 0:
                data = self.strip_sensitive_str_values(data)
            elif isinstance(data, dict):
                data = self.strip_sensitive_dict_values(data.copy())
        return data

    def strip_sensitive_dict_values(self, data: dict) -> dict:
        for key, value in data.items():
            if value in self.sensitive_values_to_be_masked:
                data[key] = "***<masked by logger>***"
        return data

    def strip_sensitive_str_values(self, data: str) -> str:
        stripped_data = data
        for sensitive_value_to_be_masked in self.sensitive_values_to_be_masked:
            stripped_data = stripped_data.replace(sensitive_value_to_be_masked, "***<masked by logger>***")
        return stripped_data
