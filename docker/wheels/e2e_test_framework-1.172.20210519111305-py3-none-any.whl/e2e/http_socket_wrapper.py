#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import re
import socket
from time import time


class HttpSocketWrapper():
    _EXP_BODY_LEN = re.compile(r'Content-Length: (\d+)\s')
    _EXP_BODY_SEPARATOR = re.compile(r'\s{4}')

    def __init__(self, host, port):
        self._family = socket.AF_INET
        self._type = socket.SOCK_STREAM
        self.host = host
        self.port = port

    def send(self, method, path, body='', headers={}):
        default_headers = {"Host": f"{self.host}:{self.port}",
                           "Content-Length": str(len(body)),
                           "Connection": 'close'}
        default_headers.update(headers)
        header = f"{method} {path} HTTP/1.1\n"
        for name, value in default_headers.items():
            header += f"{name}: {value}\n"
        header += "\n"
        msg = header.encode('ascii') + body.encode('ascii')

        with socket.socket(self._family, self._type) as soc:
            soc.connect((self.host, self.port))
            start = time()
            soc.sendall(msg)

            header, body = self._receive(soc)
            end = time()

        return end - start, header, body

    def _receive(self, soc):
        base_len, header, body = 10, '', ''

        while HttpSocketWrapper._EXP_BODY_SEPARATOR.search(header) is None:
            header += soc.recv(base_len).decode('ascii')

        match = HttpSocketWrapper._EXP_BODY_SEPARATOR.search(header)
        body = header[match.end():]
        header = header[:match.start()]

        match = HttpSocketWrapper._EXP_BODY_LEN.search(header)
        if match:
            body_len = int(match.group(1))
            base_len = body_len - len(body)
            body += soc.recv(base_len).decode('ascii')
        else:
            tmp_msg = soc.recv(base_len).decode('ascii')
            while len(tmp_msg) > 0:
                body += tmp_msg
                tmp_msg = soc.recv(base_len).decode('ascii')

        return header, body
