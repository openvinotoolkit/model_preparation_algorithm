#
# INTEL CONFIDENTIAL
# Copyright (c) 2021 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
from e2e.command_wrappers import Command


class Ffmpeg(Command):

    COMMAND = "ffmpeg"
    LEVEL_OPTION = "-loglevel"
    LOGLEVEL_QUIET = "quiet"
    INPUT_OPTION = "-f"
    INPUT_X11GRAB = "x11grab"
    VIDEO_SIZE_OPTION = "-video_size"
    DISPLAY_NUMBER_OPTION = "-i"

    def __init__(self):
        super().__init__()

    def ffmpeg(self, video_height, video_width, loglevel_quiet, display_number, output_file):
        ffmpeg = list()
        if loglevel_quiet:
            ffmpeg.append(self.LEVEL_OPTION)
            ffmpeg.append(self.LOGLEVEL_QUIET)
        ffmpeg.append(self.INPUT_OPTION)
        ffmpeg.append(self.INPUT_X11GRAB)
        ffmpeg.append(self.VIDEO_SIZE_OPTION)
        video_size = f"{video_width}x{video_height}"
        ffmpeg.append(video_size)
        ffmpeg.append(self.DISPLAY_NUMBER_OPTION)
        ffmpeg.append(display_number)
        ffmpeg.append(output_file)
        return list(self) + ffmpeg
