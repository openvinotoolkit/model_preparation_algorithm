#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import os
from typing import Any

from abc import ABCMeta

from e2e import config

from e2e.command_wrappers import Command
from e2e.constants.supported_oses import OS


class Mount(Command):
    @classmethod
    def get_class(cls):
        if config.os_name == OS.Linux:
            return MountLinux
        elif config.os_name == OS.Darwin:
            return MountDarwin
        elif config.os_name == OS.Windows:
            return MountWindows
        else:
            raise RuntimeError("not supported os")

    def __new__(cls, *args, **kwargs) -> Any:
        return super().__new__(cls.get_class())

    @classmethod
    def mount(cls, remote_host, samba_share, local_dir=None, username=None, password=None, domain=None, **kwargs):
        return cls.get_class().mount(remote_host, samba_share, local_dir=local_dir, username=username,
                                     password=password, domain=domain, **kwargs)

    @classmethod
    def list(cls, **kwargs):
        return cls.get_class().list(**kwargs)

    @classmethod
    def umount(cls, local_dir: str, **kwargs):
        return cls.get_class().umount(local_dir, **kwargs)


class MountPosix(Mount, metaclass=ABCMeta):
    COMMAND = "mount"
    UMOUNT = "umount"
    LAZY = "--lazy"
    FORCE = "-f"

    def _add_local_dir(self, local_dir) -> 'Mount':
        if local_dir is not None:
            self.append(local_dir)
        return self

    @classmethod
    def list(cls, sudo_password: str = config.sudo_password, **kwargs):
        self = cls(add_sudo=True, sudo_password=sudo_password, **kwargs)
        return self


class MountDarwin(MountPosix):
    """
    List of strings representation of selected options.
    """
    COMMAND = "mount"
    REMOTE_LOCATION = "//'{}:{}'@{}/{}".format

    @classmethod
    def mount(cls, remote_host, samba_share, local_dir=None, username=None, password=None, domain=None, **kwargs):
        """
        Generate mount command as a list of command line options.
        """
        self = cls(command="mount_smbfs", **kwargs)
        self.append(self.REMOTE_LOCATION(username, password, remote_host, samba_share))
        self._add_local_dir(local_dir)
        return self

    @classmethod
    def umount(cls, local_dir, sudo_password: str = config.sudo_password, force: bool = True, **kwargs):
        """
        Generate mount command as a list of command line options.
        """
        self = cls(add_sudo=True, sudo_password=sudo_password, command=cls.UMOUNT, **kwargs)
        if force:
            self.append(self.FORCE)
        self._add_local_dir(local_dir)
        # other parameters to form a command like:
        # echo zzz | sudo --stdin --reset-timestamp umount /home/osboxes/samba_test
        # parameters: local_dir
        return self


class MountLinux(MountPosix):
    """
    List of strings representation of selected options.
    """
    TYPES = "--types"
    CIFS = "cifs"
    OPTIONS = "--options"
    VERSION_FORMAT = "vers={}".format
    VERSION = "3.0"
    USERNAME = "username={}".format
    DOMAIN = "domain={}".format
    UID = "uid={}".format
    PASSWORD = "password={}".format
    REMOTE_LOCATION = "//{}/{}".format

    @classmethod
    def mount(cls, remote_host, samba_share, local_dir=None, username=None, password=None, domain=None,
              uid=None, sudo_password: str = config.sudo_password, **kwargs):
        """
        Generate mount command as a list of command line options.
        """
        uid = uid if uid is not None else os.getuid()
        self = cls(add_sudo=True, sudo_password=sudo_password, **kwargs)
        self.append(self.TYPES)
        self.append(self.CIFS)
        self._options(username, password, domain, uid)
        self.append(self.REMOTE_LOCATION(remote_host, samba_share))
        self._add_local_dir(local_dir)
        # other parameters to form a command like:
        # echo zzz | sudo --stdin --reset-timestamp mount --types cifs //fatboy.sclab.intel.com/Public/
        # /home/osboxes/samba_test/ --options vers=3.0,username=pgrubick,domain=GER,password=xxx
        # parameters: samba_share, local_dir, username, password, domain
        return self

    def _options(self, username=None, password=None, domain=None, uid=None) -> 'MountLinux':
        username_option = self.USERNAME(username) if username is not None else None
        password_option = self.PASSWORD(password) if password is not None else None
        domain_option = self.DOMAIN(domain) if domain is not None else None
        uid_option = self.UID(uid) if uid is not None else None
        options = [self.VERSION_FORMAT(self.VERSION), username_option, password_option, domain_option, uid_option]
        options = [option for option in options if option is not None]
        self.append(self.OPTIONS)
        self.append(','.join(options))
        return self

    @classmethod
    def umount(cls, local_dir, sudo_password: str = config.sudo_password, force: bool = False, lazy: bool = True,
               **kwargs):
        """
        Generate mount command as a list of command line options.
        """
        self = cls(add_sudo=True, sudo_password=sudo_password, command=cls.UMOUNT, **kwargs)
        if lazy:
            self.append(self.LAZY)
        if force:
            self.append(self.FORCE)
        self._add_local_dir(local_dir)
        # other parameters to form a command like:
        # echo zzz | sudo --stdin --reset-timestamp umount /home/osboxes/samba_test
        # parameters: local_dir
        return self


class MountWindows(Mount):
    COMMAND = "net"
    USE = "use"
    DELETE = "/DELETE"
    DELETE_CONFIRMATION = "/y"
    USER = "/USER:{domain}{user}".format
    DOMAIN = "{domain}\\".format
    UNC = r"\\{remote_host}\{samba_share}".format
    # DEVICE_NAME = config.
    PERSISTENT = "/PERSISTENT:{is_persistent}".format

    @classmethod
    def mount(cls, remote_host, samba_share, local_dir=None, username=None, password=None, domain=None, **kwargs):
        self = cls(**kwargs)
        self.append(self.USE)
        self.append(local_dir)
        self._unc_remote_path(remote_host, samba_share)
        self._password(password)
        self._user(username, domain)
        self._persistent(False)
        return self

    @classmethod
    def list(cls, **kwargs):
        self = cls(**kwargs)
        self.append(self.USE)
        return self

    @classmethod
    def umount(cls, local_dir, **kwargs):
        self = cls(**kwargs)
        self.append(self.USE)
        self.append(local_dir)
        self.append(self.DELETE)
        self.append(self.DELETE_CONFIRMATION)
        return self

    def _unc_remote_path(self, remote_host: str, samba_share: str):
        self.append(self.UNC(remote_host=remote_host, samba_share=samba_share))
        return self

    def _password(self, password: str = None):
        if password is not None:
            self.append(password)
        return self

    def _user(self, user_name: str, domain_name: str = None):
        if user_name is not None:
            if domain_name is not None:
                self.append(self.USER(domain=self.DOMAIN(domain=domain_name), user=user_name))
            else:
                self.append(self.USER(domain="", user=user_name))
        return self

    def _persistent(self, persistent: bool = None):
        if persistent is not None:
            self.append(self.PERSISTENT(is_persistent="YES" if persistent is True else "NO"))
        return self
