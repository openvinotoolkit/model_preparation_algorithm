#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

from enum import Enum

from e2e.command_wrappers import Command


class Date(Command):

    class TimeSpecRFC(Enum):
        """It is used as precision definition RFC format"""
        DATE = "date"
        SECONDS = "seconds"
        NANOSECONDS = "ns"

    class TimeSpecISO(Enum):
        """It is used as precision definition for ISO format"""
        DATE = "date"
        HOURS = "hours"
        MINUTES = "minutes"
        SECONDS = "seconds"
        NANOSECONDS = "ns"

    DATE_TIME = "date"
    ISO_8601 = "--iso-8601={time_spec}".format
    FORMAT = "+'{format}'".format

    def __init__(self, format_: str = None, iso: TimeSpecISO = None):
        """
        Args:
            format_: date format options see man date for details
            iso: timespec for iso 8601 format
        """
        super().__init__(add_pipe=False)
        self.date()
        self.format(format_)
        self.iso(iso)

    def date(self) -> 'Date':
        """
        adds date command
        Returns: self
        """
        self.append(self.DATE_TIME)
        return self

    def format(self, format_: str = None) -> 'Date':
        """
        Args:
            format_: date format string
        Returns: self
        """
        if format_ is not None and len(format_):
            self.append(self.FORMAT(format=format_))
        return self

    def iso(self, time_spec: TimeSpecISO) -> 'Date':
        """
        Args:
            time_spec: precision for iso format
        Returns self
        """
        if time_spec is not None and isinstance(time_spec, Date.TimeSpecISO):
            self.append(self.ISO_8601(time_spec=time_spec.value))
        return self
