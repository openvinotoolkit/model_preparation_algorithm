#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
from typing import List, Union

from e2e.command_wrappers import Command


class WGet(Command):
    COMMAND = "wget"
    # Download:
    NO_CLOBBER = "--no-clobber"  # skip downloads that would download to existing files (overwriting them)
    FILE = "-O"  # write documents to FILE
    TIME_STAMPING = "--timestamping"  # don't re-retrieve files unless newer than local
    NO_PROXY = "--no-proxy"  # explicitly turn off proxy
    IGNORE_CASE = "--ignore-case"  # ignore case when matching files/directories
    USER_FORMAT = "--user={}"  # set both ftp and http user to USER
    PASSWORD_FORMAT = "--password={}"  # set both ftp and http password to PASS

    # Directories:
    NO_DIRECTORIES = "--no-directories"  # don't create directories
    NO_HOST_DIRECTORIES = "--no-host-directories"  # don't create host directories
    DIRECTORY_PREFIX_FORMAT = "--directory-prefix={}"  # save files to PREFIX/..
    CUT_DIRS_FORMAT = "--cut-dirs={}"  # ignore NUMBER remote directory components

    # HTTP options:
    CONTENT_ON_ERROR = "--content-on-error"  # output the received content on server errors

    # HTTPS (SSL/TLS) options:
    NO_CHECK_CERTIFICATE = "--no-check-certificate"  # don't validate the server's certificate

    # Recursive download:
    RECURSIVE = "-r"  # specify recursive download
    LEVEL_FORMAT = "--level={}"  # maximum recursion depth (inf or 0 for infinite)
    MIRROR = "--mirror"  # shortcut for -N -r -l inf --no-remove-listing

    # Recursive accept/reject:
    ACCEPT_FORMAT = "--accept={}"  # comma-separated list of accepted extensions
    REJECT_FORMAT = "--reject={}"  # comma-separated list of rejected extensions
    ACCEPT_REGEX_FORMAT = "--accept-regex={}"  # regex matching accepted URLs
    REJECT_REGEX_FORMAT = "--reject-regex={}"  # regex matching rejected URLs
    INCLUDE_DIRECTORIES_FORMAT = "--include-directories={}"  # list of allowed directories
    EXCLUDE_DIRECTORIES_FORMAT = "--exclude-directories={}"  # list of excluded directories
    NO_PARENT = "--no-parent"  # don't ascend to the parent directory

    def __init__(self, url: str, add_pipe: bool = False, add_sudo: bool = False,
                 no_clobber: bool = False, file: str = None,
                 time_stamping: bool = False, no_proxy: bool = False, ignore_case: bool = False,
                 user: str = None, password: str = None,
                 no_directories: bool = False, no_host_directories: bool = False, directory_prefix: str = None,
                 cut_dirs: int = None,  content_on_error: bool = False, no_check_certificate: bool = False,
                 recursive: bool = False, level: int = None, mirror: bool = False,
                 accept: Union[str, List[str]] = None, reject: Union[str, List[str]] = None,
                 accept_regexp: str = None, reject_regexp: str = None,
                 include_dirs: Union[str, List[str]] = None, exclude_dirs: Union[str, List[str]] = None,
                 no_parent: bool = False):
        """
         Builds wget command line as a list of strings
        Args:
            add_pipe: adds a pipe before command
            add_sudo: adds sudo before command
            url: url to get
            no_clobber: skip downloads that would download to existing files (overwriting them)
            file: path to file to write to
            time_stamping: don't re-retrieve files unless newer than local
            no_proxy: explicitly turn off proxy
            ignore_case: ignore case when matching files/directories
            user: both ftp and http user
            password: both ftp and http password
            no_directories: don't create directories
            no_host_directories: don't create host directories
            directory_prefix: directory prefix where to save files
            cut_dirs: ignore NUMBER remote directory components
            content_on_error: output the received content on server errors
            no_check_certificate: don't validate the server's certificate
            recursive: specify recursive download (The default maximum depth is 5.)
            level: maximum recursion depth (inf or 0 for infinite, The default maximum depth is 5.)
            mirror: shortcut for -N -r -l inf --no-remove-listing
            accept: comma-separated list of accepted extensions
            reject: comma-separated list of rejected extensions
            accept_regexp: regex matching accepted URLs
            reject_regexp: regex matching rejected URLs
            include_dirs: list of allowed directories
            exclude_dirs: list of excluded directories
            no_parent: don't ascend to the parent directory
        """
        super().__init__(add_pipe, add_sudo)
        self.no_clobber(no_clobber)
        self.file(file)
        self.time_stamping(time_stamping)
        self.no_proxy(no_proxy)
        self.ignore_case(ignore_case)
        self.user(user)
        self.password(password)
        self.directory(no_directories, no_host_directories, directory_prefix, cut_dirs)
        self.content_on_error(content_on_error)
        self.no_check_certificate(no_check_certificate)
        self.recursive(recursive)
        self.level(level)
        self.mirror(mirror)
        self.accept(accept)
        self.reject(reject)
        self.accept_regexp(accept_regexp)
        self.reject_regexp(reject_regexp)
        self.include_dirs(include_dirs)
        self.exclude_dirs(exclude_dirs)
        self.no_parent(no_parent)
        self.append(url)

    def no_clobber(self, no_clobber: bool = False):
        if no_clobber:
            self.append(self.NO_CLOBBER)
        return self

    def file(self, file: str = None) -> 'WGet':
        if file is not None:
            self.append(self.FILE)
            self.append(file)
        return self

    def time_stamping(self, time_stamping: bool = False):
        if time_stamping:
            self.append(self.TIME_STAMPING)
        return self

    def no_proxy(self, no_proxy: bool = False):
        if no_proxy:
            self.append(self.NO_PROXY)
        return self

    def ignore_case(self, ignore_case: bool = False):
        if ignore_case:
            self.append(self.IGNORE_CASE)
        return self

    def user(self, user: str = None):
        if user is not None:
            self.append(self.USER_FORMAT.format(user))
        return self

    def password(self, password: str = None):
        if password is not None:
            self.append(self.PASSWORD_FORMAT.format(password))
        return self

    def directory(self, no_directories: bool = False, no_host_directories: bool = False,
                  directory_prefix: str = None, cut_dirs: int = None) -> 'WGet':
        if directory_prefix is not None:
            self.append(self.DIRECTORY_PREFIX_FORMAT.format(directory_prefix))
        if no_host_directories:
            self.append(self.NO_HOST_DIRECTORIES)
        if no_directories:
            self.append(self.NO_DIRECTORIES)
        if cut_dirs is not None:
            self.append(self.CUT_DIRS_FORMAT.format(cut_dirs))
        return self

    def content_on_error(self, content_on_error: bool = False):
        if content_on_error:
            self.append(self.CONTENT_ON_ERROR)
        return self

    def no_check_certificate(self, no_check_certificate: bool = False) -> 'WGet':
        if no_check_certificate:
            self.append(self.NO_CHECK_CERTIFICATE)
        return self

    def recursive(self, recursive: bool = False) -> 'WGet':
        if recursive:
            self.append(self.RECURSIVE)
        return self

    def level(self, level: int = None):
        if level is not None:
            self.append(self.LEVEL_FORMAT.format(level))
        return self

    def mirror(self, mirror: bool = False):
        if mirror:
            self.append(self.MIRROR)
        return self

    def accept(self, accept: Union[str, List[str]] = None) -> 'WGet':
        if accept is not None:
            accept = [accept] if isinstance(accept, str) else accept
            self.append(self.ACCEPT_FORMAT.format(",".join(accept)))
        return self

    def reject(self, reject: Union[str, List[str]] = None) -> 'WGet':
        if reject is not None:
            reject = [reject] if isinstance(reject, str) else reject
            self.append(self.REJECT_FORMAT.format(",".join(reject)))
        return self

    def accept_regexp(self, accept_regexp: str = None):
        if accept_regexp is not None:
            self.append(self.ACCEPT_REGEX_FORMAT.format(accept_regexp))
        return self

    def reject_regexp(self, reject_regexp: str = None):
        if reject_regexp is not None:
            self.append(self.REJECT_REGEX_FORMAT.format(reject_regexp))
        return self

    def include_dirs(self, include_dirs: Union[str, List[str]] = None):
        if include_dirs is not None:
            include_dirs = [include_dirs] if isinstance(include_dirs, str) else include_dirs
            self.append(self.INCLUDE_DIRECTORIES_FORMAT.format(",".join(include_dirs)))
        return self

    def exclude_dirs(self, exclude_dirs: Union[str, List[str]] = None):
        if exclude_dirs is not None:
            exclude_dirs = [exclude_dirs] if isinstance(exclude_dirs, str) else exclude_dirs
            self.append(self.EXCLUDE_DIRECTORIES_FORMAT.format(",".join(exclude_dirs)))
        return self

    def no_parent(self, no_parent: bool = False) -> 'WGet':
        if no_parent:
            self.append(self.NO_PARENT)
        return self
