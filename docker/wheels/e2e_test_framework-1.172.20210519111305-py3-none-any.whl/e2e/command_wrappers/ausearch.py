#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

from .command_wrappers import Command


class Ausearch(Command):

    AUSEARCH = "ausearch"
    INPUT_LOGS = "--input-logs"
    RAW = "--raw"
    START = "--start"
    END = "--end"
    GROUP = "--gid"
    USER = "--uid"

    def __init__(self, add_pipe=False, add_sudo=True,
                 since_date: str = None, since_time=None,
                 until_date: str = None, until_time=None, raw=True,
                 uid=None, gid=None):
        """
        Generate admin log command as a list of command line options.

        :param add_pipe: adds '|' before all to commands stacking, redirecting
        :param since_date: select since date for ausearch, if None, 'today' is used
        :param since_time: select since time for ausearch, if None, 'Midnight' is used
        :param until_date: select until date for ausearch, if None, 'today' is used
        :param until_time: select until time for ausearch, if None, 'Now' is used
        :param raw: output in raw log or formatted
        """
        super().__init__(add_pipe=add_pipe, add_sudo=add_sudo)
        self.audit_log()
        self.append(self.INPUT_LOGS)
        self.raw(raw)
        self.since(since_date, since_time)
        self.until(until_date, until_time)
        self.group_id(gid)
        self.user_id(uid)
        self.strip_error_on_opening_config_file()

    def strip_error_on_opening_config_file(self):
        """
        remove Error opening config file (Permission denied)
        NOTE - using built-in logs: /var/log/audit/audit.log
        """
        self.append(r"2>/dev/null")

    def audit_log(self) -> 'Ausearch':
        """
        adds audit log command
        :return: self
        """
        self.append(self.AUSEARCH)
        return self

    def since(self, since_date: str = None, since_time: str = None) -> 'Ausearch':
        """
        :param since_date: select since date for ausearch, if None, 'today' is used
        :param since_time: select since time for ausearch, if None, 'Midnight' is used
        :return:
        """
        if since_date or since_time:
            self.append(self.START)
        if since_date:
            self.append(since_date)
        if since_time:
            self.append(since_time)
        return self

    def until(self, until_date: str = None, until_time: str = None) -> 'Ausearch':
        """
        :param until_date: select until date for ausearch, if None, 'today' is used
        :param until_time: select until time for ausearch, if None, 'Now' is used
        :return:
        """
        if until_date or until_time:
            self.append(self.END)
        if until_date:
            self.append(until_date)
        if until_time:
            self.append(until_time)
        return self

    def raw(self, raw: bool = True) -> 'Ausearch':
        if raw:
            self.append(self.RAW)
        return self

    def group_id(self, gid: str) -> 'Ausearch':
        if gid not in [None, ""]:
            self.append(self.GROUP)
            self.append(gid)
        return self

    def user_id(self, uid: str) -> 'Ausearch':
        if uid not in [None, ""]:
            self.append(self.USER)
            self.append(uid)
        return self
