#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

from enum import Enum
from typing import Union, List, Set, Tuple

from e2e.command_wrappers import Command


class Grep(Command):
    """
    List of strings representation of selected options.
    """
    class Variant(Enum):
        BASIC = "--basic-regexp"
        EXTENDED = "--extended-regexp"
        FIXED_STRINGS = "--fixed-strings"
        PERL = "--perl-regexp"

    GREP = "grep"
    REGEXP = "--regexp='{pattern}'".format
    IGNORE_CASE = "--ignore-case"
    INVERT_MATCH = "--invert-match"
    WORD_REGEXP = "--word-regexp"
    LINE_REGEXP = "--line-regexp"

    COUNT = "--count"
    MAX_COUNT = "--max-count={num}".format
    ONLY_MATCHING = "--only-matching"
    QUIET = "--quiet"
    NO_MESSAGES = "--no-messages"

    LINE_NUMBER = "--line-number"
    AFTER_CONTEXT = "--after-context={A}".format
    BEFORE_CONTEXT = "--before-context={B}".format
    CONTEXT = "--context={C}".format
    GROUP_SEPARATOR = "--group-separator='{separator}'".format

    def __init__(self, pattern: Union[List[str], Set[str], Tuple[str, ...], str] = None,
                 add_pipe: bool = True, ignore_case: bool = True,
                 invert_match: bool = False,
                 word_regexp: bool = False, line_regexp: bool = False,
                 count: bool = False, max_count: int = None,
                 only_matching: bool = False,
                 quiet: bool = False, no_messages: bool = False,
                 line_number: bool = False,
                 a: int = None, b: int = None, c: int = None, group_separator: str = None,
                 variant: Variant = Variant.BASIC):
        """
        Generate Grep command as a list of command line options.

        :param pattern: grep pattern, can be a list of patterns, cannot be empty
        :param add_pipe: adds '|' before all to commands stacking, redirecting
        :param ignore_case: ignore case distinctions.
        :param invert_match: invert the sense of matching.
        :param word_regexp: select only those lines containing matches that form whole words.
        :param line_regexp: select only those matches that exactly match the whole line.
        :param count: count number of matches (suppress normal output).
        :param max_count: stop after max number of matches.
        :param only_matching: show only matched parts of matching lines.
        :param quiet: do not write anything to standard output.
        :param no_messages: suppress error messages about nonexistent or unreadable files.
        :param line_number: to show line numbers in output.
        :param a: number of lines after match.
        :param b: number of lines before match.
        :param c: number of lines around match (before and after).
        :param group_separator: separator between groups of lines before and after match.
        :param variant: enables grep variant of pattern execution.
        """
        super().__init__(add_pipe=add_pipe)
        self.grep()
        self.pattern(pattern)
        self.ignore_case(ignore_case)
        self.invert_match(invert_match)
        self.word_regexp(word_regexp)
        self.line_regexp(line_regexp)
        self.count(count)
        self.max_count(max_count)
        self.only_matching(only_matching)
        self.quiet(quiet)
        self.no_messages(no_messages)
        self.line_number(line_number)
        self.a(a).b(b).c(c).group_separator(group_separator)
        self.variant(variant)

    def grep(self) -> 'Grep':
        """
        adds grep command
        :return: self
        """
        self.append(self.GREP)
        return self

    def pattern(self, pattern: Union[List[str], Set[str], Tuple[str, ...], str] = None) -> 'Grep':
        """
        :param pattern: grep pattern, can be a list of patterns, cannot be empty
        :return: self
        """
        if pattern is None:
            raise RuntimeError("Pattern cannot be None")
        for pat in pattern if isinstance(pattern, (list, set, tuple)) else [pattern]:
            if pat is None or not isinstance(pat, str):
                raise RuntimeError("Pattern must be not None str")
            self.append(self.REGEXP(pattern=pat))
        return self

    def ignore_case(self, enable: bool = True) -> 'Grep':
        """
        :param enable: ignoring case distinctions.
        :return: self
        """
        if enable:
            self.append(self.IGNORE_CASE)
        return self

    def invert_match(self, enable: bool = False) -> 'Grep':
        """
        :param enable: inverting the sense of matching.
        :return: self
        """
        if enable:
            self.append(self.INVERT_MATCH)
        return self

    def word_regexp(self, enable: bool = False) -> 'Grep':
        """
        :param enable: selecting only those lines containing matches that form whole words.
        :return: self
        """
        if enable:
            self.append(self.WORD_REGEXP)
        return self

    def line_regexp(self, enable: bool = False) -> 'Grep':
        """
        :param enable: selecting only those matches that exactly match the whole line.
        :return: self
        """
        if enable:
            self.append(self.LINE_REGEXP)
        return self

    def count(self, enable: bool = False) -> 'Grep':
        """
        :param enable: counting number of matches (suppress normal output).
        :return: self
        """
        if enable:
            self.append(self.COUNT)
        return self

    def max_count(self, value: int = None) -> 'Grep':
        """
        :param value: stop after {value} number of matches.
        :return: self
        """
        if value is not None and value > 0:
            self.append(self.MAX_COUNT(num=value))
        return self

    def only_matching(self, enable: bool = False) -> 'Grep':
        """
        :param enable: showing only matched parts of matching lines.
        :return: self
        """
        if enable:
            self.append(self.ONLY_MATCHING)
        return self

    def quiet(self, enable: bool = False) -> 'Grep':
        """
        :param enable: not writing anything to standard output.
        :return: self
        """
        if enable:
            self.append(self.QUIET)
        return self

    def no_messages(self, enable: bool = False) -> 'Grep':
        """
        :param enable: suppressing error messages about nonexistent or unreadable files.
        :return: self
        """
        if enable:
            self.append(self.NO_MESSAGES)
        return self

    def line_number(self, enable: bool = False) -> 'Grep':
        """
        :param enable: showing line numbers in output.
        :return: self
        """
        if enable:
            self.append(self.LINE_NUMBER)
        return self

    def a(self, value: int = None) -> 'Grep':
        """
        :param value: show {value} of lines after match.
        :return: self
        """
        if value is not None and value > 0:
            self.append(self.AFTER_CONTEXT(A=value))
        return self

    def b(self, value: int = None) -> 'Grep':
        """
        :param value: show {value} of lines before match.
        :return: self
        """
        if value is not None and value > 0:
            self.append(self.BEFORE_CONTEXT(B=value))
        return self

    def c(self, value: int = None) -> 'Grep':
        """
        :param value: show {value} of lines before and after match.
        :return: self
        """
        if value is not None and value > 0:
            self.append(self.CONTEXT(C=value))
        return self

    def group_separator(self, value: str = None) -> 'Grep':
        """
        :param value: adds {value} as a separator between groups of lines before and after match.
        :return: self
        """
        if value is not None and len(value) > 0:
            self.append(self.GROUP_SEPARATOR(separator=value))
        return self

    def variant(self, variant: Variant = Variant.BASIC) -> 'Grep':
        """
        :param variant: sets grep variant of pattern execution.
        :return: self
        """
        if variant is not None and isinstance(variant, Grep.Variant):
            self.append(variant.value)
        return self
