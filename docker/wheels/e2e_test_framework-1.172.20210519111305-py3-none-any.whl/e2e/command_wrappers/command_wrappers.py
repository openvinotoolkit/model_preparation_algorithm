#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

from enum import Enum
from typing import NamedTuple, List


class OptionEnum(Enum):
    """
    Base class to create enums of command options.
    """
    __option_name__ = None

    def __new__(cls, name_or_value: str, value=None):
        """
        Creates enum instances.
        It can be used in 3 modes:
        ENUM_ENTRY = value
        ENUM_ENTRY = name, value
        ENUM_ENTRY = name
        :param name_or_value: value or name of value if second argument is filled.
        :param value: optional value argument.
        :return:
        """
        oe = object.__new__(cls)
        oe._value_ = value if value is not None else name_or_value  # internal Enum variable
        oe._value_name = name_or_value
        oe._name_ = name_or_value  # internal Enum variable
        return oe

    def __call__(self) -> str:
        return self.option

    def get_value_name(self):
        return self._value_name

    @property
    def option(self) -> str:
        return "--{option}={value}".format(
            option=self.__option_name__ or self.__class__.__name__.lower(),
            value=self._value_name)


class Command(List[str]):
    """
    Base class for all command wrappers.
    """
    PIPE = "|"
    SUDO = "sudo"
    COMMAND = None
    ECHO = "echo"
    STD_IN = "-S"  # "--stdin not works on some systems"
    RESET_TIMESTAMP = "-k"  # "--reset-timestamp not work on some systems"
    SUDO_PASSWORD = "'{}'".format

    def __init__(self, add_pipe=False, add_sudo=False, command: str = None,
                 sudo_password: str = None, std_in: bool = False, reset_timestamp: bool = False):
        """
        :param add_pipe: adds '|' before all to commands stacking, redirecting
        :param add_sudo: adds 'sudo'
        """
        super().__init__()
        if sudo_password is not None:
            add_sudo = True
            add_pipe = True
            std_in = True
            reset_timestamp = True
        self.sudo_password(password=sudo_password)
        self.pipe(add_pipe=add_pipe)
        self.sudo(add_sudo=add_sudo, std_in=std_in, reset_timestamp=reset_timestamp)
        self.command(command)

    def __str__(self) -> str:
        return " ".join([str(c) for c in self])

    def sudo_password(self, password: str = None):
        if password is not None:
            self.append(self.ECHO)
            self.append(self.SUDO_PASSWORD(password))

    def pipe(self, add_pipe: bool = True) -> 'Command':
        """
        :param add_pipe: adds '|' before all to commands stacking, redirecting
        :return: self
        """
        if add_pipe:
            self.append(self.PIPE)
        return self

    def sudo(self, add_sudo: bool = True, std_in: bool = False, reset_timestamp: bool = False) -> 'Command':
        """
        adds sudo command
        :return: self
        """
        if add_sudo:
            self.append(self.SUDO)
            if std_in is True:
                self.append(self.STD_IN)
            if reset_timestamp is True:
                self.append(self.RESET_TIMESTAMP)
        return self

    def command(self, command: str = None) -> 'Command':
        if command is not None:
            self.append(command)
        elif self.COMMAND is not None:
            self.append(self.COMMAND)
        return self

    def append(self, command: str) -> 'Command':
        super().append(command)
        return self

    def extend(self, commands: List[str]):
        super().extend(commands)
        return self


class OptionEnumWithValue(NamedTuple("OptionEnumWithValue", [("enum", OptionEnum), ("value", str)])):
    # enum: OptionEnum  # python 3.6 notation
    # value: str        # python 3.6 notation

    def __call__(self) -> str:
        if self.value is not None:
            return "=".join([self.enum.option, "{value}".format(value=self.value)])
        else:
            return self.enum.option
