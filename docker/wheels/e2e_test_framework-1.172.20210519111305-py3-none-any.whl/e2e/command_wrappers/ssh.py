#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

from typing import Dict, List

from e2e import config
from .ssh_base import SshBase, SshOption


class Ssh(SshBase):
    SSH_COMMAND = "ssh"
    DO_NOT_EXECUTE_REMOTE_COMMAND = "-N"
    PORT_TO_CONNECT_TO_ON_REMOTE_HOST = "-p"
    PORT_FORWARD = "-L"
    BASH = "bash"
    BASH_COMMAND = "-c"

    def __init__(self, add_pipe: bool = False, add_sudo=False,
                 remote_username: str = None,
                 remote_password: str = None,
                 remote_host: str = None,
                 remote_port: str = None,
                 priv_key: str = None,
                 batch_mode: bool = False, quiet_mode: bool = False, tty: bool = False,
                 ssh_options: Dict[SshOption, str] = SshBase.SSH_DEFAULT_OPTIONS_VALUES,
                 remote_command=None):
        """
        Builds ssh command line as a list of strings
        Args:
            add_pipe: adds a pipe before command
            add_sudo: adds sudo before command
            remote_username: user name
            remote_password: user password
            remote_host: host to connect to
            remote_port: port to connect to
            priv_key: private ssh key
            batch_mode: see man scp
            quiet_mode: see man scp
            ssh_options: see: man scp
        """
        if add_sudo is True:
            ssh_command = Ssh(
                add_pipe=add_pipe, add_sudo=False,
                remote_username=remote_username, remote_password=remote_password,
                remote_host=remote_host, remote_port=remote_port,
                priv_key=priv_key, batch_mode=batch_mode, quiet_mode=quiet_mode, tty=tty, ssh_options=ssh_options,
                remote_command=remote_command)
            self.sudo()
            self.bash("'eval `ssh-agent -s`; ssh-add /data/ssh/ssh.key; {ssh_command}'"
                      .format(ssh_command=ssh_command))
        else:
            super().__init__(add_pipe, add_sudo,
                             remote_username, remote_password, remote_host, remote_port,
                             priv_key, batch_mode, quiet_mode, ssh_options, tty)

            self.add_user_at_host()
            self.remote_command(remote_command=remote_command)

    def verbose(self):
        if config.verbose_ssh:
            self.append("-vvv")

    def add_user_at_host(self):
        self.append(self.user_at_host)

    def not_execute_remote_command(self) -> 'Ssh':
        self.append(self.DO_NOT_EXECUTE_REMOTE_COMMAND)
        return self

    def port_to_connect_to_on_remote_host(self, port: int = None) -> 'Ssh':
        if port is not None:
            self.append(self.PORT_TO_CONNECT_TO_ON_REMOTE_HOST)
            self.append(str(port))
        return self

    def bash(self, command: str = None) -> 'Ssh':
        """
        adds bash -c 'command'
        :return: self
        """
        if command is not None:
            self.append(self.BASH)
            self.append(self.BASH_COMMAND)
            self.append(command)
        return self

    def remote_command(self, remote_command: List[str] = None):
        if remote_command:
            self.extend(remote_command)
