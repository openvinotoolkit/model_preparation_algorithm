#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import copy
from abc import abstractmethod
from collections import OrderedDict
from enum import Enum
from typing import List, Dict

from .command_wrappers import Command
from .ssh_pass import SshPass


class SshOption(Enum):
    USER_KNOWN_HOSTS_FILE = "UserKnownHostsFile"
    STRICT_HOST_KEY_CHECKING = "StrictHostKeyChecking"
    GSS_API_AUTHENTICATION = "GSSAPIAuthentication"
    SERVER_ALIVE_INTERVAL = "ServerAliveInterval"
    LOG_LEVEL = "LogLevel"
    BATCH_MODE = "BatchMode"

    def with_value(self, option_value: str):
        return "{option_name}={option_value}".format(option_name=self.value, option_value=option_value)


class SshBase(Command):

    SSH_COMMAND = NotImplemented
    IDENTITY_FILE = "-i"
    TTY = "-t"
    QUIET_MODE = "-q"
    PORT = "-p"
    SSH_DEFAULT_OPTIONS_VALUES = OrderedDict([
        (SshOption.USER_KNOWN_HOSTS_FILE, "/dev/null"),
        (SshOption.STRICT_HOST_KEY_CHECKING, "no"),
        (SshOption.GSS_API_AUTHENTICATION, "no"),
        (SshOption.SERVER_ALIVE_INTERVAL, "30"),
        (SshOption.LOG_LEVEL, "error"),
    ])

    def __init__(self, add_pipe: bool = False, add_sudo: bool = False,
                 remote_username: str = None, remote_password: str = None,
                 remote_host: str = None, remote_port: str = None,
                 priv_key: str = None,
                 batch_mode: bool = False, quiet_mode: bool = False,
                 ssh_options: Dict[SshOption, str] = None, tty: bool = False):
        """Credentials and other options required to execute commands on a remote host

        Args:
          remote_username: name of the ssh user
          remote_password: password of the ssh user
          remote_host: remote host address
          remote_port: remote host port
          priv_key: path to private key file if exists
          batch_mode: see man scp
          quiet_mode: see man scp
          ssh_options: see man scp
        """
        super().__init__(add_pipe=add_pipe, add_sudo=add_sudo)
        self.remote_host = remote_host
        self.remote_port = remote_port
        self.remote_username = remote_username
        self.remote_password = remote_password
        self.private_key = priv_key
        options = self.SSH_DEFAULT_OPTIONS_VALUES if not ssh_options else ssh_options
        self.ssh_options = copy.copy(options)
        self.auth_options = []

        self.password(password=self.remote_password)
        self.ssh_command()
        self.batch_mode(batch_mode=batch_mode)
        self.quiet_mode(quiet_mode=quiet_mode)
        self.tty(tty=tty)
        self.priv_key(id_key_file_name=self.private_key)
        self.options(ssh_options=self.ssh_options)
        self.port(port=remote_port)
        self.verbose()

    @property
    def user_at_host(self) -> str:
        user_at_host = ""
        if self.remote_username not in [None, ""]:
            user_at_host += "{user}@".format(user=self.remote_username)
        user_at_host += "{host}".format(host=self.remote_host)
        return user_at_host

    def get_ssh_string(self) -> List[str]:
        return self

    def port(self, port: str = None):
        if port is not None:
            self.append(self.PORT)
            self.append(port)
        return self

    def priv_key(self, id_key_file_name: str = None) -> 'SshBase':
        if id_key_file_name not in [None, ""]:
            self.append(self.IDENTITY_FILE)
            self.append(id_key_file_name)
            self.auth_options.append(self.IDENTITY_FILE)
            self.auth_options.append(id_key_file_name)
        return self

    def password(self, password: str = None) -> 'SshBase':
        if password not in [None, ""] and self.private_key in [None, ""]:
            self.extend(SshPass(password=password))
        return self

    def add_option(self, option: SshOption, value, where: list = None):
        where = where if where is not None else self
        if option is not None and value is not None:
            where.append("-o")
            where.append(option.with_value(value))
        return self

    def options(self, ssh_options: Dict[SshOption, str] = None) -> 'SshBase':
        options = copy.copy(self.SSH_DEFAULT_OPTIONS_VALUES) if not ssh_options else ssh_options
        for option, value in options.items():
            self.add_option(option, value)
            self.add_option(option, value, where=self.auth_options)
        return self

    def ssh_command(self) -> 'SshBase':
        self.append(self.SSH_COMMAND)
        return self

    def tty(self, tty: bool = False) -> 'SshBase':
        if tty:
            self.append(self.TTY)
            self.auth_options.append(self.TTY)
        return self

    def quiet_mode(self, quiet_mode: bool = True) -> 'SshBase':
        if quiet_mode is True:
            self.append(self.QUIET_MODE)
            self.auth_options.append(self.QUIET_MODE)
        return self

    def batch_mode(self, batch_mode=False,
                   ssh_options: Dict[SshOption, str] = None) -> 'SshBase':
        options = copy.copy(self.SSH_DEFAULT_OPTIONS_VALUES) if not ssh_options else ssh_options
        if batch_mode is True:
            options[SshOption.BATCH_MODE] = "yes"
        return self

    @abstractmethod
    def verbose(self) -> 'SshBase':
        raise NotImplemented
