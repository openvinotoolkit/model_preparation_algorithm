#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

from logging.handlers import SysLogHandler
from typing import Union, List, Set, Tuple

from e2e.command_wrappers import OptionEnum, Command


class JournalCtl(Command):
    """
    List of strings representation of selected options.
    """

    class Output(OptionEnum):
        SHORT = "short"
        SHORT_ISO = "short-iso"
        SHORT_PRECISE = "short-precise"
        SHORT_MONOTONIC = "short-monotonic"
        SHORT_UNIX = "short-unix"
        VERBOSE = "verbose"
        EXPORT = "export"
        JSON = "json"
        JSON_PRETTY = "json-pretty"
        JSON_SSE = "json-sse"
        CAT = "cat"

    class Priority(OptionEnum):
        EMERG = "emerg", SysLogHandler.LOG_EMERG
        PANIC = "panic", SysLogHandler.LOG_EMERG  # deprecated
        ALERT = "alert", SysLogHandler.LOG_ALERT
        CRIT = "crit", SysLogHandler.LOG_CRIT
        ERR = "err", SysLogHandler.LOG_ERR
        ERROR = "err", SysLogHandler.LOG_ERR  # deprecated
        WARNING = "warning", SysLogHandler.LOG_WARNING
        WARN = "warn", SysLogHandler.LOG_WARNING  # deprecated
        NOTICE = "notice", SysLogHandler.LOG_NOTICE
        INFO = "info", SysLogHandler.LOG_INFO
        DEBUG = "debug", SysLogHandler.LOG_DEBUG

    JOURNAL_CTL = "journalctl"
    UNIT = "--unit={unit}".format
    PRIORITY_UP_TO = "--priority={up_to}".format
    PRIORITY_SINGLE = "--priority={single}..{single}".format
    PRIORITY_FROM_TO = "--priority={FROM}..{TO}".format
    OUTPUT = "--output={output}".format
    SINCE = "--since='{date}'".format
    UNTIL = "--until='{date}'".format
    REVERSE = "--reverse"
    UTC = "--utc"
    LINES = "--lines={lines}".format
    BOOT = "--boot={boot}".format

    def __init__(self, add_pipe=False, add_sudo=True,
                 unit: Union[List[str], Set[str], Tuple[str], str] = None,
                 priority: Union[Priority, Tuple[Priority], Tuple[Priority, Priority]] = None,
                 output: Output = None,
                 since: str = None, until: str = None, utc: bool = False,
                 reverse: bool = False, lines=0, boot: int = None):
        """
        Generate journal_ctl command as a list of command line options.

        :param add_pipe: adds '|' before all to commands stacking, redirecting
        :param unit: name of unit to get logs for
        :param priority: sets priority of logs to show (log level),
            <ul>
                <li>single value: show only messages with log level up to selected value</li>
                <li>one element tuple, show only messages with selected log level.</li>
                <li>two elements tuple, show only messages from first selected value to second selected value.</li>
            </ul>
        :param output: select output format (cat, short, verbose, etc).
        :param since: select since date for logs
        :param until: select until date for logs
        :param reverse: reverse log order (newest on the top).
        :param boot: Show messages from a specific boot
        """
        if unit is None:
            unit = []
        super().__init__(add_pipe=add_pipe, add_sudo=add_sudo)
        self.journal_ctl()
        self.priority(priority)
        self.unit(unit)
        self.output(output)
        self.since(since)
        self.until(until)
        self.reverse(reverse)
        self.utc(utc)
        self.lines(lines)
        self.boot(boot)

    def journal_ctl(self) -> 'JournalCtl':
        """
        adds journal_ctl command
        :return: self
        """
        self.append(self.JOURNAL_CTL)
        return self

    def unit(self, unit: Union[List[str], Set[str], Tuple[str, ...], str] = None) -> 'JournalCtl':
        """
        :param unit: name of unit to get logs for
        :return: self
        """
        if unit is None:
            return self
        for _unit in unit if isinstance(unit, (list, set, tuple)) else [unit] if unit and isinstance(unit, str) else []:
            self.append(self.UNIT(unit=_unit))
        return self

    def priority(self, priority: Union[Priority, Tuple[Priority], Tuple[Priority, Priority]] = None) -> 'JournalCtl':
        """
        :param priority: sets priority of logs to show (log level),
            <ul>
                <li>single value: show only messages with log level up to selected value</li>
                <li>one element tuple, show only messages with selected log level.</li>
                <li>two elements tuple, show only messages from first selected value to second selected value.</li>
            </ul>
        :return: self
        """
        if priority is not None:
            if isinstance(priority, tuple):
                if len(priority) == 2:
                    self.append(self.PRIORITY_FROM_TO(FROM=priority[0].get_value_name(),
                                                      TO=priority[1].get_value_name()))
                elif len(priority) == 1:
                    self.append(self.PRIORITY_SINGLE(single=priority[0].get_value_name()))
                else:
                    raise RuntimeError("Not allowed number of elements in tuple.")
            elif isinstance(priority, JournalCtl.Priority):
                self.append(self.PRIORITY_UP_TO(up_to=priority.get_value_name()))
        return self

    def output(self, output: Output = None) -> 'JournalCtl':
        """
        :param output: select output format (cat, short, verbose, etc).
        :return: self
        """
        if output is not None:
            self.append(self.OUTPUT(output=output.value))
        return self

    def reverse(self, reverse: bool = False) -> 'JournalCtl':
        """
        :param reverse: reverse log order (newest on the top).
        :return: self
        """
        if reverse:
            self.append(self.REVERSE)
        return self

    def since(self, since: str = None) -> 'JournalCtl':
        """
        :param since: select since date for logs
        :return:
        """
        if since:
            self.append(self.SINCE(date=since))
        return self

    def until(self, until: str = None) -> 'JournalCtl':
        """
        :param until: select until date for logs
        :return:
        """
        if until:
            self.append(self.UNTIL(date=until))
        return self

    def utc(self, enable: bool = False) -> 'JournalCtl':
        if enable:
            self.append(self.UTC)
        return self

    def lines(self, lines: int) -> 'JournalCtl':
        if lines > 0:
            self.append(self.LINES(lines=lines))
        return self

    def boot(self, boot: int) -> 'JournalCtl':
        if boot is not None:
            self.append(self.BOOT(boot=boot))
        return self
