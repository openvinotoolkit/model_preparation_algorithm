#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

import argparse
import json

from datetime import datetime, timedelta

from e2e.current_os_info import CurrentOsInfo
from e2e.environment_info import EnvironmentInfo
from e2e.markers import MarkRunType
from e2e.mongo_reporter.base_reporter import TestStatus
from e2e.mongo_reporter.run_reporter import RunReporter
from e2e import config


error_suffix = "{}: {} error"
date_format = "%Y-%m-%d %H:%M:%S.%f"
default_docstring = "Test description is not available"
default_priority = "high"
result = {TestStatus.RESULT_PASS: 0,
          TestStatus.RESULT_FAIL: 0,
          TestStatus.RESULT_SKIPPED: 0,
          TestStatus.RESULT_UNKNOWN: 0,
          TestStatus.RESULT_NOT_IMPLEMENTED: 0,
          TestStatus.RESULT_NEXT_VERSION: 0}


def get_status(test_result: dict):
    not_implemented_str = "not implemented yet"
    if test_result["outcome"] == "skipped":
        if test_result["setup"].get("longrepr", None):
            if not_implemented_str in test_result["setup"]["longrepr"]:
                return TestStatus.RESULT_NOT_IMPLEMENTED
            else:
                return TestStatus.RESULT_SKIPPED
        else:
            return TestStatus.RESULT_SKIPPED
    if test_result["outcome"] == "failed":
        return TestStatus.RESULT_FAIL
    if test_result["outcome"] == "error":
        return TestStatus.RESULT_FAIL
    if test_result["outcome"] == "passed":
        return TestStatus.RESULT_PASS


def parse_date(date_to_parse, utc: bool = False):
    if utc:
        date_to_parse = str(datetime.utcfromtimestamp(date_to_parse / 1000))
    parsed_date = datetime.strptime(str(date_to_parse), date_format)
    return parsed_date


def parse_duration(duration):
    return timedelta(seconds=duration)


def get_run_end_date(raw_tests_results, start_date):
    if raw_tests_results["report"]["summary"].get("duration", None):
        duration = parse_duration(raw_tests_results["report"]["summary"]["duration"])
        return start_date + duration
    else:
        return parse_date(raw_tests_results["testResults"][-1]["endTime"], utc=True)


def parse_test_run(raw_tests_results, utc: bool = False):
    parsed_results = dict()

    start_date = parse_date(raw_tests_results["report"]["created_at"], utc)
    parsed_results["start_date"] = start_date
    parsed_results["end_date"] = get_run_end_date(raw_tests_results, start_date)
    parsed_results["test_count"] = raw_tests_results["report"]["summary"].get("num_tests", 0)
    parsed_results["total_test_count"] = raw_tests_results["report"]["summary"].get("num_tests", 0)
    parsed_results["finished"] = True

    return parsed_results


def parse_stacktrace(raw_test_result, test_parsed, key):
    if raw_test_result[key].get("longrepr", None):
        test_parsed["stacktrace"] = raw_test_result[key]["longrepr"]
        if key in ["setup", "teardown"]:
            test_parsed["name"] = error_suffix.format(test_parsed["name"], key)
    return test_parsed


def get_test_end_date(raw_test_result, start_date):
    if raw_test_result.get("duration", None):
        delta = timedelta(seconds=raw_test_result["duration"])
        return start_date + delta
    else:
        return parse_date(raw_test_result["endTime"], utc=True)


def get_duration_time(raw_test_result):
    if raw_test_result.get("duration", None):
        return raw_test_result["duration"]
    else:
        return (raw_test_result["endTime"] - raw_test_result["startTime"]) / 1000


def parse_test_results(raw_test_result: dict, reporter: RunReporter, start_date: datetime,
                       test_type: MarkRunType, components_list: list):
    test_parsed = dict()
    test_parsed["name"] = raw_test_result["name"]
    test_parsed["components"] = components_list
    test_parsed["reqids"] = []
    test_parsed["docstring"] = default_docstring
    test_parsed["defects"] = ""
    test_parsed["priority"] = default_priority
    test_parsed["run_id"] = reporter._document_id
    test_parsed["stacktrace"] = ""
    test_parsed["tags"] = ""
    test_parsed["test_type"] = MarkRunType.test_mark_to_test_run_type(test_type_mark=test_type)
    test_parsed["start_date"] = start_date
    test_parsed["end_date"] = get_test_end_date(raw_test_result, start_date)
    test_parsed["duration"] = get_duration_time(raw_test_result)
    test_parsed["status"] = get_status(raw_test_result)
    test_parsed["logs"] = ""
    if test_parsed["status"] == TestStatus.RESULT_FAIL:
        if raw_test_result.get("call", None):
            if raw_test_result["call"].get("log", None):
                test_parsed["logs"] = raw_test_result["call"]["log"]
        if raw_test_result.get("setup", None):
            test_parsed = parse_stacktrace(raw_test_result, test_parsed, "setup")
        if raw_test_result.get("teardown", None):
            test_parsed = parse_stacktrace(raw_test_result, test_parsed, "teardown")
        if raw_test_result.get("call", None):
            test_parsed = parse_stacktrace(raw_test_result, test_parsed, "call")
        if raw_test_result.get("failureMessages", None):
            test_parsed["logs"] = raw_test_result["failureMessages"][0]
    test_parsed["order"] = raw_test_result.get("run_index", 0)
    return test_parsed


def get_reporter():
    reporter = RunReporter(document_id=config.test_run_id, environment=EnvironmentInfo.get_environment_name())
    return reporter


def save_to_database(parsed_results: dict, reporter: RunReporter, test_type: MarkRunType, components_list: list):
    reporter.report_test_type(test_type_mark=test_type)
    reporter.report_test_build_number(build_number=config.test_session_build_number)
    reporter.report_env_numbers(build_number=EnvironmentInfo.get_build_number(),
                                version_number=EnvironmentInfo.get_version_number())
    reporter.report_components(components_list, save=True)

    reporter._mongo_run_document["start_date"] = parsed_results["start_date"]
    reporter._mongo_run_document["end_date"] = parsed_results["end_date"]
    reporter._mongo_run_document["result"] = result
    reporter._mongo_run_document["total_test_count"] = parsed_results["total_test_count"]
    reporter._mongo_run_document["system"] = CurrentOsInfo.get_os_distname()
    reporter._mongo_run_document["finished"] = parsed_results["finished"]
    reporter._save_test_collection()
    return reporter._mongo_run_document


def update_test_results(document: dict, reporter: RunReporter):
    reporter.result_reporter.mongo_run_document = document
    reporter.result_reporter.document_id = None
    reporter.result_reporter._save_test_collection()
    reporter.update_run_status(document["status"], 1)


def get_script_results_arg():
    parser = argparse.ArgumentParser()
    parser.add_argument('--results', type=str, default="", help='json file with tests results')
    return parser.parse_args()


def get_results_from_args(args):
    with open(args.results) as json_file:
        return json.load(json_file)
