#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

from typing import List

from e2e.exceptions import CommandExecutionException
from e2e.ssh_lib.jump_client import JumpClient
from e2e.process_utils import Process
from e2e.logger import get_logger


class RemoteLinuxProcess(Process):
    """ Class represents a Linux process, which can be executed on remote machine and then
     its outcome returned to the local caller."""

    _logger = get_logger(__name__)

    def __init__(self, ssh_client: JumpClient):
        self._ssh_client = ssh_client

    def execute(self, args: List[str]) -> (int, List[str], List[str]):
        """Executes a process specified by the args parameter.

                :param args: Command line arguments to execute.
                :return: (code, stdout, stderr) tuple with process execution results.
                """
        try:
            self._logger.info("Execute remote linux process")
            out, code = self._ssh_client.execute_ssh_command(["sudo"] + args, get_shell_data=True)
            self._logger.info('Remote process finished: code=%d', code)
            return code, out, []
        except CommandExecutionException:
            return -1, [], []


class RemoteLinuxProcessWithCredentials(RemoteLinuxProcess):

    def __init__(self, ssh_client: JumpClient):
        super().__init__(ssh_client)
