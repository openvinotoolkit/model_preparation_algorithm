#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import pprint
from typing import List

import os
import shutil
from collections import OrderedDict
from pathlib import WindowsPath

from abc import ABCMeta, abstractmethod

from e2e import command, config
from e2e.command_wrappers import mount as cmd
from e2e.constants.supported_oses import OS
from e2e.logger import get_logger
from .e2e_object_superclass import E2EObjectSuperclass

logger = get_logger(__name__)


class MountCtxMgr(metaclass=ABCMeta):
    @abstractmethod
    def __enter__(self):
        pass

    @abstractmethod
    def __exit__(self, exc_type, exc_val, exc_tb):
        pass

    @abstractmethod
    def __add__(self, other: str) -> 'MountedPath':
        pass

    @property
    @abstractmethod
    def mount(self) -> 'Mount':
        pass

    @property
    @abstractmethod
    def local_path(self) -> str:
        pass

    @property
    @abstractmethod
    def remote_host(self) -> str:
        pass


class Mount(E2EObjectSuperclass, MountCtxMgr):
    _COMPARABLE_ATTRIBUTES = ["local_path", "remote_host"]

    LOCAL = "Local"
    REMOTE = "Remote"
    COMMAND = "Command"
    MOUNTED = "Mounted"
    PERMISSION_DENIED = NotImplemented
    PERMISSION_DENIED_CODE = NotImplemented

    @classmethod
    def get_class(cls):
        if config.os_name == OS.Linux:
            return MountLinux
        elif config.os_name == OS.Darwin:
            return MountDarwin
        elif config.os_name == OS.Windows:
            return MountWindows
        else:
            raise RuntimeError("not supported os")

    def __new__(cls, local_path, remote_host, mount_command: cmd.Mount = None, is_mounted: bool = False):
        return super().__new__(cls.get_class())

    def __init__(self, local_path, remote_host, mount_command: cmd.Mount = None, is_mounted: bool = False):
        super().__init__(object_id=local_path)
        self._remote_host = remote_host
        self._local_path = local_path
        self.command = mount_command
        self.is_mounted = is_mounted

    @property
    def mount(self):
        return self

    @property
    def local_path(self) -> str:
        return self._local_path if self._local_path.endswith(os.sep) else self._local_path + os.sep

    @property
    def remote_host(self) -> str:
        return self._remote_host

    def __str__(self):
        return self.local_path

    def __repr__(self):
        return "{local} -> {remote} ({mounted})".format(local=self.id, remote=self.remote_host,
                                                        mounted="mounted" if self.is_mounted else "not mounted")

    def __enter__(self):
        if self.is_mounted is False and self.command is not None:
            self.mounts()
        return self.local_path

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.is_mounted is True and self.command is not None:
            self.umounts()

    def __add__(self, other: str) -> 'MountedPath':
        if other is not None and isinstance(other, str):
            return MountedPath(self, other)
        return NotImplemented

    def mounts(self):
        output, ret_code, _ = command.run(self.command, shell=True)
        self.is_mounted = True
        return self

    def umounts(self, **kwargs):
        umount_command = cmd.Mount.umount(self._local_path, **kwargs)
        output, ret_code, _ = command.run(umount_command, shell=True)
        self.is_mounted = False
        return self

    @classmethod
    def list(cls, **kwargs) -> List['Mount']:
        """Lists samba shares"""
        list_command = cmd.Mount.list(**kwargs)
        mounts, _, _ = command.run(list_command, shell=True)
        mounts = cls.get_class().list_from_response(mounts)
        return mounts

    @classmethod
    def create(cls, remote_host, samba_share, local_dir, username, smb_password, context, domain=None, **kwargs):
        """Will mount samba share to local dir"""
        mount_command = cmd.Mount.mount(remote_host=remote_host, samba_share=samba_share, local_dir=local_dir,
                                        username=username, password=smb_password, domain=domain, **kwargs)
        mount = cls.from_response({cls.LOCAL: local_dir, cls.REMOTE: os.path.join(remote_host, samba_share),
                                   cls.COMMAND: mount_command, cls.MOUNTED: False})
        context.test_objects.append(mount)
        return mount

    def delete(self, remove_dir: bool = True, **kwargs):
        if not self._is_deleted:
            if self.is_mounted:
                self.umounts(**kwargs)
            if remove_dir is True:
                shutil.rmtree(path=self.id, ignore_errors=True)
            self._set_deleted(True)

    @classmethod
    def from_response(cls, rsp: dict):
        return cls(local_path=rsp.get(cls.LOCAL, None),
                   remote_host=rsp.get(cls.REMOTE, None),
                   mount_command=rsp.get(cls.COMMAND, None),
                   is_mounted=rsp.get(cls.MOUNTED, cls.check_if_is_mounted(rsp)))

    @classmethod
    def check_if_is_mounted(cls, rsp: dict):
        return True

    @classmethod
    def parse_mount_output(cls, rsp):
        raise NotImplementedError

    @classmethod
    def list_from_response(cls, rsp):
        return super().list_from_response(cls.parse_mount_output(rsp))


class MountPosix(Mount):
    @classmethod
    def parse_mount_output(cls, output: List[str]):
        table = []
        for line in output:
            dev, _, mount_point_details = line.partition(" on ")
            mount_point, _, type_details = mount_point_details.partition(" ")
            row = {cls.LOCAL: mount_point, cls.REMOTE: dev, cls.MOUNTED: True}
            table.append(row)
        return table


class MountLinux(MountPosix):

    PERMISSION_DENIED_CODE = 32
    PERMISSION_DENIED = "Permission denied"


class MountDarwin(MountPosix):

    PERMISSION_DENIED_CODE = 77
    PERMISSION_DENIED = "Authentication error"


class MountWindows(Mount):
    NETWORK_TYPES_TO_SKIP = ["Microsoft Terminal Services", "NFS Network"]
    STATUS = "Status"
    NETWORK = "Network"
    DISCONNECTED = "Disconnected"
    UNAVAILABLE = "Unavailable"
    OK = "OK"
    PERMISSION_DENIED_CODE = 2
    PERMISSION_DENIED = "The specified network password is not correct."

    @classmethod
    def check_if_is_mounted(cls, rsp: dict):
        status = rsp.get(cls.STATUS, None)
        if status in [None, "", cls.OK]:
            return True
        elif isinstance(status, str) and status.strip() == "":
            logger.warning("net use status is non empty white space")
            return True
        elif status in [cls.DISCONNECTED, cls.UNAVAILABLE]:
            return False
        else:
            logger.warning("not supported net use status value: {}".format(status))
            return None

    @classmethod
    def parse_mount_output(cls, output: List[str]):
        table = {"header": {}, "body": []}
        output_iterator = iter(output)
        try:
            line = next(output_iterator)
            while True:
                if "The command completed successfully." in line:
                    break
                elif "New connections will" in line or\
                        "" == line or\
                        "-------------------------------------------------------------------------------" in line:
                    pass
                elif cls.STATUS in line and cls.LOCAL in line and cls.REMOTE in line and cls.NETWORK in line:
                    headers = line.split()  # type: List[str]
                    start = 0
                    for index, header in enumerate(headers[1:], 1):
                        end = line.find(header, start)
                        table["header"][headers[index - 1]] = {
                            "start": start,
                            "end": end,
                            "length": end - start,
                        }
                        start = end
                    else:
                        end = len(line)
                        table["header"][headers[len(headers) - 1]] = {
                            "start": start,
                            "end": end,
                            "length": end - start,
                        }
                else:
                    row = {}
                    first_line = line
                    second_line = line = next(output_iterator)
                    name = cls.NETWORK
                    column = table["header"].get(name, None)
                    assert column is not None,\
                        "Lack of {} column in 'net use' output!!!\n{}".format(name, "\n".join(output))
                    if second_line == "" or second_line[:column["start"] - 1].strip() != "":
                        two_line_mount_entry = False
                        row[name] = first_line[column["start"] - 1:column["end"]].strip()
                    else:
                        two_line_mount_entry = True
                        row[name] = second_line.strip()
                    for name in [cls.STATUS, cls.LOCAL, cls.REMOTE]:
                        column = table["header"].get(name, None)
                        assert column is not None,\
                            "Lack of {} column in 'net use' output!!!\n{}".format(name, "\n".join(output))
                        if name in [cls.STATUS, cls.LOCAL]:
                            row[name] = first_line[column["start"]:column["end"]].strip()
                        elif name == cls.REMOTE:
                            # longer Remote column value makes two line mount entry.
                            if two_line_mount_entry:
                                row[name] = first_line[column["start"]:].strip()
                            else:
                                row[name] = first_line[column["start"]:column["end"]].strip()
                    if row.get(cls.NETWORK, "") not in cls.NETWORK_TYPES_TO_SKIP:
                        table["body"].append(row)
                    if two_line_mount_entry is False:
                        continue  # line already moved to next value
                line = next(output_iterator)
        except StopIteration:
            pass
        return table["body"]


class DriveLetters:
    INSTANCE = None
    DRIVES_LETTERS = OrderedDict(("{letter}:".format(letter=chr(x)), False) for x in range(ord('a'), ord('z') + 1))

    def check_if_windows_drive_letter_is_occupied(self, letter, try_umount: bool = True) -> bool:
        try:
            return WindowsPath("{letter}\\".format(letter=letter)).exists()
        except WindowsError as err:
            if err.winerror == 1326 and try_umount is True:
                occupied = Mount(local_path=letter, remote_host=None)
                occupied.delete()
                return self.check_if_windows_drive_letter_is_occupied(letter, try_umount=False)
            else:
                logger.warning("Exception occurred while checking for availability of drive {}:\n".format(letter),
                               exc_info=err)
            return True
        except OSError as err:
            logger.warning("Other OS error occurred.", exc_info=err)
            return True

    def __new__(cls):
        if cls.INSTANCE is None:
            cls.INSTANCE = object.__new__(cls)
        return cls.INSTANCE

    def get(self):
        logger.debug("DRIVES_LETTERS\n{}".format(pprint.pformat(self.DRIVES_LETTERS)))
        for letter, occupied in reversed(self.DRIVES_LETTERS.items()):
            if occupied is False:
                occupied = self.DRIVES_LETTERS[letter] = self.check_if_windows_drive_letter_is_occupied(letter)
                if occupied is True:
                    continue
                logger.debug("returning: {}".format(letter))
                return letter
        return None

    def free(self, letter: str):
        self.DRIVES_LETTERS[letter] = False


class MountedPath(MountCtxMgr):
    """
    Helper class to produce context manager working like Mount class but including access to paths based on it.
    """
    def __init__(self, mount: MountCtxMgr, *path: str):
        self._mount = mount.mount
        if isinstance(mount, MountedPath):
            path = (mount._path, *path)
        self._path = os.path.join(*path)

    @property
    def mount(self):
        return self._mount

    @property
    def path(self):
        return os.path.join(self.local_path, self._path)

    def __str__(self):
        return self.path

    def __repr__(self):
        return "{path!s}@{mount!r}".format(path=self._path, mount=self.mount)

    def __enter__(self):
        self.mount.__enter__()
        return self.path

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.mount.__exit__(exc_type, exc_val, exc_tb)

    def __add__(self, other: str) -> 'MountedPath':
        if other is not None and isinstance(other, str):
            return MountedPath(self.mount, os.path.join(self._path, other))
        return NotImplemented

    @property
    def local_path(self) -> str:
        return self.mount.local_path

    @property
    def remote_host(self) -> str:
        return self.mount.remote_host
