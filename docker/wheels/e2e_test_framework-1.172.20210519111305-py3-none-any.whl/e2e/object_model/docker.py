#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
from datetime import datetime
import pprint
import time
from typing import Union, List, Callable, Any, Tuple
from typing_extensions import TypedDict

import docker
from docker.models.containers import Container
from e2e.config import artifacts_dir, test_build_log_url
from e2e.context import Context
from e2e.files.file_base import FileBase
from io import BytesIO
from retry.api import retry_call

from e2e.helpers import SingletonMeta
from e2e.logger import get_logger
from e2e.object_model.e2e_object_superclass import E2EObjectSuperclass
from e2e.test_names import generate_test_object_name

CONTAINER_STATUS_RUNNING = "running"
CONTAINER_STATUS_EXITED = "exited"
CONTAINER_STATUS_DEAD = "dead"
CONTAINER_STATUS_CREATED = "created"
CONTAINER_STATUS_RESTARTING = "restarting"

logger = get_logger(__name__)


class DockerClient(docker.DockerClient, metaclass=SingletonMeta):

    def build(self, dockerfile: str, build_args, nocache: bool = True, **kwargs) -> tuple:
        logs = []
        with open(dockerfile, 'r') as file:
            data = file.read()
        file_obj = BytesIO(data.encode('utf-8'))
        image, generator = self.images.build(fileobj=file_obj, nocache=nocache, buildargs=build_args, **kwargs)
        while True:
            try:
                output = generator.__next__()
                logs.append(str(output.values()))
            except StopIteration:
                break

        return image, logs

    def push(self, repository, tag=None, **kwargs):
        logs = self.images.push(repository=repository, tag=tag, **kwargs).split("\n")
        for line in logs:
            assert "requested access to the resource is denied" not in line, \
                "Unauthorized to push docker image: {}".format(line)
            assert "error" not in line, "Failed to push docker image: {}".format(line)
        return logs

    def pull(self, repository, tag):
        return self.images.pull(repository=repository, tag=tag)

    def remove(self, image_id: str, **kwargs):
        return self.images.remove(image=image_id, **kwargs)

    def get(self, container_id_or_name) -> Container:
        container = self.containers.get(container_id_or_name)
        return container

    def create(self, image, command=None, **kwargs) -> Container:
        container = self.containers.create(image, command, **kwargs)
        return container

    def run(self, image, command=None, stdout=True, stderr=False, remove=False, **kwargs) -> Union[Container, None]:
        container = self.containers.run(image, command, stdout, stderr, remove, **kwargs)
        return container

    def list_containers(self, all_containers=False, before=None, filters=None, limit=-1, since=None) -> List[Container]:
        return self.containers.list(all_containers, before, filters, limit, since)


class Limits(TypedDict):
    cpu_period: int
    cpu_quota: int
    cpu_shares: int
    cpuset_cpus: str
    kernel_memory: Union[int, str]
    mem_limit: Union[int, str]
    mem_reservation: Union[int, str]
    mem_swappiness: int
    memswap_limit: Union[int, str]
    oom_kill_disable: bool


class DockerContainer(E2EObjectSuperclass):
    _COMPARABLE_ATTRIBUTES = ["name"]
    COMMON_RETRY = {"tries": 30, "delay": 2}
    NOT_ON_LIST_RETRY = {"tries": 10, "delay": 2}
    GETTING_LOGS_RETRY = COMMON_RETRY
    GETTING_STATUS_RETRY = COMMON_RETRY

    client = DockerClient()

    def __init__(self, container: Container, command=None,
                 detach: bool = True, ports: dict = None, volumes: dict = None, devices: List[type(str)] = None,
                 limits: Limits = None, **kwargs):
        self.kwargs = kwargs
        self.container = container
        self.image = self.container.image
        self.name = self.container.name
        self.command = command
        self.detach = detach
        self.ports = ports
        self.volumes = volumes
        self.limits = limits
        self.devices = devices
        super().__init__(object_id=self.name)

    def __eq__(self, other):
        if isinstance(other, type(self)):
            return super().__eq__(other)
        elif isinstance(other, str):
            return self.name == other
        else:
            logger.warning("Unexpected type of item: {}".format(type(other)))
            return False

    @classmethod
    def run(cls, context: Context, image, command=None, stdout=True, stderr=False, remove=False,
            name: str = None, detach: bool = True, ports: dict = None, volumes: dict = None,
            devices: List[type(str)] = None, limits: Limits = None,
            **kwargs):
        logger.info("Running container with:\n image: {}\n command: {}\n volumes: {}"
                    .format(image, command, volumes))
        if limits is not None:
            kwargs.update(limits)
        container = cls.client.run(image, command,
                                   stdout=stdout, stderr=stderr, remove=remove,
                                   name=cls.container_name(name),
                                   detach=detach,
                                   ports=ports,
                                   volumes=volumes,
                                   devices=devices,
                                   **kwargs)
        instance = cls(container, command,
                       detach=detach,
                       ports=ports,
                       volumes=volumes,
                       devices=devices,
                       limits=limits,
                       **kwargs)
        context.test_objects.append(instance)
        return instance

    @classmethod
    def create(cls, context: Context, image, command=None,
               name: str = None, detach: bool = True, ports: dict = None, volumes: dict = None,
               devices: List[type(str)] = None, limits: Limits = None,
               **kwargs):
        logger.info("Creating container with:\n image: {}\n command: {}\n volumes: {}"
                    .format(image, command, volumes))
        if limits is not None:
            kwargs.update(limits)
        container = cls.client.create(image, command,
                                      name=cls.container_name(name),
                                      detach=detach,
                                      ports=ports,
                                      volumes=volumes,
                                      devices=devices,
                                      **kwargs)
        instance = cls(container, command,
                       detach=detach,
                       ports=ports,
                       volumes=volumes,
                       devices=devices,
                       limits=limits,
                       **kwargs)
        context.test_objects.append(instance)
        return instance

    @classmethod
    def get(cls, container_id_or_name) -> Union['DockerContainer', None]:
        container = cls.client.get(container_id_or_name)  # type: Container
        return cls.from_response(container)

    @classmethod
    def list(cls, all_containers=False, before=None, filters=None, limit=-1, since=None) -> List['DockerContainer']:
        container_list = cls.client.list_containers(all_containers,
                                                    before, filters, limit, since)  # type: List[Container]
        return cls.list_from_response(container_list)

    @classmethod
    def from_response(cls, rsp: Container):
        return cls(container=rsp)

    def restart(self, stdout=True, stderr=False, remove=False, **kwargs):
        if len(kwargs):
            self.kwargs.update(kwargs)
        self.delete()
        self.container = self.client.run(self.image, self.command,
                                         stdout=stdout, stderr=stderr, remove=remove,
                                         name=self.name,
                                         detach=self.detach,
                                         ports=self.ports,
                                         volumes=self.volumes,
                                         **self.kwargs)

    @classmethod
    def container_name(cls, container_name: str = None):
        return generate_test_object_name() if container_name is None else container_name

    @classmethod
    def volume(cls, external_path: str, internal_path: str, mode: str = 'ro', volumes: dict = None):
        if not isinstance(volumes, dict):
            volumes = dict()
        volumes[external_path] = {'bind': internal_path, 'mode': mode}
        return volumes

    def start_container(self):
        assert self.container is not None, "Lack of container {} to start (is None)\nContainers found:\n{}"\
            .format(self.name, repr(self.client.list_containers(all_containers=True)))
        return self.container.start()

    def stop_container(self):
        assert self.container is not None, "Lack of container {} to stop (is None)\nContainers found:\n{}"\
            .format(self.name, repr(self.client.list_containers(all_containers=True)))
        return self.container.stop()

    def remove_container(self, ensure_deleted: bool = False):
        assert self.container is not None, "Lack of container {} to remove (is None)\nContainers found:\n{}"\
            .format(self.name, repr(self.client.list_containers(all_containers=True)))
        removed = self.container.remove()
        if ensure_deleted:
            self.ensure_not_on_list(self.name)
        return removed

    def delete(self, ensure_deleted: bool = False):
        self.stop_container()
        self.remove_container(ensure_deleted)

    def check_non_empty_logs(self, specific_str: str, acceptable_logs_length_trigger: int = 0, **kwargs):
        logs = self.get_logs(**kwargs)
        assert len(logs) > acceptable_logs_length_trigger,\
            "Logs list for {} should not be empty".format(self.name)
        assert specific_str in logs, "Specific string: {} not found in logs: {}".format(specific_str, logs)
        return logs

    def ensure_logs_contain_specific_str(self, specific_str: str, acceptable_logs_length_trigger: int = 0, **kwargs):
        args = [specific_str, acceptable_logs_length_trigger]
        link = "{}artifact/test_log/{}.log".format(test_build_log_url, self.name)
        logger.info("Log will be saved at: {}".format(link))
        return retry_call(self.check_non_empty_logs, fargs=args, fkwargs=kwargs,
                          exceptions=AssertionError, **self.GETTING_LOGS_RETRY)

    def silent_ensure_log_contains_specific_str(self, specific_str, timeout=60):
        self.silent_ensure_log_contains_specific_str_set([specific_str], timeout=timeout)

    def silent_ensure_log_contains_specific_str_set(self, specific_strings, timeout=60):
        string_detected = False

        def search_strings_in_log(specific_msg_set):
            log_generator = self.container.logs(stream=True, follow=False)
            while not all([x for x in specific_msg_set.values()]):
                try:
                    log_line = next(log_generator).decode()
                    for specific_msg in specific_msg_set:
                        if not specific_msg_set[specific_msg]:
                            specific_msg_set[specific_msg] = specific_msg in log_line
                except StopIteration:
                    break

        report = dict.fromkeys(specific_strings, False)
        start = datetime.now()
        while not string_detected and ((datetime.now() - start).total_seconds() <= timeout):
            search_strings_in_log(report)
            string_detected = all([x for x in report.values()])

        unable_to_detect_string = [msg for msg in report if not report[msg]]
        assert len(unable_to_detect_string) == 0, f'Unable to find string set: {unable_to_detect_string} in log: \n'\
                                                  f'{"=" * 50}\n{self.get_logs()}\n{"=" * 50}'

    @property
    def ports_mapping(self):
        self.container.reload()
        return self.container.ports

    def get_first_host_port_mapping(self, mapped_port):
        port_mapping = self.ports_mapping.get(mapped_port, [])
        first_host_port_mapping = next(iter(port_mapping), {})
        return first_host_port_mapping

    def get_host_port_mapping(self, mapped_port: str) -> Tuple[str, str]:
        """
        gets first host and port mapping
        :param mapped_port: str -> port mapping in format: "3456/tcp"
        :return: Tuple[str, str] -> (host_ip, host_port)
        """
        host = self.get_first_host_port_mapping(mapped_port)
        host_port = host.get("HostPort", None)
        host_ip = host.get("HostIP", None)
        assert host_port is not None, f"Cannot get mapped port for {mapped_port} in {self.ports}"
        return host_ip, host_port

    def update(self):
        self.container = self.client.containers.get(self.container.id)  # type: Container
        return self

    def get_status(self):
        self.update()
        return self.container.status

    def assert_status(self, status):
        current_status = self.get_status()
        assert current_status == status,\
            "Not expected status for container {} found. \n "\
            "Expected: {}, \n "\
            "received: {}".format(self.container.name, status, self.container.status)
        return True

    def ensure_status(self, status: str = CONTAINER_STATUS_RUNNING):
        container_status = {"status": status}
        return retry_call(self.assert_status, fkwargs=container_status,
                          exceptions=AssertionError, **self.GETTING_STATUS_RETRY)

    def get_logs(self, **kwargs) -> Union[bool, str]:
        assert self.container is not None, "Lack of container to get logs from (is None)"
        return self.container.logs(**kwargs).decode()

    def save_logs_to_file(self):
        logs = self.get_logs()
        file_name = "{filename}.log".format(filename=self.name)
        file_base = FileBase(file_name=file_name, dir_path=artifacts_dir)
        file_base.save_file(data=logs)

    @classmethod
    def check_not_on_list(cls, container: Union[str, 'DockerContainer'],
                          comparator: Callable[[Any, Any], bool] = None):
        current_list = cls.list()
        logger.debug("Searching for container with a name: {name}, among:\n{elem}\n"
                     .format(name=container if isinstance(container, str) else container.name,
                             elem="\n".join([repr(elem) for elem in current_list])))
        if comparator is None:
            assert container not in current_list,\
                "{} was found on: {}".format(container, pprint.pformat(current_list))
        else:
            for member in current_list:
                assert comparator(container, member) is False,\
                    "{} was found on: {}".format(container, pprint.pformat(current_list))

    @classmethod
    def ensure_not_on_list(cls, container: Union[str, 'DockerContainer'],
                           comparator: Callable[[Any, Any], bool] = None,
                           ensure_count: int = 1):
        retry_call(cls.check_not_on_list, fargs=[container, comparator],
                   exceptions=AssertionError,
                   tries=cls.NOT_ON_LIST_RETRY['tries'], delay=cls.NOT_ON_LIST_RETRY['delay'])
        for count in range(1, ensure_count):
            time.sleep(cls.NOT_ON_LIST_RETRY['delay'])
            cls.check_not_on_list(container, comparator)

    def __repr__(self):
        return "<%s: %s%s>" % (self.__class__.__name__,
                               self.id,
                               " (%s)" % self.container.id if self.container is not None else "")
