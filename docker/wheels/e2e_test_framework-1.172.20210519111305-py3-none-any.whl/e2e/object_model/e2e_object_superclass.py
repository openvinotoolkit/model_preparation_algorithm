#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
"""Describes the E2EObjectSuperclass, basis for most appliance objects"""

import functools
from abc import ABCMeta

from e2e.object_model.comparable import Comparable


@functools.total_ordering
class E2EObjectSuperclass(Comparable, metaclass=ABCMeta):
    """E2EObjectSuperclass represents base for any e2e objects, that have
    id, and can be created on the environment.

    When defining child classes, _COMPARABLE_ATTRIBUTES have to be defined. They
    are used to compare objects

    Several methods have to be reimplemented, but that's not mandatory.

    """

    def __init__(self, *, object_id: str):
        self.id = object_id
        self._is_deleted = False

    def __lt__(self, other):
        return self.id < other.id

    def __repr__(self):
        raise NotImplementedError

    @classmethod
    def from_response(cls, rsp):
        """Will create object from the response"""
        raise NotImplementedError

    @classmethod
    def list_from_response(cls, rsp):
        """Will create list of object from the response"""
        items = []
        for item in rsp:
            items.append(cls.from_response(item))
        return items

    def delete(self):
        """Will remove the object from DUT"""
        raise NotImplementedError

    @property
    def deleted(self):
        return self._is_deleted

    def cleanup(self):
        """Method called by context after tests have finished"""
        self.delete()
        self._set_deleted(True)

    def _set_deleted(self, is_deleted):
        self._is_deleted = bool(is_deleted)

    @staticmethod
    def delete_list(ls: list):
        for o in ls:
            o.delete()
