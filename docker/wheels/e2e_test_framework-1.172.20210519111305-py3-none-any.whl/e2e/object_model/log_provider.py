#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import inspect
from typing import Union, Callable, List, Iterator, Generic, TypeVar, Any

from abc import ABCMeta, abstractmethod
from retry.api import retry_call

LogRecord = TypeVar('LogRecord', str, Any)  # Any type.


class LogProvider(Generic[LogRecord], metaclass=ABCMeta):
    GETTING_LOGS_RETRY = {"tries": 45, "delay": 2}

    @classmethod
    def filter_logs(cls, filter_fn: Callable[[str], bool], logs: List[LogRecord]) -> Iterator[str]:
        return filter(filter_fn, logs)

    @classmethod
    def filter_function(cls, matcher: Union[str, Callable[[str], bool]],
                        logs: List[LogRecord]) -> Union[Callable[[str], bool], Any]:
        if isinstance(matcher, str):
            if len(logs) > 0:
                if cls.is_log_record_instance(logs[0]):
                    def matcher_fn(log_line: LogRecord) -> bool:
                        return matcher in cls.log_record_to_str(log_line)
                else:
                    raise RuntimeError("Incorrect type of list elements: {}, type: {}".
                                       format(str(logs[0]), str(type(logs[0]))))
            else:
                matcher_fn = None
        else:
            matcher_fn = matcher
        return matcher_fn

    @classmethod
    def log_record_to_str(cls, log_record: LogRecord) -> str:
        raise NotImplementedError

    @classmethod
    def is_log_record_instance(cls, list_element: Any) -> bool:
        raise NotImplementedError

    def check_non_empty_logs(self, acceptable_logs_length_trigger: int = 0, **kwargs):
        logs = self.logs(**kwargs)
        assert len(logs) > acceptable_logs_length_trigger, "Logs list for {} should {}".format(
            "{cls}({namespace}{separator}{name})"
            .format(cls=self.__class__.__name__,
                    name=self.name if hasattr(self, "name") else "",
                    namespace=self.namespace if hasattr(self, "namespace") else "",
                    separator="\\" if hasattr(self, "namespace") else ""),
            "not be empty" if acceptable_logs_length_trigger == 0 else
            "have more than {count} lines (got: {got}):\n{lines}\n"
            .format(count=acceptable_logs_length_trigger,
                    got=len(logs),
                    lines="\n".join([str(line) for line in logs])))
        return logs

    def ensure_non_empty_logs(self, **kwargs):
        return retry_call(self.check_non_empty_logs, fkwargs=kwargs,
                          exceptions=AssertionError, **self.GETTING_LOGS_RETRY)

    def check_logs_contains(self, matcher: Union[str, Callable[[str], bool]], **kwargs):
        logs = self.check_non_empty_logs(**kwargs)
        filter_function = self.filter_function(matcher, logs)
        assert next(self.filter_logs(filter_function, logs), None) is not None,\
            "Logs list should {}.".format("contain {}".
                                          format(matcher) if isinstance(matcher, str) else "match lambda: {}".
                                          format(inspect.getsource(matcher)))
        return logs

    def ensure_logs_contains(self, matcher: Union[str, Callable[[str], bool]], **kwargs):
        return retry_call(self.check_logs_contains, fargs=[matcher], fkwargs=kwargs,
                          exceptions=AssertionError, **self.GETTING_LOGS_RETRY)

    @abstractmethod
    def logs(self, *args, **kwargs):
        pass
