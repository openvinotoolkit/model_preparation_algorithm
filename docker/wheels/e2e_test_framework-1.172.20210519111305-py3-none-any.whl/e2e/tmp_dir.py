#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import _warnings
import logging
from pathlib import Path
from tempfile import TemporaryDirectory

import os
import string

import shutil
import stat
from datetime import datetime


class TemporaryDirectoryWithReadOnlyFilesCleaning(TemporaryDirectory):
    """Override to apply on_error function to cleanup methods."""
    _logger = None
    _log_files_from_logger_file_handlers = []
    _successfully_removed_read_only_files_counter = 0
    _ignore_errors = False

    @classmethod
    def _on_error(cls, del_func, path_to_remove, original_exception):
        try:
            if del_func == os.rmdir:
                path_to_remove_files = [Path(path_to_remove, file) for file in os.listdir(path_to_remove)]
                logger_files_in_path_to_remove = set(path_to_remove_files).intersection(
                    cls._log_files_from_logger_file_handlers)
                if len(logger_files_in_path_to_remove) > 0:
                    cls._logger.info("Cannot remove current directory\n{}\ndue to problem with "
                                     "removing log files caused by platform limitations:\n{}\n"
                                     .format(path_to_remove, "\n".join(map(str, logger_files_in_path_to_remove))))
                    return
                else:
                    cls._logger.error("Problem with removing dir: {}.\nListing contents:\n{}\n"
                                      .format(path_to_remove, "\n".join(path_to_remove_files)))
            os.chmod(path_to_remove, stat.S_IWRITE)
            del_func(path_to_remove)
            cls._successfully_removed_read_only_files_counter += 1
        except OSError as current_exception:
            cls._logger.exception("original exception:", exc_info=original_exception)
            cls._logger.exception("another attempt exception:", exc_info=current_exception)

    @classmethod
    def _get_logger_locally(cls):
        """Gets logger with local import to avoid circular imports."""
        from e2e.logger import get_logger
        cls._logger = get_logger(__name__)

    @classmethod
    def _gather_log_files_from_logger_file_handlers(cls):
        """Gather all FileHandlers to find all log files that could be open during cleanup."""
        cls._log_files_from_logger_file_handlers.extend(Path(handler.baseFilename)
                                                        for handler in cls._logger.root.handlers
                                                        if isinstance(handler, logging.FileHandler))

    @classmethod
    def _rmtree(cls, name, ignore_errors=None, onerror=None):
        """rmtree with number presentation of successfully removed read-only files """
        onerror = onerror if onerror is not None else cls._on_error
        ignore_errors = ignore_errors if ignore_errors is not None else cls._ignore_errors
        shutil.rmtree(name, ignore_errors=ignore_errors, onerror=onerror)
        if cls._successfully_removed_read_only_files_counter > 0:
            cls._logger.info("Number of read only files removed successfully: {}\n"
                             .format(cls._successfully_removed_read_only_files_counter))

    @classmethod
    def _cleanup(cls, name, warn_message):
        cls._get_logger_locally()
        cls._gather_log_files_from_logger_file_handlers()
        cls._rmtree(name)
        _warnings.warn(warn_message, ResourceWarning)

    def cleanup(self):
        self._get_logger_locally()
        self._gather_log_files_from_logger_file_handlers()
        if self._finalizer.detach():
            self._rmtree(self.name)


class TmpDir(str):
    """Creates safe temp dir"""
    TMP_DIR = None
    VALID_CHARS = "-_.() {letters}{digits}".format(letters=string.ascii_letters, digits=string.digits)
    SEPARATOR = "_"

    def __new__(cls, temp_dir: str = None) -> str:
        if cls.TMP_DIR is None:
            temp_dir = temp_dir if temp_dir else None
            cls.TMP_DIR = TemporaryDirectoryWithReadOnlyFilesCleaning(
                prefix=datetime.now().strftime('%Y%m%d_%H%M%S_%f') + cls.SEPARATOR,
                suffix=cls.SEPARATOR + cls.make_filesystem_safe(cls.get_user_name()),
                dir=temp_dir)
        return cls.TMP_DIR.name

    @classmethod
    def make_filesystem_safe(cls, to_be_safe: str):
        for whitespace in string.whitespace:
            to_be_safe = to_be_safe.replace(whitespace, cls.SEPARATOR)
        return "".join(c for c in to_be_safe if c in cls.VALID_CHARS)

    @classmethod
    def get_user_name(cls):
        try:
            user_name = os.getlogin()
        except OSError:
            user_name = os.environ.get(
                'USERNAME',
                os.environ.get(
                    "LOGNAME",
                    os.environ.get("USER", "not_known_user")))
        return user_name
