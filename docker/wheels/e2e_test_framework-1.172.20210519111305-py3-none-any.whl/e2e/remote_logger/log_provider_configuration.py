#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
from typing import Dict

from e2e.remote_logger.remote_logger_client import RemoteLoggerClient
from .base_configuration import BaseConfiguration


class LogProviderConfiguration(BaseConfiguration):
    """Log provider configuration object."""

    def __init__(self, from_date: str, to_date: str, app_name: str, client: RemoteLoggerClient):
        super().__init__(from_date, to_date)
        self._validate("app_name", str, app_name)
        self._validate("client", RemoteLoggerClient, client)
        self._app_name = app_name
        self._client = client

    @property
    def parameters(self) -> Dict[str, str]:
        return {
            "app_name": self.app_name,
            "from_date": self.from_date,
            "to_date": self.to_date,
        }

    @property
    def from_date(self):
        """Date in seconds format from which logs starts."""
        return self._from_date

    @property
    def to_date(self):
        """Date in seconds format to which logs ends."""
        return self._to_date

    @property
    def app_name(self):
        """Application name."""
        return self._app_name

    @property
    def client(self):
        """Client."""
        return self._client
