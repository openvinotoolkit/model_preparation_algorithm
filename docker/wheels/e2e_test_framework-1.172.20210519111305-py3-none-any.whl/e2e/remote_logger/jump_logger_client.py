#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
from typing import List, Dict

from e2e.command_wrappers import JournalCtl, Grep
from e2e.exceptions import CommandExecutionException
from e2e.logger import log_fixture
from e2e.remote_logger.remote_logger_client import RemoteLoggerClient
from e2e.ssh_lib import JumpClient, BaseJumpTunnel


class JumpLoggerClient(RemoteLoggerClient):
    fixture_name = "jump_client"
    TIME_BEFORE_NEXT_CALL = 15
    TUNNEL_AVAILABLE = False

    def __init__(self, client: JumpClient) -> None:
        from e2e.ssh_lib.tunnel import Tunnel
        self.Tunnel = Tunnel
        super().__init__(client)

    def save_logs(self, *args, **kwargs):
        pass

    def __enter__(self):
        if self.TUNNEL_AVAILABLE is False:
            self.tunnel = self.Tunnel(jump_client=self.client)  # type: BaseJumpTunnel
            self.tunnel.open()
            self.TUNNEL_AVAILABLE = True

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.TUNNEL_AVAILABLE is True:
            self.tunnel.close()

    def get_logs(self, app_name: str = None, from_date: str = None, to_date: str = None,
                 grep_list: list = None,
                 **kwargs) -> List[Dict[str, List[str]]]:
        """Retrieve journal ctl logs

        Args:
          app_name (unit): retrieve logs from specific unit
          from_date: date from which the logs will be retrieved
          to_date: date to which the logs will be retrieved
          grep_list: arguments for grep

        Returns:
          journal ctl logs
        """
        journal_log = []
        command = JournalCtl(unit=app_name, since=from_date, until=to_date)

        if grep_list:
            for arg in grep_list:
                command.extend(Grep(pattern=arg, ignore_case=False))
        try:
            log_fixture("Getting logs from journalctl")
            journal_log, _, _ = self.client.execute_ssh_command(command)
        except CommandExecutionException as exc:
            assert exc.output != ""
        return [{"journal": journal_log}]
