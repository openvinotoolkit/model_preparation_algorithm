#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

from multiprocessing import Process, Queue
from os import getpid
from time import sleep

from e2e import config
from ..logger import get_logger, log_fixture
from ..constants.logger_type import LoggerType
from .log_provider_configuration import LogProviderConfiguration

logger = get_logger(LoggerType.REMOTE_LOGGER)


class LogProvider(Process):
    """Object for getting logs form elastic search."""

    EMPTY_LOG = []
    TRIALS_LOG = "PID: {} - APP: {} - Try number: {}"
    EXCEPTION_LOG = "PID: {} - APP: {} - Exception: {}"

    def __init__(self, configuration: LogProviderConfiguration, queue: Queue):
        name = ".".join([configuration.app_name, configuration.client.fixture_name])
        super().__init__(name=name)
        self.name = name
        self._configuration = configuration
        self._queue = queue
        self._log = self.EMPTY_LOG

    def run(self):
        """Worker function to get logs from elastic search."""
        log_fixture("Collecting logs from {} using {}.".format(self._configuration.app_name,
                                                               self._configuration.client.fixture_name))
        try:
            log = self.EMPTY_LOG
            trials_number = 0
            while log == self.EMPTY_LOG:
                sleep(self._configuration.client.TIME_BEFORE_NEXT_CALL)
                trials_number += 1
                if trials_number > config.logsearch_collect_retry_count:
                    raise LogProviderExceededTrialsNumberException()
                logger.info(self.TRIALS_LOG.format(getpid(), self._configuration.app_name, trials_number))
                log = self._configuration.client.get_logs(**self._configuration.parameters)
            self._log = log if all(line.values() for line in log) else self.EMPTY_LOG
        except Exception as e:
            logger.error(self.EXCEPTION_LOG.format(getpid(), self._configuration.app_name, e))
            self._log = self.EMPTY_LOG
        else:
            logger.info("Logs collected and converted successfully")
        finally:
            self._update_queue()

    def _update_queue(self):
        """Put log results dictionary into process queue."""
        self._queue.put({self._configuration.app_name: self._log})


class LogProviderExceededTrialsNumberException(Exception):
    def __init__(self):
        super().__init__("Number of trials has been exceeded.")
