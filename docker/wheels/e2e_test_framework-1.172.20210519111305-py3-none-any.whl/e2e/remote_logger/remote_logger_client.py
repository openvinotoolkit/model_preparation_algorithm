#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
from abc import ABCMeta, abstractmethod
from typing import Type, Dict, Any, List

from _pytest.fixtures import FixtureRequest, FixtureLookupError

from e2e.helpers import SingletonABCMeta
from e2e.logger import get_logger

logger = get_logger(__name__)


class RemoteLoggerClient(metaclass=SingletonABCMeta):
    fixture_name = NotImplemented  # type: str
    TIME_BEFORE_NEXT_CALL = NotImplemented

    def __init__(self, client: Any) -> None:
        super().__init__()
        self._client = client

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass

    @abstractmethod
    def get_logs(self, app_name: str = None, from_date: str = None, to_date: str = None,
                 **kwargs) -> List[Dict[str, List[str]]]:
        return NotImplemented

    @abstractmethod
    def save_logs(self, *args, **kwargs):
        return NotImplemented

    @property
    def client(self):
        return self._client


class RemoteLoggerClientFactory(metaclass=ABCMeta):
    CLIENT_CLASSES = {}  # type: Dict[str, Type[RemoteLoggerClient]]

    def __new__(cls, request: FixtureRequest, client_fixture_name: str) -> RemoteLoggerClient:
        try:
            client = request.getfixturevalue(client_fixture_name)  # type: Any
        except FixtureLookupError as err:
            logger.exception("Cannot find fixture named: {}, double check its name".format(client_fixture_name),
                             exc_info=err)
            raise err
        assert client_fixture_name in cls.CLIENT_CLASSES, \
            "Cannot find registered RemoteLoggerClient implementation for fixture {}".format(client_fixture_name)
        target_cls = cls.CLIENT_CLASSES[client_fixture_name]
        return target_cls(client)

    @staticmethod
    def register(client: Type['RemoteLoggerClient']):
        RemoteLoggerClientFactory.CLIENT_CLASSES[client.fixture_name] = client
