#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import os
from multiprocessing import Queue
from queue import Empty

from typing import Dict, Union, List

from e2e import config
from e2e.remote_logger.remote_logger_configuration import RemoteLoggerConfiguration
from ..logger import get_logger, log_fixture
from ..constants.logger_type import LoggerType
from .log_provider import LogProvider


logger = get_logger(LoggerType.REMOTE_LOGGER)


class RemoteLogger(object):
    """Object for getting logs from remote sources."""
    TIMEOUT = 5 * 60
    LOG_FILES = set()
    # Log file name format
    LOG_FILE_NAME = "{}.log"
    FAILURES_COUNTER = "failures_counter"
    ROOT_DIRECTORY = os.path.join(os.getcwd(), config.test_log_directory)

    def __init__(self, configuration: RemoteLoggerConfiguration):

        self._configuration = configuration

    def run_logging_procedure(self):
        """Block which connects methods."""
        try:
            logs = self._get_logs()
            self._save_logs(logs)
        except Exception as e:
            logger.error(e)

    def _get_logs(self):
        """Run multiple log providers, one for each application.
        Wait for each process to finish and then collect all logs that have been read."""
        queue = Queue()
        logs = {self.FAILURES_COUNTER: 0}
        log_fixture("Collecting remote logs")
        with self._configuration:
            log_providers_processes = [LogProvider(log_provider_configuration, queue)
                                       for log_provider_configuration in self._configuration]
            for log_provider in log_providers_processes:
                log_provider.start()
            for _ in self._configuration:
                try:
                    logs.update(queue.get(timeout=self.TIMEOUT))
                except Empty as ee:
                    logger.exception("cannot get logs from queue (timeout {} exceeded)".format(self.TIMEOUT),
                                     exc_info=ee)
                    logs[self.FAILURES_COUNTER] += 1
            failures = self._configuration.app_names - set(logs.keys())
            for failure_app in failures:
                logs[failure_app] = [{"FAILURE": "timeout ({}) exceeded while waiting for logs.".format(self.TIMEOUT)}]
            for p in log_providers_processes:
                p.join()
        return logs

    def _save_logs(self, logs: Dict[str, Union[List[Dict[str, List[str]]], int]]):
        """Write logs to files, one separate file for each application name."""
        dir_path = os.path.join(self.ROOT_DIRECTORY, self._configuration.destination_directory)
        os.makedirs(dir_path, exist_ok=True)
        for app_name, app_logs in logs.items():
            if app_logs != LogProvider.EMPTY_LOG:
                if app_name != self.FAILURES_COUNTER:
                    for logs_entry in app_logs:
                        for log_src, log_messages in logs_entry.items():
                            name = ".".join([app_name, log_src])
                            self._save_log(name, log_messages, dir_path)
                else:
                    if isinstance(app_logs, int) and app_logs > 0:
                        logger.error("Failures counter returned: {}".format(str(app_logs)))
            else:
                logger.error("Empty log has been returned for: {}".format(app_name))

    @staticmethod
    def _save_log(app_name, app_log, dir_path):
        """Write log to file."""
        file_name = RemoteLogger.LOG_FILE_NAME.format(app_name)
        file_path = os.path.join(dir_path, file_name)
        RemoteLogger.LOG_FILES.add(file_path)
        logger.info("Save log to file: {}".format(file_path))
        with open(file_path, 'w') as file:
            if isinstance(app_log, list):
                file.writelines(app_log)
            else:
                file.write(app_log)
