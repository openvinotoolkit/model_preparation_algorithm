#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
from abc import ABCMeta


class ConfigurationValidator:
    @staticmethod
    def _validate(property_name, property_type, property_value):
        """Validate if given property has valid type and value."""
        if not property_value:
            raise ConfigurationEmptyPropertyException(property_name)
        if property_type is not object and not isinstance(property_value, property_type):
            raise ConfigurationInvalidPropertyTypeException(property_name)


class BaseConfiguration(ConfigurationValidator, metaclass=ABCMeta):
    """Base configuration object."""

    def __init__(self, from_date: str, to_date: str):
        self._validate("from_date", str, from_date)
        self._validate("to_date", str, to_date)
        self._from_date = from_date
        self._to_date = to_date

    @property
    def from_date(self):
        """Date in seconds format from which logs starts."""
        return self._from_date

    @property
    def to_date(self):
        """Date in seconds format to which logs ends."""
        return self._to_date


class ConfigurationEmptyPropertyException(Exception):
    TEMPLATE = "Property '{}' can not be empty."

    def __init__(self, message=None):
        super().__init__(self.TEMPLATE.format(message))


class ConfigurationInvalidPropertyTypeException(Exception):
    TEMPLATE = "Property '{}' has invalid type."

    def __init__(self, message=None):
        super().__init__(self.TEMPLATE.format(message))
