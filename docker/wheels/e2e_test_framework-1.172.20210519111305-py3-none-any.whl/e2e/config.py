#
# INTEL CONFIDENTIAL
# Copyright (c) 2021 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

import os
import posixpath
import re
from pathlib import PureWindowsPath, Path

from bson.objectid import ObjectId

from e2e.config_utils import delete_empty_env_variables, get_bool, get_int, get_list, \
    MAX_LOGGED_COMMAND_RUN_OUTPUT_LENGTH_DEFAULT, Environment, get_float
from e2e.constants.framework_constants import StrippingLists
from e2e.constants.infrastructure import get_infrastructure_type, InfrastructureType
from e2e.constants.supported_oses import OS
from e2e.current_os_info import CurrentOsInfo as OsInfo
from e2e.tmp_dir import TmpDir

try:
    # In user_config.py, user might export custom environment variables
    import user_config
except ImportError:
    pass

"""
Retrieve configuration from environment variables or set to defaults.
NOTE: for all config items, respective env variable names should start with a 'TT_' prefix.
"""

""" TT_FIXTURE_SELECTOR - keyword to select fixtures in conftest """
fixture_selector = os.environ.get("TT_FIXTURE_SELECTOR", None)  # type: str

""" SUDO_PASSWORD - variable needed to run commands with root"""
sudo_password = os.environ.get("SUDO_PASSWORD", None)


delete_empty_env_variables()

"""TT_OWNER - tests owner (to be put in object names)"""
tests_owner = os.environ.get("OWNER", "test")
tests_owner = os.environ.get("TT_OWNER", tests_owner)

""" TT_INFO_MODULE - indicates module that should be used for getting information about tested environment.
                     Default value: e2e.base_info.BaseInfo.
                     Allowed value class module that inherits from default class"""
info_module = os.environ.get("TT_INFO_MODULE", "e2e.base_info.BaseInfo")

"""TT_DOMAIN  - Domain name, Default  is xip.io """
domain_name = os.environ.get("TT_DOMAIN", "")

"""TT_LOGGING_LEVEL - framework log level, default: INFO"""
logging_level = os.environ.get("TT_LOGGING_LEVEL", "INFO")
"""TT_LOGGER_OUTPUT - framework strategy for logging, default: True, allowed values: True, Defer, False"""
logger_output = os.environ.get("TT_LOGGER_OUTPUT", "True")

""" TT_PRODUCT_VERSION - Environment version provided by user"""
product_version = os.environ.get("TT_PRODUCT_VERSION", "1.0.0")

""" TT_PRODUCT_VERSION_SUFFIX - Environment version suffix provided by user"""
product_version_suffix = os.environ.get("TT_PRODUCT_VERSION_SUFFIX", "oss")

""" TT_PRODUCT_VERSION_FROM_ENV - If set to True, version is taken from tested environment,
                                  If set to False version is taken from TT_PRODUCT_VERSION
                                  If TT_PRODUCT_VERSION not set default version is taken"""
product_version_number_from_env = get_bool("TT_PRODUCT_VERSION_FROM_ENV", False)

""" TT_TEST_SESSION_BUILD_NUMBER  - Test session build number provided by user or CI"""
test_session_build_number = os.environ.get("TT_TEST_SESSION_BUILD_NUMBER", "1")

""" TT_PRODUCT_BUILD_NUMBER  - Test product build number provided by user (last number from version - 0.8.0.XXXX)"""
product_build_number = os.environ.get("TT_PRODUCT_BUILD_NUMBER", "1")
""" TT_PRODUCT_BUILD_FROM_ENV - If set to True, environment build number is taken from tested environment,
                                If set to False environment build number is taken from TT_PRODUCT_BUILD_NUMBER
                                If TT_PRODUCT_BUILD_NUMBER not set default environment build number is taken"""
product_build_number_from_env = get_bool("TT_PRODUCT_BUILD_FROM_ENV", True)

""" TT_INSTALL_PACKAGE_NAME - Install package name provided by user """
install_package_name = os.environ.get("TT_INSTALL_PACKAGE_NAME", "default_package_name")
""" TT_INSTALL_PACKAGE_NAME_FROM_ENV - If set to True, install package name is taken from tested environment,
                                       If set to False install package name is taken from TT_INSTALL_PACKAGE_NAME
                                       If TT_INSTALL_PACKAGE_NAME not set default install package name is taken"""
install_package_name_from_env = get_bool("TT_INSTALL_PACKAGE_NAME_FROM_ENV", True)

""" TT_REPOSITORY_NAME - repository name provided by user """
repository_name = os.environ.get("TT_REPOSITORY_NAME", None)

""" TT_REPOSITORY_TESTS_PATH - repository internal tests root path provided by user """
repository_tests_path = os.environ.get("TT_REPOSITORY_TESTS_PATH", "/")

""" TT_SCM_REPOSITORY_STATE - scm repository state provided by user """
scm_repository_state = os.environ.get("TT_SCM_REPOSITORY_STATE", "default_scm_repository_state")
""" TT_SCM_REPOSITORY_STATE_FROM_ENV - If set to True, scm repository state name is taken from tested environment,
                                       If set to False scm repository state name is taken from TT_SCM_REPOSITORY_STATE
                                       If TT_SCM_REPOSITORY_STATE not set default scm repository state is taken"""
scm_repository_state_from_env = get_bool("TT_SCM_REPOSITORY_STATE_FROM_ENV", True)

""" TT_PROXY - http proxy to use when connecting over http and https """
http_proxy = os.environ.get("TT_PROXY", "")
https_proxy = os.environ.get("TT_PROXY", "")

""" TT_PRODUCT_INFRASTRUCTURE_TYPE - Environment infrastructure type provided by user. Possible values:
                                     BM - for appliance environments
                                     VIRTUAL - for virtual appliance environments
                                     HYBRID - for appliance environments with some virtual components
                                     CLOUD - for cloud environments (default) """
infrastructure_type_name = os.environ.get("TT_PRODUCT_INFRASTRUCTURE_TYPE", InfrastructureType.CLOUD.value).upper()
infrastructure_type = get_infrastructure_type(infrastructure_type_name)

""" ARTIFACT_KIND - image artifact kind provided by user, if not set default is taken: snapshot"""
release_type = os.environ.get("ARTIFACT_KIND", "snapshot")

""" TT_EXTERNAL_PROTOCOL - protocol used for http requests.
                           Possible values: http, https (default)"""
external_protocol = os.environ.get("TT_EXTERNAL_PROTOCOL", "https")

""" TT_INTERNAL_PROTOCOL - protocol used for internal http requests. Possible values: http (default), https """
internal_protocol = os.environ.get("TT_INTERNAL_PROTOCOL", "http")

# Proxy settings
global_no_proxy = os.environ.get("GLOBAL_NO_PROXY", "")
if global_no_proxy != "":
    current_no_proxy = os.environ.get("no_proxy", "")
    os.environ["no_proxy"] = "{},{}".format(current_no_proxy, global_no_proxy)
    current_no_proxy = os.environ.get("NO_PROXY", "")
    os.environ["NO_PROXY"] = "{},{}".format(current_no_proxy, global_no_proxy)

global_http_proxy = os.environ.get("GLOBAL_HTTP_PROXY", "")
global_https_proxy = os.environ.get("GLOBAL_HTTPS_PROXY", "")
if global_http_proxy != "":
    os.environ["http_proxy"] = global_http_proxy
    os.environ["HTTP_PROXY"] = global_http_proxy

if global_https_proxy != "":
    os.environ["https_proxy"] = global_https_proxy
    os.environ["HTTPS_PROXY"] = global_https_proxy

# Api related data
""" TT_API_AUTH_TOKEN - path for getting oauth token, default is oauth/token"""
api_token_endpoint = os.environ.get("TT_API_AUTH_TOKEN", "oauth/token")

""" TT_ENVIRONMENT_NAME - Environment name to be used while reporting test results
                          to be presented on test reports as a environment name."""
""" TT_ENV_DNS - Environment address base on DNS name. It used for ssh connections. Also presented on test reports
                 as environment name. If not set see TT_ENV_DNS"""
""" TT_ENV_IP - Environment address base on IP address. It used for ssh connections. Also presented on test reports
                 as environment name if TT_ENV_DNS is not set"""
environment = Environment(name=os.environ.get("TT_ENVIRONMENT_NAME"),
                          dns=os.environ.get("TT_ENV_DNS"),
                          ip=os.environ.get("TT_ENV_IP"))

"""TT_HOST_OS_USER - internal root user name, default root"""
host_os_user = os.environ.get("TT_HOST_OS_USER", "root")
"""TT_HOST_OS_PASSWORD - internal root user password, default blank"""
host_os_password = os.environ.get("TT_HOST_OS_PASSWORD", "")
"""TT_SOCKS_PROXY_PORT - port for creating tunnel to appliance, default 5555"""
socks_proxy_port = get_int("TT_SOCKS_PROXY_PORT", 5555)


"""TT_API_VERSION  - api version of appliance admin, default v1"""
api_version = os.environ.get("TT_API_VERSION", "v1")


"""TT_TEST_USER_EMAIL - email address where all default email should be sent , default intel.data.tests@gmail.com"""
test_user_email = os.environ.get("TT_TEST_USER_EMAIL", "intel.data.tests@gmail.com")

"""TT_DATABASE_URL - report database name.  if specified, results will be logged in this database"""
database_url = os.environ.get("TT_DATABASE_URL")  # if specified, results will be logged in database

"""TT_DATABASE_SSL - use ssl to access database """
database_ssl = get_bool("TT_DATABASE_SSL", False)  # if specified, results will be logged in database

"""TT_COLLECT_LOGSEARCH_LOGS - If set to True logs from tested environment are retrieved, default False"""
collect_logsearch_logs = get_bool("TT_COLLECT_LOGSEARCH_LOGS", False)

"""TT_LOGSEARCH_COLLECT_RETRY_COUNT - Number of tries framework tries to get logs from tested environment, default 5"""
logsearch_collect_retry_count = get_int("TT_LOGSEARCH_COLLECT_RETRY_COUNT", 5)

"""TT_LOGSEARCH_COLLECT_RETRY_INTERVAL - Interval in seconds between tries, default 1"""
logsearch_collect_retry_interval = get_int("TT_LOGSEARCH_COLLECT_RETRY_INTERVAL", 1)

"""TT_VERBOSE_SSH - if set to True verbose ssh is set , default: False """
verbose_ssh = get_bool("TT_VERBOSE_SSH", False)

"""TT_LOGGED_RESPONSE_BODY_LENGTH - length of http response logged , default: 1024 """
logged_response_body_length = os.environ.get("TT_LOGGED_RESPONSE_BODY_LENGTH", 1024)

"""TT_MAX_LOGGED_COMMAND_RUN_OUTPUT_LENGTH - max length of logged output from command.run """
max_logged_command_run_output = get_int("TT_MAX_LOGGED_COMMAND_RUN_OUTPUT_LENGTH",
                                        MAX_LOGGED_COMMAND_RUN_OUTPUT_LENGTH_DEFAULT)

"""TT_LOG_USERNAME - If set to True admin user name is logged , default: False """
log_username = os.environ.get("TT_LOG_USERNAME", False)

"""TT_DISABLE_ENVIRONMENT_CHECK - If set to True framework checks if environment is available , default: True """
disable_environment_check = get_bool("TT_DISABLE_ENVIRONMENT_CHECK", True)

"""TT_SMOKE_TESTS - False -> api-smoke tests are not run, True -> api-smoke tests are run, default: False"""
run_smoke_tests = get_bool("TT_SMOKE_TESTS", False)

"""TT_ON_COMMIT_TESTS - False -> api-on-commit tests are not run,
                             True -> api-on-commit tests are run, default: False"""
run_on_commit_tests = get_bool("TT_ON_COMMIT_TESTS", False)

"""TT_RUN_REGRESSION_TESTS - False -> api-regression tests are not run,
                             True -> api-regression tests are run, default: False"""
run_regression_tests = get_bool("TT_RUN_REGRESSION_TESTS", False)

"""TT_ENABLING_TESTS - False -> api-enabling tests are not run,
                             True -> api-enabling tests are run, default: False"""
run_enabling_tests = get_bool("TT_ENABLING_TESTS", False)

"""TT_API_OTHER_TESTS - False -> api-other tests are not run, True -> api-other tests are run, default: False"""
run_api_other_tests = get_bool("TT_API_OTHER_TESTS", False)

"""TT_GUI_OTHER_TESTS - False -> gui other tests are not run, True -> gui other tests are run, default: False"""
run_gui_other_tests = get_bool("TT_GUI_OTHER_TESTS", False)

"""TT_GUI_REGRESSION_TESTS - False -> gui regression tests are not run, True -> gui regression tests are run,
                             default: False"""
run_gui_regression_tests = get_bool("TT_GUI_REGRESSION_TESTS", False)

"""TT_GUI_ENABLING_TESTS - False -> gui enabling tests are not run, True -> gui enabling tests are run,
                             default: False"""
run_gui_enabling_tests = get_bool("TT_GUI_ENABLING_TESTS", False)

"""TT_GUI_SMOKE_TESTS - False -> gui smoke tests are not run, True -> gui smoke tests are run, default: False"""
run_gui_smoke_tests = get_bool("TT_GUI_SMOKE_TESTS", False)

"""TT_GUI_LONG_TESTS - False -> gui long tests are not run, True -> gui long tests are run, default: False"""
run_gui_long_tests = get_bool("TT_GUI_LONG_TESTS", False)

"""TT_MANUAL_TESTS - False -> manual tests are not run, True -> manual tests are run, default: False"""
run_manual_tests = get_bool("TT_MANUAL_TESTS", False)

"""TT_STRESS_AND_LOAD_TESTS - False -> api-long tests are not run, True -> api_stress-and-load tests are run, 
    default: False"""
run_stress_and_load_tests = get_bool("TT_STRESS_AND_LOAD_TESTS", False)

"""TT_LONG_TESTS - False -> api-long tests are not run, True -> api-long tests are run, default: False"""
run_long_tests = get_bool("TT_LONG_TESTS", False)

"""TT_PERFORMANCE_TESTS - False ->api-performance tests are not run,
                          True ->api-performance tests are run, default: False"""
run_performance_tests = get_bool("TT_PERFORMANCE_TESTS", False)

"""TT_ON_MERGE_REQUEST_TESTS - False -> api_on_merge tests are not run, 
    True -> api_on_merge tests are run, default: False"""
run_on_merge_request_tests = get_bool("TT_ON_MERGE_REQUEST_TESTS", False)

"""TT_GUI_ON_MERGE_REQUEST_TESTS - False -> gui_on_merge tests are not run, 
    True -> gui_on_merge tests are run, default: False"""
run_gui_on_merge_request_tests = get_bool("TT_GUI_ON_MERGE_REQUEST_TESTS", False)

"""TT_UNIT_TESTS - False -> unit tests are not run, 
    True -> unit tests are run, default: False"""
run_unit_tests = get_bool("TT_UNIT_TESTS", False)

"""TT_COMPONENT_TESTS - False -> component tests are not run, 
    True -> component tests are run, default: False"""
run_component_tests = get_bool("TT_COMPONENT_TESTS", False)

"""TT_NO_FAIL_NO_TESTS_COLLECTED - False -> fail when no tests are collected,
                                   True -> not fail when no tests are collected"""
no_fail_no_test_collected = get_bool("TT_NO_FAIL_NO_TESTS_COLLECTED", False)

if run_performance_tests:
    logger_format = "{}%(asctime)s {}- %(threadName)s:%(name)s" \
                    ":%(funcName)s:%(lineno)d - %(levelname)s: %(message)s".format
else:
    logger_format = "{}%(asctime)s {}- %(name)s - %(levelname)s: %(message)s".format

"""TT_INITIAL_TESTS - False -> initial tests are not run, True -> initial tests are run, default: False"""
run_initial_tests = get_bool("TT_INITIAL_TESTS", False)

"""TT_HW_SPECIFIC_TESTS - False -> hw specific tests are not run, True -> hw specific tests are run, default: False"""
run_hw_specific = get_bool("TT_HW_SPECIFIC_TESTS", False)

"""TT_DEBUG_ARTIFACTS - False -> additional artifacts are not stored,
                        True -> additional artifacts are stored, default: False"""
add_debug_artifacts = get_bool("TT_DEBUG_ARTIFACTS", False)

tmp_directory = posixpath.join(posixpath.sep, "tmp")
audit_full_log_path = posixpath.join(tmp_directory, "audit.log")
audit_logs_path = posixpath.join(posixpath.sep, "var", "log", "audit")
os_name = OsInfo.get_os_name()

nfs_test_data_dir = os.environ.get(
    "TT_NFS_TEST_DATA_DIR",
    "/nfs/test_data/" if os_name != OS.Windows else str(PureWindowsPath("Z:/")))

"""TEST_LOG_DIR - directory path where all logs are stored, default test_log"""
test_log_directory = os.environ.get("TEST_LOG_DIR", Path().absolute() / "test_log")
Path(test_log_directory).mkdir(exist_ok=True)
test_log_directory = str(test_log_directory)

"""TT_TEST_TEMP_DIR_CLEANUP - if set to false cleanup of tmp dir is omitted on non passing tests"""
test_temp_dir_cleanup = get_bool("TT_TEST_TEMP_DIR_CLEANUP", True)

"""TT_TEST_TEMP_DIR - directory path where all temporary files are stored, default is not set"""
test_temp_dir = os.environ.get("TT_TEST_TEMP_DIR", None)
tmp_dir = TmpDir(test_temp_dir)
tmp_dir_test_files = os.path.join(tmp_dir, "test_files")
tmp_file_name_prefix = "test_file"

"""ARTIFACTSINCULDE_PATH - absolute path to file .artifactsinclude"""
artifactsinclude_path = os.environ.get("ARTIFACTSINCULDE_PATH", os.path.abspath(os.path.join(os.pardir,
                                                                                             ".artifactsinclude")))

local_compressed_logs_filename_pattern = "results_{0}_*.tar"
log_grabber_configuration = [{
    "log_files": [
        audit_full_log_path
    ],
    "destination_directory": test_log_directory,
    "tar_name": os.environ.get("TEST_LOG_TAR_NAME", "")
}]


"""TT_BUILD_URL - Link to build where tests are being executed"""
test_build_log_url = os.environ.get("TT_BUILD_URL")

"""TT_PACKAGES_SERVER_ADDRESS - server with packages, keys, etc, default "". """
packages_server_address = os.environ.get("TT_PACKAGES_SERVER_ADDRESS", "")

"""TT_PACKAGES_SERVER_USER - user name to connect to TT_PACKAGES_SERVER_ADDRESS, default not set"""
packages_server_user = os.environ.get("TT_PACKAGES_SERVER_USER")

"""TT_PACKAGES_SERVER_PASSWORD - user password to connect to TT_PACKAGES_SERVER_ADDRESS, default not set"""
packages_server_password = os.environ.get("TT_PACKAGES_SERVER_PASSWORD")

""" TT_SMTP_AVAILABILITY - if set to True framework assumes that environment has smtp server configured,
                           default True"""
smtp_availability = get_bool("TT_SMTP_AVAILABILITY", True)

""" TT_SSL_VALIDATION - if set to True for https request ssl protocol validation is performed,
                           default False"""
ssl_validation = get_bool("TT_SSL_VALIDATION", False)


""" TT_TEST_RUN_ID - id of test run document. Set if you want to place your test run to existing document.
                        Make sure collection contains document with given id"""
test_run_id = os.environ.get("TT_TEST_RUN_ID", None)


""" TT_GITHUB_TOKEN - github token, default value is <undefined>"""
github_token = os.environ.get("TT_GITHUB_TOKEN", None)

"""TT_STRIP_SENSITIVE_DATA - do strip sensitive data"""
strip_sensitive_data = get_bool("TT_STRIP_SENSITIVE_DATA", False)

"""TT_SENSITIVE_KEYS - Coma delimited list of patterns of keys to be masked."""
sensitive_keys_to_be_masked = re.compile(
    "|".join(get_list("TT_SENSITIVE_KEYS", fallback=StrippingLists.DEFAULT_SENSITIVE_KEYS_TO_BE_MASKED)),
    re.IGNORECASE)

""" TT_UNIQUE_ID  - id used to generate test  object name, Default None"""
unique_id = os.environ.get("TT_UNIQUE_ID", None)

""" TT_LOG_REQUESTS  - if set to True every request is written do db, Default False"""
log_requests = get_bool("TT_LOG_REQUESTS", False)

""" TT_TUNNEL_TYPE - type of tunnel used in tests for running command from machines inside environment,
                     Possible values: None(Default), SimpleJumpTunnel, JumpTunnel, NestedJumpTunnel
"""
tunnel_type = os.environ.get("TT_TUNNEL_TYPE", None)

""" TT_TUNNEL_HOST - master node address"""
tunnel_host = os.environ.get("TT_TUNNEL_HOST", None)

""" TT_TUNNEL_USER - user name to create tunnel"""
tunnel_user = os.environ.get("TT_TUNNEL_USER", "tunnel")

""" TT_TUNNEL_PASS - user password to create tunnel"""
tunnel_pass = os.environ.get("TT_TUNNEL_PASS", "")

""" TT_TUNNEL_PRIV_KEY - private key location to create tunnel"""
tunnel_priv_key = os.environ.get("TT_TUNNEL_PRIV_KEY", "")


""" TT_NESTED_TUNNEL_HOSTNAME - hostname of machine used in NestedJumpTunnel"""
nested_tunnel_hostname = os.environ.get("TT_NESTED_TUNNEL_HOSTNAME", None)

tenant_name = "Automated_example_test_tenant"
admin_group_name = "Automated example test admin group"
user_group_name = "Automated example test user group"

""" TT_ENV_USER - user name to log in to the master node"""
env_user = os.environ.get("TT_ENV_USER", "cloud-user")

""" TT_ENV_PASS - user password to log in to the master node"""
env_pass = os.environ.get("TT_ENV_PASS", "")

""" TT_ENV_PRIV_KEY - private key location to log in to the master node"""
env_priv_key = os.environ.get("TT_ENV_PRIV_KEY", "")

""" TT_STARTING_PORT - Starting port for port manager"""
starting_port = get_int("TT_STARTING_PORT", 9001)

""" TT_PORTS_POOL_SIZE - Ports pool size"""
ports_pool_size = get_int("TT_PORTS_POOL_SIZE", 10)

""" TT_SELENIUM_HEADLESS - Run selenium headless"""
selenium_headless = get_bool("TT_SELENIUM_HEADLESS", True)

""" TT_BROWSER_HEIGHT - Browser screen height"""
browser_height = os.environ.get("TT_BROWSER_HEIGHT", 1020)

""" TT_BROWSER_WIDTH - Browser screen width"""
browser_width = os.environ.get("TT_BROWSER_WIDTH", 1920)

""" TT_DISPLAY_NUMBER - Display number"""
display_number = os.environ.get("TT_DISPLAY_NUMBER", "99")

""" TT_DOCKER_REGISTRY - Docker registry"""
docker_registry = os.environ.get("TT_DOCKER_REGISTRY", "registry.toolbox.iotg.sclab.intel.com")

""" TT_CMD_WRAPPER_SLEEP_TIME - Sleep time between checking if is_alive in _cmd_wrapper """
cmd_wrapper_sleep_time = get_float("TT_CMD_WRAPPER_SLEEP_TIME", 0.01)

""" TT_BUGS - Bugs"""
bug_ids = os.environ.get("TT_BUGS", None)

""" TT_REQUIREMENTS - Requirements"""
req_ids = os.environ.get("TT_REQUIREMENTS", None)

""" TT_JIRA_SERVER - JiraClient server url"""
jira_server = os.environ.get("TT_JIRA_SERVER", "https://jira.devtools.intel.com")
jira_user = os.environ.get("TT_JIRA_USER", "iotg_odt_val")
jira_pass = os.environ.get("TT_JIRA_PASS", None)
jira_project_key = os.environ.get("TT_JIRA_PROJECT_KEY", "CVS")


"""

----------------------------------------------------------------------------------------------------------------------
deprecated configuration
----------------------------------------------------------------------------------------------------------------------

"""
# --------------------------------- Performance tests -------------------------------- #
locust_file = os.environ.get("TT_LOCUST_FILE", None)
num_clients = get_int("TT_NUM_CLIENTS", 2)
hatch_rate = os.environ.get("TT_HATCH_RATE", "1")
test_duration = get_int("TT_DURATION", 10) * 60
locust_port = os.environ.get("TT_LOCUST_PORT", "8089")
locust_address = "http://localhost:{}".format(locust_port)

stress_run_id = os.environ.get("TT_STRESS_RUN_ID", None)
if stress_run_id:
    stress_run_id = ObjectId(stress_run_id)
log_metrics_interval = get_int("TT_LOG_METRICS_INTERVAL", 0)

# --------------------------------- GUI tests -------------------------------- #
gui_page = os.environ.get("TT_GUI_PAGE", "http://localhost")
artifacts_dir = os.environ.get("BUILD_LOGS", "")
recording = get_bool("TT_RECORDING", False)
recording_status_quiet = get_bool("TT_RECORDING_STATUS_QUIET", True)

"""TT_CHROME_DRIVER location path of chromedriver.exe"""
chrome_driver_windows = os.environ.get("TT_CHROME_DRIVER", None)

"""TT_DESKTOP_APP location path of desktop application under test"""
desktop_application = os.environ.get("TT_DESKTOP_APP", None)

# ---------------- Mongo as a docker container for test purposes ------------- #
"""TT_MONGO_DOCKER_REGISTRY - docker registry to fetch from mongo image
                              to use docker.io set to empty string ("") """
mongodb_docker_registry = os.environ.get("TT_MONGO_DOCKER_REGISTRY",
                                         "registry.toolbox.iotg.sclab.intel.com")

"""TT_MONGO_DOCKER_IMAGE_NAME - mongo docker image name"""
mongodb_docker_image_name = os.environ.get("TT_MONGO_DOCKER_IMAGE_NAME", "mongo")

"""TT_MONGO_DOCKER_TAG - mongo docker image tag/version"""
mongodb_docker_tag = os.environ.get("TT_MONGO_DOCKER_TAG", "4.4-bionic")

"""TT_MONGO_DOCKER_IMAGE - mongo docker image with tag default: mongo:4.4-bionic"""
mongodb_docker_image = os.environ.get(
    "TT_MONGO_DOCKER_IMAGE",
    "{registry}{name}".format(
        registry=f"{mongodb_docker_registry}/" if mongodb_docker_registry else "",
        name=mongodb_docker_image_name))

"""TT_MONGO_DOCKER_PORT - port mapping to use in mongo container
                          default value is None -> docker auto assigment"""
mongodb_docker_port = os.environ.get("TT_MONGO_DOCKER_PORT", None)

"""TT_START_MONGO_IN_DOCKER - start mongo docker image"""
mongodb_docker_auto_start = os.environ.get("TT_START_MONGO_IN_DOCKER", False)
