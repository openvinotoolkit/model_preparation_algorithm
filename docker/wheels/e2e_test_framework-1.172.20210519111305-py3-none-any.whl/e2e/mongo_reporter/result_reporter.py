#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#


import pprint
from collections import defaultdict
from datetime import datetime
from typing import TYPE_CHECKING, List, Dict

from e2e import config
from e2e.constants.framework_constants import FrameworkMessages

from e2e.mongo_reporter.base_reporter import BaseReporter, TestStatus
from e2e.logger import get_logger
from e2e.logging_filters import SensitiveKeysStrippingFilter
from e2e.helpers import log_trimmer
from e2e.markers import MarkRunType, MarkGeneral

if TYPE_CHECKING:
    from _pytest.nodes import Item
    from _pytest.python import Function

logger = get_logger(__name__)


DEFAULT_VERSION = "0.0.1"
SKIP_MARK_NOT_FOUND_REASON = "No skip marker, cannot return skip reason"
XFAIL_MARK_NOT_FOUND_REASON = "No xfail marker, cannot return xfail reason"

STAGE = {
    "setup": "Setup",
    "call": "Test",
    "teardown": "Teardown"
}


class ResultReporter(BaseReporter):

    _TEST_COLLECTION_NAME = "test_result"

    def __init__(self, run_id, document_id=None):
        self.stress_run_id = config.stress_run_id
        self.sensitive_data_filter = SensitiveKeysStrippingFilter()
        self._total_test_counter = 0
        self.logs = ""
        self.links = None
        self.stage = ""
        self.stacktrace = ""
        self.test_type = None
        self.performance_results = None
        self.run_id = run_id
        self.start_date = "",
        logger.info("Result Reporter init")
        super().__init__(mongo_run_document=None, document_id=document_id)
        self._log = []

    @staticmethod
    def _get_test_docstring(item):
        docstring = item.obj.__doc__
        if docstring:
            docstring = docstring.strip()
        return docstring

    @staticmethod
    def _marker_args_from_item(item: 'Item', marker_name):
        marker = item.get_closest_marker(marker_name)
        return tuple(sorted(set(getattr(marker, "args", tuple()))))

    @staticmethod
    def _bugs_from_item(item: 'Item', test_case) -> List[str]:
        """
        expected format:

        mark.bugs({
           None: ["XYZ-123456 bug for all parameters"
                  "XYZ-210987 another bug for all parameters",
                  "XYZ-098765 yet another bug for all parameters",]
           "param 01": ["XYZ-654321 bug 1 for param 01",
                        "XYZ-654322 bug 2 for param 01],
           "param 02": ["XYZ-789012 bug for param 02"],
        })


        """
        bugs_marker = item.get_closest_marker(MarkGeneral.BUGS)
        bugs = getattr(bugs_marker, "args", set())
        all_bugs = defaultdict(set)
        for bug in bugs:
            if isinstance(bug, str):
                all_bugs[None].add(bug)
            elif isinstance(bug, (list, set, tuple)):
                all_bugs[None].update(bug)
            elif isinstance(bug, dict):
                for case, bug_items in bug.items():
                    all_bugs[case] = set(bug_items)
            else:
                raise RuntimeError(f"Incorrect bug mark type: {type(bug)}, "
                                   f"value: {pprint.pformat(bug)}")
        return sorted(all_bugs[test_case] | all_bugs[None])

    @staticmethod
    def _get_skip_reason(item: 'Item'):
        skip_marker = item.get_closest_marker("skipif")
        if skip_marker is None:
            skip_marker = item.get_closest_marker("skip")
        if skip_marker is not None:
            kwargs = getattr(skip_marker, "kwargs", None)
            if kwargs is not None:
                return kwargs.get('reason')

        return SKIP_MARK_NOT_FOUND_REASON

    @staticmethod
    def _get_xfail_reason(item: 'Item'):
        xfail_marker = item.get_closest_marker("xfail")
        if xfail_marker is not None:
            kwargs = getattr(xfail_marker, "kwargs", None)
            if kwargs is not None:
                return kwargs.get('reason')

        return XFAIL_MARK_NOT_FOUND_REASON

    @staticmethod
    def _priority_from_report(report):
        priority_pattern = "priority_"
        for keyword in report.keywords:
            if keyword.startswith(priority_pattern):
                return keyword.replace(priority_pattern, "")

    @staticmethod
    def _stage_from_report(report):
        if report.when in STAGE.keys():
            return STAGE[report.when]
        else:
            return ""

    @staticmethod
    def _stacktrace_from_report(report):
        stacktrace = getattr(report.longrepr, "reprtraceback", None)
        if stacktrace is not None:
            return str(stacktrace)
        else:
            return ""

    @classmethod
    def _test_status_from_report(cls, report, item: 'Item'):
        if report.passed:
            return TestStatus.RESULT_PASS
        elif report.failed:
            return TestStatus.RESULT_FAIL
        elif report.skipped:
            reason = cls._get_skip_reason(item)
            if SKIP_MARK_NOT_FOUND_REASON in reason:
                reason = cls._get_xfail_reason(item)
            if reason == FrameworkMessages.NOT_IMPLEMENTED:
                return TestStatus.RESULT_NOT_IMPLEMENTED
            elif reason == FrameworkMessages.NEXT_VERSION:
                return TestStatus.RESULT_NEXT_VERSION
            elif reason == FrameworkMessages.NOT_TO_BE_REPORTED_IF_SKIPPED:
                return TestStatus.RESULT_NOT_TO_BE_REPORTED
            elif FrameworkMessages.NOT_TO_BE_REPORTED_IF_SKIPPED in report.longreprtext:
                return TestStatus.RESULT_NOT_TO_BE_REPORTED
            elif reason == FrameworkMessages.FEATURE_NOT_READY:
                return TestStatus.RESULT_FEATURE_NOT_READY
            elif reason == FrameworkMessages.TEST_ISSUE:
                return TestStatus.RESULT_TEST_ISSUE
            return TestStatus.RESULT_SKIPPED
        else:
            return TestStatus.RESULT_UNKNOWN

    def _update_logs(self, report):
        trimmed_logs = log_trimmer(logs=report.caplog)
        self.logs = f"{self.logs }\n{trimmed_logs}" if self.logs != "" else trimmed_logs

    def _get_stacktrace(self, report):
        striped_stacktrace = self.sensitive_data_filter.strip_sensitive_data(self._stacktrace_from_report(report))
        return striped_stacktrace if striped_stacktrace is not None else ""

    def _update_stacktrace(self, report):
        striped_stacktrace = self._get_stacktrace(report)
        self.stacktrace = f"{self.stacktrace }\n{striped_stacktrace}" if self.stacktrace != "" else striped_stacktrace

    def log_report(self, report, item: 'Function', order):
        doc, status = None, None
        self.logs = log_trimmer(logs=report.caplog)

        if report.when == "setup":
            doc, status = self._on_test_start(report, item, order)
        elif report.when == "call":
            doc, status = self._on_test(report, item, order)
        elif report.failed:
            doc, status = self._on_fixture_error(report, item)
        elif report.skipped:
            doc, status = self._on_fixture_skipped(report, item)

        new_tests = 0
        if doc is not None:
            self.mongo_run_document = doc
            new_tests = self._save_test_collection()

        return doc, status, new_tests

    def _on_test_start(self, report, item: 'Function', order):
        status = self._test_status_from_report(report, item) if report.failed or report.skipped else None
        self.stage = self._stage_from_report(report)
        if status == TestStatus.RESULT_NOT_TO_BE_REPORTED:
            # we do not report such test cases at all
            return None, status
        item.start_date = datetime.now()
        self.start_date = item.start_date
        self.stacktrace = self._get_stacktrace(report)
        self.document_id = None
        self._build_test_links(item)

        test_mongo_document = self._common_mongo_document(report=report, item=item)
        test_mongo_document.update({
            "duration": report.duration if report.failed else 0.0,
            "status": status,
            "order": order,
            "start_date": self.start_date,
            "end_date": datetime.now() if report.failed or report.skipped else None
        })
        test_name = item.location[2]
        separator = "*" * len(test_name)
        logger.info("\n{0}\n\n{1}\n\n{0}\n".format(separator, test_name))
        return test_mongo_document, status

    def _build_test_links(self, item):
        self.links = []  # type: List[Dict[str, str]]
        if hasattr(item, "_log_file_name"):
            path = f"{config.test_build_log_url}" \
                   f"artifact/.workspace/scm/" \
                   f"{config.repository_name}" \
                   f"{config.repository_tests_path}" \
                   f"test_log"
            link = f"{path}/{getattr(item, '_log_file_name')}"
            self.links.append({
                "type": "test_log",
                "link": link
            })
        path = f"{config.test_build_log_url}artifact/test_log"
        if hasattr(item, "_screenshot_file_name"):
            link = f"{path}/{getattr(item, '_screenshot_file_name')}"
            self.links.append({
                "type": "test_screenshot_full",
                "link": f"{link}_full.png"
            })
            self.links.append({
                "type": "test_screenshot",
                "link": f"{link}.png"
            })
            self.links.append({
                "type": "test_html",
                "link": f"{link}.html"
            })
        if hasattr(item, "_recording_file_name"):
            link = f"{path}/{getattr(item, '_recording_file_name')}"
            self.links.append({
                "type": "test_recording",
                "link": link
            })

    def _on_test(self, report, item: 'Function', order):
        status = self._test_status_from_report(report, item)
        self.stage = self._stage_from_report(report)
        if status == TestStatus.RESULT_NOT_TO_BE_REPORTED:
            # we do not report such test cases at all
            return None, status
        self.stacktrace = self._get_stacktrace(report)

        test_mongo_document = self._common_mongo_document(report=report, item=item)
        test_mongo_document.update({
            "duration": report.duration,
            "status": status,
            "order": order,
            "start_date": self.start_date,
            "end_date": datetime.now()
        })
        return test_mongo_document, status

    def _on_fixture_error(self, report, item: 'Function'):
        self._update_stacktrace(report=report)
        self.stage = self._stage_from_report(report)
        # reset document_id because otherwise this fixture would overwrite result for the test itself
        if report.when != "teardown":
            self.document_id = None

        fixture_mongo_document = self._common_mongo_document(report=report, item=item)
        fixture_mongo_document.update({
            "duration": report.duration,
            "status": TestStatus.RESULT_FAIL,
            "start_date": self.start_date,
            "end_date": datetime.now(),
            "performance_results": None,
        })
        return fixture_mongo_document, TestStatus.RESULT_FAIL

    def _on_fixture_skipped(self, report, item: 'Function'):
        self._update_stacktrace(report=report)
        self.stage = self._stage_from_report(report)
        # reset document_id because otherwise this fixture would overwrite result for the test itself
        if report.when != "teardown":
            self.document_id = None
        reason = self._get_skip_reason(item)
        if reason == FrameworkMessages.NOT_IMPLEMENTED:
            status = TestStatus.RESULT_NOT_IMPLEMENTED
        elif reason == FrameworkMessages.NEXT_VERSION:
            status = TestStatus.RESULT_NEXT_VERSION
        else:
            status = TestStatus.RESULT_SKIPPED

        fixture_mongo_document = self._common_mongo_document(report=report,  item=item)
        fixture_mongo_document.update({
            "status": status,
            "start_date": datetime.now(),
            "end_date": datetime.now()
        })

        return fixture_mongo_document, status

    def _common_mongo_document(self, report, item: 'Function'):
        test_case = item.callspec.id if hasattr(item, "callspec") else None
        bugs = self._bugs_from_item(item, test_case)
        test_type_mark = MarkRunType.get_test_type_mark(item)
        self.test_type = MarkRunType.test_mark_to_test_run_type(test_type_mark)
        if test_type_mark == MarkRunType.TEST_MARK_PERFORMANCE and report.when == "call":
            performance_results = item.keywords.node.instance.PERFORMANCE_RESULTS
            if performance_results is not None:
                self.performance_results = performance_results
        failed_test_logs = self.logs if report.failed else ""
        common_mongo_document = {
            "stage": self.stage,
            "components": self._marker_args_from_item(item, MarkGeneral.COMPONENTS),
            "reqids": self._marker_args_from_item(item, MarkGeneral.REQIDS),
            "defects": bugs,
            "docstring": self._get_test_docstring(item),
            "logs": self.sensitive_data_filter.strip_sensitive_data(failed_test_logs),
            "links": self.links,
            "name": item.nodeid,
            "priority": self._priority_from_report(report),
            "run_id": self.run_id,
            "stacktrace": self.stacktrace,
            "tags": ", ".join(report.keywords),
            "test_type": self.test_type,
            "performance_results": self.performance_results
        }
        return common_mongo_document

    @staticmethod
    def _remove_dots_from_env_keys(variables: dict):
        new = {}
        for key, value in variables.items():
            new[key.replace('.', '-')] = value
        return new
