#
# INTEL CONFIDENTIAL
# Copyright (c) 2017 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import logging

from bson.objectid import ObjectId
from pymongo.errors import ConnectionFailure

from e2e import config
from e2e.mongo_reporter._client import MockDbClient, DBClient

logger = logging.getLogger(__name__)

DEFAULT_ENVIRONMENT_NAME = "default_environment"


class TestStatus:
    RESULT_PASS = "PASS"
    RESULT_FAIL = "FAIL"
    RESULT_SKIPPED = "SKIPPED"
    RESULT_NOT_IMPLEMENTED = "NOT_IMPLEMENTED"
    RESULT_NEXT_VERSION = "NEXT_VERSION"
    RESULT_UNKNOWN = "UNKNOWN"
    RESULT_NOT_TO_BE_REPORTED = "RESULT_NOT_TO_BE_REPORTED"
    RESULT_TEST_ISSUE = "TEST_ISSUE"
    RESULT_FEATURE_NOT_READY = "FEATURE_NOT_READY"


class BaseReporter(object):

    _TEST_COLLECTION_NAME = None

    def __init__(self, mongo_run_document, document_id=None):
        """Important! This method cannot make http calls!"""

        if config.database_url is None:
            logger.warning("Not writing results to a database - database_url not configured.")
            self._db_client = MockDbClient()
        else:
            try:
                self._db_client = DBClient(uri=config.database_url, ssl=config.database_ssl)
            except ConnectionFailure:
                logger.error("Failed to connect to: " + config.database_url)
                self._db_client = MockDbClient()

        if document_id is not None:
            document_id = ObjectId(document_id)
        self._document_id = document_id

        self.mongo_run_document = mongo_run_document
        if self.mongo_run_document is not None:
            self._save_test_collection()

    @property
    def mongo_run_document(self):
        return self._mongo_run_document

    @mongo_run_document.setter
    def mongo_run_document(self, document):
        self._mongo_run_document = document

    @property
    def document_id(self):
        return self._document_id

    @document_id.setter
    def document_id(self, id_):
        self._document_id = id_

    def _save_test_collection(self):
        assert self._TEST_COLLECTION_NAME is not None, \
                "No collection name is provided to reporter"

        if self.document_id is None:
            self.document_id = self._db_client.insert(collection_name=self._TEST_COLLECTION_NAME,
                                                      document=self.mongo_run_document)
            return 1
        else:
            self._db_client.replace(collection_name=self._TEST_COLLECTION_NAME,
                                    document_id=self._document_id,
                                    new_document=self.mongo_run_document)
            return 0
