#
# INTEL CONFIDENTIAL
# Copyright (c) 2017 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

import time
from datetime import datetime
from pymongo.errors import ConnectionFailure

from requests import PreparedRequest

from e2e import config
from e2e.mongo_reporter._client import MockDbClient, DBClient
from e2e.logger import get_logger

logger = get_logger(__name__)


class RequestReporter:
    COLLECTION_NAME = 'request'

    def __init__(self):
        self.requests = []

        if self._log_requests():
            try:
                self._db_client = DBClient(uri=config.database_url, ssl=config.database_ssl)
            except ConnectionFailure:
                logger.error("Failed to connect to: " + config.database_url)
                self._db_client = MockDbClient()
        else:
            if config.database_url is None:
                logger.warning("Not writing results to a database - database_url not configured.")
            self._db_client = MockDbClient()

    @staticmethod
    def _log_requests():
        return config.log_requests and config.database_url and config.stress_run_id

    def add_request(self, request: dict):
        request['stress_run_id'] = config.stress_run_id
        logger.debug('New request logged: {}'.format(request))
        self.requests.append(request)

    def send_to_db(self, test_name, result_document_id):
        for request in self.requests:
            request.update({
                'test_name': test_name,
                'result_id': result_document_id
            })
        logger.info('Sending logged requests to db ({} requests)'.format(len(self.requests)))
        for request in self.requests:
            self._db_client.insert(collection_name=self.COLLECTION_NAME, document=request)
        self.requests = []


request_reporter = RequestReporter()


def log_request(func: callable):

    def wrapper(self, request: PreparedRequest, path: str, path_params, timeout: int):
        request_info = {
            'date': datetime.now(),
            'method': request.method,
            'url': path,
            'url_params': path_params
        }
        start_time = time.perf_counter()

        response = func(self, request=request, timeout=timeout)

        request_info['duration'] = time.perf_counter() - start_time
        request_info['status_code'] = response.status_code

        request_reporter.add_request(request_info)

        return response

    return wrapper
