#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

import configparser
import os
import socket
from datetime import datetime

from e2e import config
from e2e.constants.project_paths import Path

from e2e.environment_info import EnvironmentInfo
from e2e.mongo_reporter.base_reporter import BaseReporter, DEFAULT_ENVIRONMENT_NAME, TestStatus
from e2e.mongo_reporter.result_reporter import ResultReporter
from e2e.logger import get_logger
from e2e.logging_filters import SensitiveKeysStrippingFilter
from e2e.markers import MarkRunType

logger = get_logger(__name__)


DEFAULT_VERSION = "0.0.1"


class RunReporter(BaseReporter):

    _TEST_COLLECTION_NAME = "test_run"

    def __init__(self, environment=DEFAULT_ENVIRONMENT_NAME, document_id=None):
        stress_run_id = config.stress_run_id
        self.sensitive_data_filter = SensitiveKeysStrippingFilter()
        self._total_test_counter = 0
        self.logs = ""
        self.test_type = None
        self.performance_results = None
        logger.info("RunReporter init")
        logger.info(os.environ)
        mongo_run_document = {
            "end_date": None,
            "environment": environment,
            "system": EnvironmentInfo.get_os_distname(),
            "finished": False,
            "infrastructure_type": config.infrastructure_type.value,
            "parameters": {
                "environment_variables": self.sensitive_data_filter.strip_sensitive_dict_values(
                    self._remove_dots_from_env_keys(os.environ)),
            },
            "platform_components": [],
            "result": {TestStatus.RESULT_PASS: 0,
                       TestStatus.RESULT_FAIL: 0,
                       TestStatus.RESULT_SKIPPED: 0,
                       TestStatus.RESULT_UNKNOWN: 0,
                       TestStatus.RESULT_NOT_IMPLEMENTED: 0,
                       TestStatus.RESULT_NEXT_VERSION: 0,
                       TestStatus.RESULT_FEATURE_NOT_READY: 0,
                       TestStatus.RESULT_TEST_ISSUE: 0},
            "start_date": datetime.now(),
            "started_by": socket.gethostname(),
            "status": TestStatus.RESULT_PASS,
            "logs": self.logs,
            "stress_run_id": stress_run_id,
            "test_count": 0,
            "total_test_count": 0,
            "test_build_log_url": config.test_build_log_url,
            "test_version": self._get_test_version(),

            # updated in separate methods
            "components": [],
            "reqids": [],
            "environment_availability": True,
            "test_session_build_number": None,
            "product_build_number": None,
            "environment_version": None,
            "test_type": self.test_type,
        }
        super().__init__(mongo_run_document=mongo_run_document, document_id=document_id)
        self._log = []
        self.result_reporter = ResultReporter(run_id=self.document_id)

    def report_components(self, all_test_components, save=False):
        self.mongo_run_document["components"] = list(set(all_test_components))
        if save:
            self._save_test_collection()

    def report_reqids(self, all_test_reqids, save=False):
        self.mongo_run_document["reqids"] = list(set(all_test_reqids))
        if save:
            self._save_test_collection()

    def report_test_type(self, test_type_mark, save=True):
        self.mongo_run_document["test_type"] = MarkRunType.test_mark_to_test_run_type(test_type_mark)
        if save:
            self._save_test_collection()

    def report_unavailable_environment(self):
        self.mongo_run_document["environment_availability"] = False
        self.on_run_end()

    def report_test_build_number(self, save=True, build_number=None):
        self.mongo_run_document["test_session_build_number"] = build_number
        if save:
            self._save_test_collection()

    def report_env_numbers(self, save=True, build_number=None, version_number=None):
        self.mongo_run_document["product_build_number"] = build_number
        self.mongo_run_document["environment_version"] = version_number
        if save:
            self._save_test_collection()

    def report_start_date(self, start_date, save=True):
        self.mongo_run_document["start_date"] = start_date
        if save:
            self._save_test_collection()

    def save_report(self):
        self._save_test_collection()

    def on_run_end(self):
        mongo_run_document = {
            "end_date": datetime.now(),
            "total_test_count": self._total_test_counter,
            "finished": True
        }
        self.mongo_run_document.update(mongo_run_document)
        self._save_test_collection()

    def log_report(self, report, item):
        doc, status, new_tests = self.result_reporter.log_report(report=report, item=item,
                                                                 order=self.mongo_run_document["test_count"])

        if doc is not None:
            self.update_run_status(status, new_tests)
            return self.document_id

    @staticmethod
    def _get_test_version():
        bumpversion_file_path = Path.bumpversion_file
        if os.path.isfile(bumpversion_file_path):
            bumpversion_config = configparser.ConfigParser()
            bumpversion_config.read(bumpversion_file_path)
            version = bumpversion_config["bumpversion"].get("current_version", None)
            assert version is not None, "Version not found in {}".format(bumpversion_file_path)
        else:
            logger.info("No such file {}".format(bumpversion_file_path))
            version = DEFAULT_VERSION
        return version

    def update_run_status(self, test_status, new_tests):
        self._total_test_counter += new_tests
        self.mongo_run_document["test_count"] += new_tests
        if test_status is not None:  # it is not set for successful test setup
            if self.mongo_run_document["status"] == TestStatus.RESULT_PASS:
                if test_status == TestStatus.RESULT_FAIL:
                    self.mongo_run_document["status"] = TestStatus.RESULT_FAIL
                elif test_status == TestStatus.RESULT_FEATURE_NOT_READY:
                    self.mongo_run_document["status"] = TestStatus.RESULT_FEATURE_NOT_READY
                elif test_status == TestStatus.RESULT_TEST_ISSUE:
                    self.mongo_run_document["status"] = TestStatus.RESULT_TEST_ISSUE
            self.mongo_run_document["result"][test_status] += 1
        self._save_test_collection()

    @staticmethod
    def _remove_dots_from_env_keys(variables: dict):
        new = {}
        for key, value in variables.items():
            new[key.replace('.', '-')] = value
        return new
