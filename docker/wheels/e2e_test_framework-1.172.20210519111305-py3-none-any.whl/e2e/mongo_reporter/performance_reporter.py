#
# INTEL CONFIDENTIAL
# Copyright (c) 2017 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
import socket
from datetime import datetime

from apscheduler.schedulers.background import BackgroundScheduler

from e2e import config
from e2e.mongo_reporter.base_reporter import BaseReporter, DEFAULT_ENVIRONMENT_NAME, TestStatus


class PerformanceReporter(BaseReporter):

    _TEST_COLLECTION_NAME = "performance_test_run"
    METRICS_INTERVAL = 10
    REQUIRED_METRICS = ['timestamp', 'cpu_usage_platform', 'memory_usage_platform']
    scheduler = None
    metrics_job = None

    def __init__(self, environment=DEFAULT_ENVIRONMENT_NAME, document_id=None):
        mongo_run_document = {
            "end_date": None,
            "environment": environment,
            "finished": False,
            "hatch_rate": config.hatch_rate,
            "infrastructure_type": config.infrastructure_type.value,
            "metrics": [],
            "number_of_users": config.num_clients,
            "start_date": datetime.now(),
            "started by": socket.gethostname(),
            "status": TestStatus.RESULT_UNKNOWN,

            # updated in separate methods
            "environment_version": None,
        }
        super().__init__(mongo_run_document, document_id=document_id)
        self.scheduler = BackgroundScheduler()

    def on_run_end(self, stats):
        mongo_performance_run_document = {
            "end_date": datetime.now(),
            "finished": True,
            "status": self._get_status(stats)
        }
        self._mongo_run_document.update(mongo_performance_run_document)
        self._save_test_collection()

    def report_version_number(self, version_number=None):
        self._mongo_run_document["environment_version"] = version_number
        self._save_test_collection()

    @staticmethod
    def _get_status(stats):
        stats = stats["stats"]
        total_stats = stats[-1]
        return TestStatus.RESULT_FAIL if int(total_stats["num_failures"]) else TestStatus.RESULT_PASS

    def start_gathering_metrics(self):
        if config.log_metrics_interval > 0:
            print('start gathering metrics')
            self.metrics_job = self.scheduler.add_job(self._get_metrics, 'interval',
                                                      seconds=config.log_metrics_interval)
            self.scheduler.start()

    def stop_gathering_metrics(self):
        if config.log_metrics_interval > 0:
            print('stop gathering metrics')
            if self.metrics_job:
                self.metrics_job.remove()

    def _get_metrics(self):
        print('Getting metrics from appliance')
        raise NotImplemented

    def _update_metrics(self, metrics):
        self._mongo_run_document['metrics'].append(metrics)
        self._save_test_collection()
