#
# INTEL CONFIDENTIAL
# Copyright (c) 2017 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
"""DBClient - abstraction of the MongoClient"""

from bson.objectid import ObjectId
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure
from retry import retry

from e2e.logger import get_logger

logger = get_logger(__name__)


class DBClient(object):
    """Abstraction of the MongoClient, that allows basic operations
       such as connect, insert, replace
    """

    def __init__(self, uri: str, ssl: bool = False):
        """
        uri: mongodb://<host>:<port>/<dbname>
        """
        self.client = MongoClient(host=uri, ssl=ssl)
        logger.debug("Verify MongoClient has connected {ssl}to: {uri}".format(ssl="using ssl " if ssl else "", uri=uri))
        self.check_connection()

        database_name = uri.split("/")[-1]
        self.database = self.client[database_name]

        nodes = ""
        for node in self.client.nodes:
            for node_data in node:
                nodes += str(node_data) + " "

        logger.debug("Connected to {} database on {}".format(database_name, nodes))

    def insert(self, collection_name, document) -> ObjectId:
        """Insert document to colletion of previously connected database

        Args:
            collection_name: collection where document will be recorded
            document: the document itself

        Returns:
            Id of the inserted document
        """
        result = self.database[collection_name].insert_one(document)
        logger.debug("Inserted document to {} with id {}".format(collection_name,
                                                                 result.inserted_id))
        return result.inserted_id

    def replace(self, collection_name: str, document_id: ObjectId, new_document: dict):
        """Replaces a document in a collection with a new one

        Args:
            collection_name: collection where document will be replaced
            document_id: old document id
            new_document: new document id
        """
        data_filter = {"_id": document_id}
        self.database[collection_name].replace_one(data_filter, new_document)
        logger.debug("Updated document to {} with id {}".format(collection_name, document_id))

    @retry(ConnectionFailure, tries=5, delay=1)
    def check_connection(self):
        """Verifies if we have connected to a mongo database

        Raises:
            ConnectionFailure
        """
        self.client.admin.command("ismaster")


class MockDbClient(object):
    """Used when database url is not configured"""
    def __init__(self, *args, **kwargs):
        pass

    def insert(self, *args, **kwargs):
        """Mocks document insertion"""
        pass

    def replace(self, *args, **kwarg):
        """Mocks document replacement"""
        pass
