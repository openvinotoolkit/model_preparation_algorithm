#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

import copy
import os
import socket
from unittest import mock

import pytest
from bson.objectid import ObjectId

from e2e.assertions import assert_date_close_enough_to_now
from e2e.constants.framework_constants import FrameworkMessages
from e2e.constants.infrastructure import InfrastructureType
from e2e.logging_filters import SensitiveKeysStrippingFilter
from e2e.mongo_reporter._client import MockDbClient
from e2e.mongo_reporter.base_reporter import BaseReporter, TestStatus
from e2e.mongo_reporter.performance_reporter import PerformanceReporter
from e2e.mongo_reporter.run_reporter import RunReporter
from e2e.mongo_reporter.result_reporter import ResultReporter

MOCK_BUMPVERSION_PATH = os.path.join("e2e", "mongo_reporter", "unittests", "fixtures", "mock_bumpversion")
assert os.path.isfile(MOCK_BUMPVERSION_PATH)
MOCK_BUMPVERSION_BAD_PATH = os.path.join("e2e", "mongo_reporter", "unittests", "fixtures", "mock_bumpversion_bad")
assert os.path.isfile(MOCK_BUMPVERSION_BAD_PATH)

TEST_RUN_ID = ObjectId()


class MockClient:
    def __init__(self, *args, **kwargs): pass
    insert = mock.Mock(return_value=TEST_RUN_ID)
    replace = mock.MagicMock(return_value=None)


class MockConfig:
    database_url = "test_uri"
    env_main = "default_environment"
    infrastructure_type = InfrastructureType.CLOUD
    test_session_version = "test_session_version"
    stress_run_id = ObjectId()
    hatch_rate = "test_hatch_rate"
    num_clients = "test_num_clients"
    test_build_log_url = "test_build_log_url"


MOCK_SUDO_PASSWORD = {
    'MOCKED_SUDO_PASSWORD': "MOCKED_PASSWORD"
}

MOCK_ENVIRONMENT = {
    'MOCKED_K8S_PROXY': 'https://proxy-mu.intel.com:912',
    'MOCKED_TEST_SESSION_BUILD_NUMBER': '200316030253',
    'MOCKED_PWD': '/home/GER/tester/test/project',
    'MOCKED_DISABLE_ENVIRONMENT_CHECK': 'True',
}

MOCK_ENVIRONMENT.update(MOCK_SUDO_PASSWORD)


TEST_COLLECTION_NAME = "test_collection"
TEST_VERSION = "test.version"


@mock.patch("e2e.mongo_reporter.base_reporter.DBClient", MockClient)
class TestBaseReporter(object):
    MockRunDocument = {"test_key": "test_value"}

    @mock.patch("e2e.mongo_reporter.base_reporter.BaseReporter._TEST_COLLECTION_NAME", TEST_COLLECTION_NAME)
    @mock.patch("e2e.mongo_reporter.base_reporter.config.database_url", "test_uri")
    def test_init_run_id_is_set(self):
        reporter = BaseReporter(self.MockRunDocument)
        assert reporter._document_id == TEST_RUN_ID

    @mock.patch("e2e.mongo_reporter.base_reporter.BaseReporter._TEST_COLLECTION_NAME", TEST_COLLECTION_NAME)
    @mock.patch("e2e.mongo_reporter.base_reporter.config.database_url", "test_uri")
    def test_init_database_url_set(self):
        reporter = BaseReporter(self.MockRunDocument)
        assert isinstance(reporter._db_client, MockClient)

    @mock.patch("e2e.mongo_reporter.base_reporter.BaseReporter._TEST_COLLECTION_NAME", TEST_COLLECTION_NAME)
    @mock.patch("e2e.mongo_reporter.base_reporter.config.database_url", None)
    def test_init_no_database_url(self):
        reporter = BaseReporter(self.MockRunDocument)
        assert isinstance(reporter._db_client, MockDbClient)

    @mock.patch("e2e.mongo_reporter.base_reporter.BaseReporter._TEST_COLLECTION_NAME", TEST_COLLECTION_NAME)
    def test_init_run_id(self):
        run_id = ObjectId()
        reporter = BaseReporter(self.MockRunDocument, document_id=run_id)
        assert reporter._document_id == run_id

    @mock.patch("e2e.mongo_reporter.base_reporter.BaseReporter._TEST_COLLECTION_NAME", TEST_COLLECTION_NAME)
    @mock.patch("e2e.mongo_reporter.base_reporter.config.database_url", "test_uri")
    @mock.patch.object(BaseReporter, "_save_test_collection")
    def test_init_save_run_document(self, mock_method):
        BaseReporter(self.MockRunDocument)
        mock_method.assert_any_call()

    @mock.patch("e2e.mongo_reporter.base_reporter.BaseReporter._TEST_COLLECTION_NAME", TEST_COLLECTION_NAME)
    def test_mongo_run_document(self):
        reporter = BaseReporter(self.MockRunDocument)
        assert reporter._mongo_run_document == self.MockRunDocument

    @mock.patch("e2e.mongo_reporter.base_reporter.BaseReporter._TEST_COLLECTION_NAME", TEST_COLLECTION_NAME)
    @mock.patch("e2e.mongo_reporter.base_reporter.config.database_url", "test_uri")
    def test_save_test_run(self):
        run_id = ObjectId()
        reporter = BaseReporter(self.MockRunDocument, document_id=run_id)
        expected_args = {'new_document': {'test_key': 'test_value'}, 'document_id': run_id,
                         'collection_name': TEST_COLLECTION_NAME}
        reporter._db_client.replace.assert_called_with(**expected_args)

    @mock.patch("e2e.mongo_reporter.base_reporter.config.database_url", "test_uri")
    def test_cannot_save_run_document_without_name(self):
        with pytest.raises(AssertionError):
            BaseReporter(self.MockRunDocument)


@mock.patch("e2e.mongo_reporter.base_reporter.DBClient", MockClient)
class TestPerformanceReporter(object):
    MockStats = None
    StatsPassed = {"stats": [{"num_failures": 0}]}
    StatsFailed = {"stats": [{"num_failures": 1}]}

    @mock.patch("e2e.mongo_reporter.performance_reporter.config", MockConfig)
    def test_init_run_document(self):
        run_document = PerformanceReporter()._mongo_run_document
        assert run_document["end_date"] is None
        assert run_document["environment"] == MockConfig.env_main
        assert run_document["environment_version"] is None
        assert run_document["finished"] is False
        assert run_document["hatch_rate"] == MockConfig.hatch_rate
        assert run_document["infrastructure_type"] == MockConfig.infrastructure_type.value
        assert run_document["number_of_users"] == MockConfig.num_clients
        assert_date_close_enough_to_now(run_document["start_date"])
        assert run_document["started by"] == socket.gethostname()
        assert run_document["status"] == TestStatus.RESULT_UNKNOWN

    @mock.patch("e2e.mongo_reporter.performance_reporter.PerformanceReporter._get_status",
                lambda *args, **kwargs: TestStatus.RESULT_PASS)
    def test_on_run_end(self):
        reporter = PerformanceReporter()
        document_before = copy.deepcopy(reporter._mongo_run_document)
        reporter.on_run_end(self.MockStats)
        document_after = reporter._mongo_run_document
        _assert_all_keys_equal_except(document_before, document_after, "end_date", "finished", "status")
        assert_date_close_enough_to_now(document_after["start_date"])
        assert document_after["status"] is TestStatus.RESULT_PASS
        assert document_after["finished"] is True

    @pytest.mark.parametrize("mock_stats, result", ((StatsPassed, TestStatus.RESULT_PASS),
                                                    (StatsFailed, TestStatus.RESULT_FAIL)))
    def test_get_stats(self, mock_stats, result):
        assert PerformanceReporter._get_status(mock_stats) == result

    def test_collection_name_is_not_none(self):
        reporter = PerformanceReporter()
        assert reporter._TEST_COLLECTION_NAME is not None


@mock.patch("e2e.mongo_reporter.base_reporter.DBClient", MockClient)
class TestRunReporter(object):

    @pytest.fixture(scope="function")
    def dummy_class(self):
        class Dummy:
            pass
        return Dummy

    @pytest.fixture(scope="function")
    def sensitive_instance_modification(self, request):
        copy_instance = SensitiveKeysStrippingFilter.instance
        SensitiveKeysStrippingFilter.instance = None

        def finalizer():
            SensitiveKeysStrippingFilter.instance = copy_instance
        return request.addfinalizer(finalizer)

    @pytest.fixture(scope="function")
    def mock_platform(self, monkeypatch):
        _mock_platform = mock.Mock()
        monkeypatch.setattr("e2e.base_info.BaseInfo.get", _mock_platform)
        monkeypatch.setattr("e2e.environment_info.config", MockConfig)
        return _mock_platform

    @mock.patch("e2e.mongo_reporter.run_reporter.config", MockConfig)
    @mock.patch("e2e.environment_info.config", MockConfig)
    @mock.patch.dict(os.environ, MOCK_ENVIRONMENT, clear=True)
    @mock.patch("e2e.mongo_reporter.run_reporter.SensitiveKeysStrippingFilter.gather_sensitive_pairs",
                mock.Mock(return_value=MOCK_SUDO_PASSWORD))
    @mock.patch("e2e.mongo_reporter.run_reporter.RunReporter._get_test_version",
                lambda *args, **kwargs: TEST_VERSION)
    def test_init_run_document(self, sensitive_instance_modification):
        sensitive_environment_variables = ['MOCKED_SUDO_PASSWORD']
        mask_str = '***<masked by logger>***'
        run_document = RunReporter()._mongo_run_document

        # values from config
        assert run_document["environment"] == MockConfig.env_main
        assert run_document["environment_version"] is None
        assert run_document["infrastructure_type"] == MockConfig.infrastructure_type.value
        assert run_document["stress_run_id"] == MockConfig.stress_run_id
        # other dynamic values
        assert_date_close_enough_to_now(run_document["start_date"])
        assert run_document["started_by"] == socket.gethostname()
        assert run_document["test_version"] == TEST_VERSION
        sensitive_environment_variables_masked = os.environ
        for variable in sensitive_environment_variables:
            if sensitive_environment_variables_masked.get(variable, None) is not None:
                sensitive_environment_variables_masked[variable] = mask_str

        for env, value in run_document["parameters"]["environment_variables"].items():
            assert env in sensitive_environment_variables_masked
            assert value in sensitive_environment_variables_masked[env]

        assert run_document["test_session_build_number"] is None
        # non-dynamic values
        assert_date_close_enough_to_now(run_document["start_date"])
        assert run_document["end_date"] is None
        assert run_document["finished"] is False
        assert run_document["logs"] == ""
        assert run_document["platform_components"] == []
        assert run_document["result"] == {TestStatus.RESULT_PASS: 0,
                                          TestStatus.RESULT_NOT_IMPLEMENTED: 0,
                                          TestStatus.RESULT_NEXT_VERSION: 0,
                                          TestStatus.RESULT_FAIL: 0,
                                          TestStatus.RESULT_SKIPPED: 0,
                                          TestStatus.RESULT_UNKNOWN: 0,
                                          TestStatus.RESULT_FEATURE_NOT_READY: 0,
                                          TestStatus.RESULT_TEST_ISSUE: 0}
        assert run_document["status"] == TestStatus.RESULT_PASS
        assert run_document["test_count"] == 0
        assert run_document["total_test_count"] == 0
        assert run_document["components"] == []
        assert run_document["environment_availability"] is True
        assert run_document["test_type"] is None

    def test_report_components(self):
        test_components = ["a", "b", "c"]
        reporter = RunReporter()
        document_before = copy.deepcopy(reporter._mongo_run_document)
        reporter.report_components(test_components)
        document_after = reporter._mongo_run_document
        _assert_all_keys_equal_except(document_before, document_after, "components")
        assert sorted(document_after["components"]) == sorted(test_components)

    def test_report_test_type(self):
        reporter = RunReporter()
        document_before = copy.deepcopy(reporter._mongo_run_document)
        reporter.report_test_type("api_smoke")
        document_after = reporter._mongo_run_document
        _assert_all_keys_equal_except(document_before, document_after, "test_type")
        assert reporter._mongo_run_document["test_type"] == "api_smoke"

    def test_report_unavailable_environment(self):
        reporter = RunReporter()
        document_before = copy.deepcopy(reporter._mongo_run_document)
        reporter.report_unavailable_environment()
        document_after = reporter._mongo_run_document
        _assert_all_keys_equal_except(document_before, document_after, "environment_availability", "end_date",
                                      "finished")
        assert document_after["environment_availability"] is False
        assert_date_close_enough_to_now(document_after["end_date"])
        assert document_after["finished"] is True

    def test_on_run_end(self):
        test_count = 123
        reporter = RunReporter()
        document_before = copy.deepcopy(reporter._mongo_run_document)
        reporter._total_test_counter = test_count
        reporter.on_run_end()
        document_after = reporter._mongo_run_document
        _assert_all_keys_equal_except(document_before, document_after, "end_date", "total_test_count", "finished")
        assert_date_close_enough_to_now(document_after["start_date"])
        assert document_after["total_test_count"] == test_count
        assert document_after["finished"] is True

    @mock.patch("e2e.mongo_reporter.run_reporter.Path.bumpversion_file", MOCK_BUMPVERSION_PATH)
    def test_get_test_version(self):
        version = RunReporter._get_test_version()
        assert version == "test.version"

    @mock.patch("e2e.mongo_reporter.run_reporter.Path.bumpversion_file", "idontexist")
    def test_get_test_version_missing_bumpversion_file(self):
        version = RunReporter._get_test_version()
        assert version == "0.0.1"

    @mock.patch("e2e.mongo_reporter.run_reporter.Path.bumpversion_file", MOCK_BUMPVERSION_BAD_PATH)
    def test_get_test_version_bad_file(self):
        with pytest.raises(AssertionError) as e:
            RunReporter._get_test_version()
        assert "Version not found" in str(e.value)

    def test_marker_args_from_item_no_args(self, dummy_class):
        class ItemMock:
            @staticmethod
            def get_closest_marker(cls, **kwargs):
                return dummy_class
        args = ResultReporter._marker_args_from_item(ItemMock(), "name")
        assert args == tuple()

    TEST_ARGS = ("a", "b", "c")

    def test_marker_args_from_item(self, dummy_class):
        class ItemMock:
            @staticmethod
            def get_closest_marker(cls, **kwargs):
                dummy_class.args = self.TEST_ARGS
                return dummy_class
        args = ResultReporter._marker_args_from_item(ItemMock(), "name")
        assert args == self.TEST_ARGS

    @pytest.mark.parametrize("keywords,expected_priority", [(("abc", "def"), None),
                                                            (("abc", "priority_kitten"), "kitten")],
                             ids=("no-priority-set", "priority_kitten"))
    def test_priority_from_report(self, dummy_class, keywords, expected_priority):
        dummy_class.keywords = keywords
        priority = ResultReporter._priority_from_report(dummy_class)
        assert priority == expected_priority

    def test_stacktrace_from_report_no_stacktrace(self, dummy_class):
        class Report:
            longrepr = dummy_class
        stacktrace = ResultReporter._stacktrace_from_report(Report())
        assert stacktrace == ""

    TEST_STACKTRACE = "test_stacktrace"

    def test_stacktrace_from_report(self, dummy_class):
        class Report:
            dummy_class.reprtraceback = self.TEST_STACKTRACE
            longrepr = dummy_class
        stacktrace = ResultReporter._stacktrace_from_report(Report())
        assert stacktrace == self.TEST_STACKTRACE

    @pytest.mark.parametrize("report_attr_true,expected_test_status",
                             [("passed", TestStatus.RESULT_PASS),
                              ("failed", TestStatus.RESULT_FAIL),
                              ("skipped", TestStatus.RESULT_SKIPPED),
                              ("other", TestStatus.RESULT_UNKNOWN)],
                             ids=("pass", "fail", "skip", "unknown"))
    def test_test_status_from_report(self, dummy_class, report_attr_true, expected_test_status):
        for attr_name in ("passed", "failed", "skipped", "other"):
            setattr(dummy_class, attr_name, False)
        setattr(dummy_class, report_attr_true, True)
        setattr(dummy_class, "longreprtext", "Skipped")

        class Dummy:
            pass

        def _get_closest_marker(arg):
            return expected_test_status

        item = Dummy()
        setattr(item, "get_closest_marker", _get_closest_marker)

        test_status = ResultReporter._test_status_from_report(dummy_class, item)
        assert test_status == expected_test_status

    def test_test_status_from_report_not_implemented(self, dummy_class):
        for attr_name in ("passed", "failed", "other"):
            setattr(dummy_class, attr_name, False)
        setattr(dummy_class, "skipped", True)

        class Dummy:
            pass

        kwargs = Dummy()

        def kwargs_get(arg):
            return FrameworkMessages.NOT_IMPLEMENTED
        setattr(kwargs, "get", kwargs_get)

        skip_marker = Dummy()
        setattr(skip_marker, "kwargs", kwargs)

        def _get_closest_marker(arg):
            return skip_marker

        item = Dummy()
        setattr(item, "get_closest_marker", _get_closest_marker)

        test_status = ResultReporter._test_status_from_report(dummy_class, item)
        assert test_status == TestStatus.RESULT_NOT_IMPLEMENTED

    @pytest.mark.parametrize("run_status,test_status,expected_run_status",
                             [(TestStatus.RESULT_PASS, TestStatus.RESULT_PASS,
                               TestStatus.RESULT_PASS),
                              (TestStatus.RESULT_PASS, TestStatus.RESULT_NOT_IMPLEMENTED,
                               TestStatus.RESULT_PASS),
                              (TestStatus.RESULT_FAIL, TestStatus.RESULT_NOT_IMPLEMENTED,
                               TestStatus.RESULT_FAIL),
                              (TestStatus.RESULT_PASS, TestStatus.RESULT_FAIL,
                               TestStatus.RESULT_FAIL),
                              (TestStatus.RESULT_FAIL, TestStatus.RESULT_PASS,
                               TestStatus.RESULT_FAIL),
                              (TestStatus.RESULT_PASS, TestStatus.RESULT_SKIPPED,
                               TestStatus.RESULT_PASS),
                              (TestStatus.RESULT_PASS, TestStatus.RESULT_UNKNOWN,
                               TestStatus.RESULT_PASS)])
    def test_update_run_status(self, run_status, test_status, expected_run_status):
        reporter = RunReporter()
        reporter._mongo_run_document["status"] = run_status
        run_document_before = copy.deepcopy(reporter._mongo_run_document)
        reporter.update_run_status(test_status=test_status, new_tests=0)
        run_document_after = reporter._mongo_run_document
        _assert_all_keys_equal_except(run_document_before, run_document_after, "status", "result", "test_count")
        assert run_document_after["status"] == expected_run_status
        assert run_document_after["result"][test_status] == run_document_before["result"][test_status] + 1

    def test_save_test_run_no_run_id(self):
        reporter = RunReporter()
        reporter._document_id = None
        with mock.patch.object(reporter._db_client, "insert", mock.Mock()) as mock_insert:
            reporter._save_test_collection()
        mock_insert.assert_called_once_with(collection_name=RunReporter._TEST_COLLECTION_NAME,
                                            document=reporter._mongo_run_document)

    def test_save_test_run_run_id(self):
        reporter = RunReporter(document_id=ObjectId())
        with mock.patch.object(reporter._db_client, "replace", mock.Mock()) as mock_replace:
            reporter._save_test_collection()
        mock_replace.assert_called_once_with(collection_name=RunReporter._TEST_COLLECTION_NAME,
                                             document_id=reporter._document_id, new_document=reporter._mongo_run_document)

    def test_collection_name_is_not_none(self):
        reporter = RunReporter()
        assert reporter._TEST_COLLECTION_NAME is not None


def _assert_all_keys_equal_except(document_a: dict, document_b: dict, *args):
    for k, v in document_a.items():
        if k not in args:
            assert v == document_b[k], "Value of {} key changed".format(k)
