#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

import copy
from unittest import mock

import bson
import mongomock

import pytest

from e2e.markers import MarkGeneral
from e2e.mongo_reporter.base_reporter import TestStatus
from e2e.mongo_reporter.run_reporter import RunReporter
from e2e.mongo_reporter.result_reporter import ResultReporter, STAGE
from e2e.mongo_reporter._client import DBClient


class Dummy:
    pass


TEST_DOCSTRING = "test-docstring"
TEST_COMPONENTS = ("abc", "def")
TEST_DEFECTS = ("lorem", "ipsum")
TEST_REQIDS = ("req1", "req2")
TEST_LOG = "test-log"
TEST_PRIORITY = "test-priority"
TEST_KEYWORDS = ("a", "b", "c")
TEST_RUN_ID = bson.ObjectId()
TEST_STACKTRACE = "test-stacktrace"
TEST_TEST_COUNT = 14
TEST_STATUS = "PASS"
TEST_TEST_TYPE = "api_smoke"
TEST_ITEM_LOCATION = ('test', '35', 'TestExample.unit_test')
item = Dummy()
report = Dummy()
report.nodeid = "test-name"
report.when = "call"
report.caplog = TEST_LOG
report.duration = 0.123
report.keywords = TEST_KEYWORDS
report.longrepr = Dummy()
report.longrepr.reprtraceback = TEST_STACKTRACE
item.start_date = 0
item.end_date = 0.123
item.nodeid = "test_system"
item.location = TEST_ITEM_LOCATION
item.keywords = Dummy()
item.keywords.node = Dummy()
item.keywords.node.instance = Dummy()
item.keywords.node.instance.PERFORMANCE_RESULTS = None


def _markers_get(arg):
    return "api_smoke" if arg == "api_smoke" else None


setattr(item, "get_closest_marker", _markers_get)

TEST_COMMON_REPORT = {
    "components": TEST_COMPONENTS,
    "docstring": TEST_DOCSTRING,
    "defects": TEST_DEFECTS,
    "priority": TEST_PRIORITY,
    "tags": ", ".join(TEST_KEYWORDS),
    "logs": "",
    "run_id": TEST_RUN_ID,
    "stacktrace": TEST_STACKTRACE,
    "test_type": TEST_TEST_TYPE
}


def _bugs_from_item(self, item, test_case):
    return TEST_DEFECTS


def _marker_args_from_item(self, item_ignored, marker_name):
    if marker_name == MarkGeneral.COMPONENTS:
        return TEST_COMPONENTS
    elif marker_name == MarkGeneral.REQIDS:
        return TEST_REQIDS


@mock.patch.multiple("e2e.mongo_reporter.run_reporter.ResultReporter",
                     _get_test_docstring=lambda *args, **kwargs: TEST_DOCSTRING,
                     _marker_args_from_item=_marker_args_from_item,
                     _bugs_from_item=_bugs_from_item,
                     _priority_from_report=lambda *args, **kwargs: TEST_PRIORITY,
                     _stacktrace_from_report=lambda *args, **kwargs: TEST_STACKTRACE)
class TestReporterTestDocument:

    @pytest.fixture(scope="function")
    def mock_db_client(self):
        class MockClient(DBClient):
            def __init__(self, *args, **kwargs):
                self.database = mongomock.MongoClient().db
        return MockClient

    @staticmethod
    def _get_test_result_documents(reporter):
        return [d for d in reporter.result_reporter._db_client.database[ResultReporter._TEST_COLLECTION_NAME].find()]

    def test_on_test(self):
        reporter = RunReporter(document_id=TEST_RUN_ID)
        report.passed = True
        report.failed = not report.passed
        test_document, status = reporter.result_reporter._on_test(report=report, item=item, order=TEST_TEST_COUNT)
        assert status == TEST_STATUS
        assert set(TEST_COMMON_REPORT.items()).issubset(set(test_document.items()))
        assert test_document["status"] == TEST_STATUS

        assert test_document["duration"] == report.duration
        assert test_document["name"] == item.nodeid
        assert test_document["order"] == TEST_TEST_COUNT

    def test_on_fixture_error(self):
        reporter = RunReporter(document_id=TEST_RUN_ID)
        report.failed = False
        test_document, status = reporter.result_reporter._on_fixture_error(report=report, item=item)
        assert status == TestStatus.RESULT_FAIL
        assert set(TEST_COMMON_REPORT.items()).issubset(set(test_document.items()))
        assert test_document["status"] == TestStatus.RESULT_FAIL
        assert test_document["name"] == item.nodeid
        assert test_document["stage"] == STAGE[report.when]

    def test_on_fixture_skipped(self):
        reporter = RunReporter(document_id=TEST_RUN_ID)
        report.failed = False
        test_document, status = reporter.result_reporter._on_fixture_skipped(report=report, item=item)
        assert status == TestStatus.RESULT_SKIPPED
        assert set(TEST_COMMON_REPORT.items()).issubset(set(test_document.items()))
        assert test_document["name"] == item.nodeid
        assert test_document["stage"] == STAGE[report.when]
        assert test_document["status"] == status

    @pytest.mark.parametrize("report_passed,report_failed,report_skipped,expected_status",
                             [(True, False, False, TestStatus.RESULT_PASS), (False, True, False,
                                                                             TestStatus.RESULT_FAIL),
                              (False, False, True, TestStatus.RESULT_SKIPPED)],
                             ids=("report_passed", "report_failed", "report_skipped"))
    @mock.patch("e2e.mongo_reporter.run_reporter.config.database_url", "test_uri")
    def test_log_report_on_call(self, mock_db_client, report_passed, report_failed, report_skipped, expected_status):
        report.when = "call"
        report.passed = report_passed
        report.failed = report_failed
        report.skipped = report_skipped
        report.caplog = TEST_LOG
        if report_skipped:
            report.longreprtext = "Skipped"

        with mock.patch("e2e.mongo_reporter.base_reporter.DBClient", mock_db_client):
            reporter = RunReporter()
            run_document_before = copy.deepcopy(reporter._mongo_run_document)
            item.document_id = None
            reporter.log_report(report=report, item=item)
            run_document_after = reporter._mongo_run_document
            assert run_document_after["test_count"] == run_document_before["test_count"] + 1
            test_documents = self._get_test_result_documents(reporter)
            assert len(test_documents) == 1
            assert test_documents[0]["name"] == item.nodeid
            assert test_documents[0]["status"] == expected_status

    @pytest.mark.parametrize(
        "report_when,report_passed,report_failed,report_skipped,expected_test_status",
        [("setup", False, True, False, TestStatus.RESULT_FAIL),
         ("setup", False, False, True, TestStatus.RESULT_SKIPPED),
         ("teardown", False, True, False, TestStatus.RESULT_FAIL),
         ("teardown", False, False, True, TestStatus.RESULT_SKIPPED)],
        ids=("on_setup_report_error", "on_setup_report_skipped",
             "on_teardown_report_failed", "on_teardown_report_skipped"))
    @mock.patch("e2e.mongo_reporter.run_reporter.config.database_url", "test_uri")
    def test_log_report_on_fixture_one_document(self, mock_db_client, report_when, report_passed, report_failed,
                                                report_skipped, expected_test_status):
        report.when = report_when
        report.passed = report_passed
        report.failed = report_failed
        report.skipped = report_skipped
        report.caplog = TEST_LOG

        with mock.patch("e2e.mongo_reporter.base_reporter.DBClient", mock_db_client):
            reporter = RunReporter()
            run_document_before = copy.deepcopy(reporter._mongo_run_document)
            item.document_id = None
            reporter.log_report(report=report, item=item)
            run_document_after = reporter._mongo_run_document
            assert run_document_after["test_count"] == run_document_before["test_count"] + 1
            if expected_test_status == TestStatus.RESULT_FAIL:
                assert run_document_after["status"] == TestStatus.RESULT_FAIL
            else:
                assert run_document_after["status"] == run_document_before["status"]
            test_documents = self._get_test_result_documents(reporter)
            assert len(test_documents) == 1
            assert test_documents[0]["name"] == item.nodeid
            assert test_documents[0]["stage"] == STAGE[report.when]

            if report_skipped:
                assert test_documents[0]["status"] == TestStatus.RESULT_SKIPPED
            else:
                assert test_documents[0]["status"] == TestStatus.RESULT_FAIL

    @mock.patch("e2e.mongo_reporter.run_reporter.config.database_url", "test_uri")
    def test_log_report_no_update_on_teardown_report_passed(self, mock_db_client):
        report.when = "teardown"
        report.passed = True
        report.failed = False
        report.skipped = False
        report.caplog = TEST_LOG

        with mock.patch("e2e.mongo_reporter.base_reporter.DBClient", mock_db_client):
            reporter = RunReporter()
            run_document_before = copy.deepcopy(reporter._mongo_run_document)
            reporter.log_report(report=report, item=item)
            run_document_after = reporter._mongo_run_document
            assert run_document_after == run_document_before
            test_documents = self._get_test_result_documents(reporter)
            assert len(test_documents) == 0

    @mock.patch("e2e.mongo_reporter.run_reporter.config.database_url", "test_uri")
    def test_log_report_two_documents(self, mock_db_client):
        report.when = "setup"
        report.passed = False
        report.failed = True
        report.skipped = False
        report.caplog = TEST_LOG

        with mock.patch("e2e.mongo_reporter.base_reporter.DBClient", mock_db_client):
            reporter = RunReporter()
            run_document_before = copy.deepcopy(reporter._mongo_run_document)
            reporter.log_report(report=report, item=item)
            run_document_after = reporter._mongo_run_document
            assert run_document_after["test_count"] == run_document_before["test_count"] + 1
            test_documents = self._get_test_result_documents(reporter)
            assert len(test_documents) == 1
            fixture_document = next((d for d in test_documents if d["status"] == TestStatus.RESULT_FAIL), None)
            assert fixture_document is not None
            assert fixture_document["name"] == item.nodeid
            assert fixture_document["stage"] == STAGE[report.when]
