#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#

import time
from datetime import datetime
from requests import PreparedRequest
from typing import Optional
from unittest import mock
from unittest.mock import Mock

from bson.objectid import ObjectId

from e2e.assertions import assert_date_close_enough_to_now, \
    assert_values_approximately_equal
from e2e.constants.infrastructure import InfrastructureType
from e2e.mongo_reporter._client import MockDbClient
from e2e.mongo_reporter.request_reporter import RequestReporter, log_request, request_reporter
from e2e.logger import get_logger

logger = get_logger(__name__)

SELF = mock.Mock()
TIMEOUT = 1
DURATION = .5
TEST_NAME = 'test_name'
TEST_RESULT_ID = str(ObjectId())
TEST_STRESS_RUN_ID = str(ObjectId())


class MockRequest:
    method = 'GET'
    path_url = '/stairways/to/{heaven}'
    path_params = {'heaven': 'heaven'}


TEST_NEW_REQUEST_INFO = {
    'date': datetime.now(),
    'method': MockRequest.method,
    'status_code': 200,
    'url': MockRequest.path_url,
    'url_params': MockRequest.path_params
}

TEST_REQUEST_INFO = dict(TEST_NEW_REQUEST_INFO, stress_run_id=TEST_STRESS_RUN_ID)
TEST_REQUEST_INFO_IN_DB = dict(TEST_REQUEST_INFO, test_name=TEST_NAME, result_id=TEST_RESULT_ID)


class MockConfig:
    def __init__(self, database_url: Optional[str] = 'db_url',
                 stress_run_id: Optional[str] = TEST_STRESS_RUN_ID, log_requests: bool = True):
        self.database_url = database_url
        self.database_ssl = False
        self.stress_run_id = stress_run_id
        self.log_requests = log_requests
        self.test_domain = "test-domain"
        self.infrastructure_type = InfrastructureType.CLOUD
        self.test_session_version = "test_session_version"
        self.kerberos = "test_kerberos"
        self.hatch_rate = "test_hatch_rate"
        self.num_clients = "test_num_clients"


@mock.patch('e2e.mongo_reporter.request_reporter.config', MockConfig())
class TestRequestReporter(object):
    """Tests the request reporter"""

    @mock.patch('e2e.mongo_reporter.request_reporter.DBClient')
    def test_collection_name_is_not_none(self, mock_db_client):
        """Verifies there is no empty collection"""
        mock_db_client.return_value = mock_db_client
        reporter = RequestReporter()
        assert reporter.COLLECTION_NAME == 'request', 'RequestReporter has no specified collection name'

    @mock.patch('e2e.mongo_reporter.request_reporter.DBClient')
    def test_request_list_should_be_initialized_empty(self, mock_db_client):
        """Verifies that the initialized list is not empty"""
        mock_db_client.return_value = mock_db_client
        reporter = RequestReporter()
        assert len(reporter.requests) == 0, 'RequestReporter are initialized with non empty requests list'

    def test_use_mock_client_if_no_db_url(self):
        with mock.patch('e2e.mongo_reporter.request_reporter.config', MockConfig(database_url=None)):
            reporter = RequestReporter()
            assert isinstance(reporter._db_client, MockDbClient), \
                'RequestReporter should use MockDbClient if no db url provided'

    def test_use_mock_client_if_no_stress_run_id(self):
        with mock.patch('e2e.mongo_reporter.request_reporter.config', MockConfig(stress_run_id=None)):
            reporter = RequestReporter()
            assert isinstance(reporter._db_client, MockDbClient), \
                'RequestReporter should use MockDbClient if no stress run id provided'

    def test_use_mock_client_if_log_requests_is_false(self):
        """Verifies proper flag in config is et"""
        with mock.patch('e2e.mongo_reporter.request_reporter.config', MockConfig(log_requests=False)):
            reporter = RequestReporter()
            assert isinstance(reporter._db_client, MockDbClient), \
                'RequestReporter should use MockDbClient if PT_LOG_REQUESTS flag is not set'

    @mock.patch('e2e.mongo_reporter.request_reporter.DBClient')
    def test_add_request(self, mock_db_client):
        mock_db_client.return_value = mock_db_client
        reporter = RequestReporter()
        reporter.add_request(TEST_NEW_REQUEST_INFO)
        assert len(reporter.requests) == 1, "Request isn't logged to RequestReporter"
        assert reporter.requests[0] == TEST_REQUEST_INFO, \
            'RequestReporter assign incorrect stress run id to request info'

    @mock.patch('e2e.mongo_reporter.request_reporter.DBClient')
    def test_send_to_db(self, mock_db_client):
        mock_db_client.return_value = mock_db_client
        reporter = RequestReporter()
        reporter.add_request(TEST_NEW_REQUEST_INFO)
        reporter.send_to_db(test_name=TEST_NAME, result_document_id=TEST_RESULT_ID)
        mock_db_client.insert.assert_called_once_with(collection_name='request', document=TEST_REQUEST_INFO_IN_DB)

    @mock.patch('e2e.mongo_reporter.request_reporter.DBClient')
    def test_clean_request_lists_after_sending_to_db(self, mock_db_client):
        mock_db_client.return_value = mock_db_client
        reporter = RequestReporter()
        reporter.add_request(TEST_NEW_REQUEST_INFO)
        assert len(reporter.requests) == 1, "Request isn't logged to RequestReporter"
        reporter.send_to_db(test_name=TEST_NAME, result_document_id=TEST_RESULT_ID)
        assert len(reporter.requests) == 0, 'RequestReporter.send_to_db() not clean RequestReporter.requests list'

    @mock.patch('e2e.mongo_reporter.request_reporter.DBClient')
    def test_send_no_request_info_if_no_request_logged(self, mock_db_client):
        mock_db_client.return_value = mock_db_client
        reporter = RequestReporter()
        reporter.send_to_db(test_name=TEST_NAME, result_document_id=TEST_RESULT_ID)
        assert mock_db_client.insert.call_count == 0


def mock_function(self, request: PreparedRequest, timeout: int):
    logger.info("Mock called by: {} with timeout".format(self, str(timeout)))
    time.sleep(DURATION)
    response = Mock()
    response.request = request
    response.status_code = TEST_NEW_REQUEST_INFO['status_code']
    return response


@mock.patch('e2e.mongo_reporter.request_reporter.config', MockConfig())
def test_log_request_decorator():
    request_reporter.requests = []

    decorated_func = log_request(mock_function)
    decorated_func(self='self',
                   request=MockRequest,
                   path=MockRequest.path_url,
                   path_params=MockRequest.path_params,
                   timeout=TIMEOUT)

    assert len(request_reporter.requests) == 1, '@log_request does not add request to request_report'

    logged_request = request_reporter.requests[0]

    assert_date_close_enough_to_now(logged_request['date'], epsilon=.8)
    assert_values_approximately_equal(logged_request['duration'], DURATION, epsilon=.5)
    assert logged_request['method'] == TEST_REQUEST_INFO['method']
    assert logged_request['status_code'] == TEST_REQUEST_INFO['status_code']
    assert logged_request['stress_run_id'] == TEST_REQUEST_INFO['stress_run_id']
    assert logged_request['url'] == TEST_REQUEST_INFO['url']
    assert logged_request['url_params'] == TEST_REQUEST_INFO['url_params']
