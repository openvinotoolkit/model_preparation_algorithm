#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
"""Unit tests for DBClient functionality"""
from bson.objectid import ObjectId
from unittest import mock

from e2e.mongo_reporter import _client

# This a mocked retrievable document from mongodb
EXAMPLE_DOCUMENT = "Some document"


class Result:
    """Mock of result class, that has some predefined document id"""
    def __init__(self):
        self.inserted_id = ObjectId("543b591d91b9e510a06a42e2")


# Mock of the mongo collection class. It just returns one result
collection_mongo_mock = mock.MagicMock()
collection_mongo_mock.insert_one.return_value = Result()
collection_mongo_mock.find.return_value = [EXAMPLE_DOCUMENT]
# Mock of the mongo database, that can only return one collection
database_mongo_mock = mock.MagicMock()
database_mongo_mock.__getitem__.return_value = collection_mongo_mock
# Basic mongo client (mock)
basic_mongo_mock = mock.MagicMock()
basic_mongo_mock.__getitem__.return_value = database_mongo_mock


class TestMongoClient:
    """Basic client test suite"""
    test_document = {"hello": "kitty", "int": 1, "bool": True, "none": None}
    test_db_name = "test_db"
    test_collection_name = "test_collection"
    uri = "mongodb://mockmongo:1234/{}".format(test_db_name)

    @mock.patch("e2e.mongo_reporter._client.MongoClient")
    def test_init(self, mongo_mock):
        """Verify that the DBClient checks the connection"""
        mongo_mock.return_value = basic_mongo_mock
        _client.DBClient(uri=self.uri)

        basic_mongo_mock.admin.command.assert_called_with("ismaster")
        assert basic_mongo_mock.admin.command.call_count == 1

    @mock.patch("e2e.mongo_reporter._client.MongoClient")
    def test_insert(self, mongo_mock):
        """Insert a document to mocked mongo database
        and attempts to retrieve it"""
        # Initialize mongo client
        mongo_mock.return_value = basic_mongo_mock
        db_client = _client.DBClient(uri=self.uri)

        # Create a document and insert it
        test_document = self.test_document.copy()
        document_id = db_client.insert(collection_name=self.test_collection_name,
                                       document=test_document)

        # Verify proper database was retrieved
        assert database_mongo_mock.__getitem__.call_count == 1
        assert database_mongo_mock.__getitem__.call_args[0] == (self.test_collection_name,)

        # Verify insertion method was called
        assert collection_mongo_mock.insert_one.call_count == 1
        assert collection_mongo_mock.insert_one.call_args[0] == (test_document,)

        # Verify ObjectId is returned
        assert isinstance(document_id, ObjectId)

        # Now replace the document
        db_client.replace(collection_name=self.test_collection_name, document_id=document_id,
                          new_document=test_document)

        # Verify proper database was retrieved
        assert database_mongo_mock.__getitem__.call_count == 2
        assert database_mongo_mock.__getitem__.call_args[0] == (self.test_collection_name,)

        # Verify replace method was called
        assert collection_mongo_mock.replace_one.call_count == 1
        assert collection_mongo_mock.replace_one.call_args[0] == ({"_id": document_id},
                                                                  test_document,)
