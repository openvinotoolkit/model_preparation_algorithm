#
# Copyright (c) 2018-2020 Intel Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import json
from google.protobuf.json_format import MessageToJson
import grpc
import numpy as np

from tensorflow.compat.v1 import make_tensor_proto, make_ndarray
from tensorflow_serving.apis import predict_pb2
from tensorflow_serving.apis import prediction_service_pb2_grpc, model_service_pb2_grpc
from tensorflow_serving.apis import get_model_metadata_pb2, get_model_status_pb2

from e2e.assertions import assert_raises_grpc_exception
from e2e.constants.grpc_error_codes import GrpcErrorCode
from e2e.logger import get_logger
from e2e.ssl_certificates import SslCertificates

GRPC_TIMEOUT = 60
GRPC = "grpc"

logger = get_logger(__name__)


class InferenceClient:
    NOT_FOUND = GrpcErrorCode.NOT_FOUND
    INVALID_ARGUMENT = GrpcErrorCode.INVALID_ARGUMENT
    INTERNAL = GrpcErrorCode.INTERNAL
    ABORTED = GrpcErrorCode.ABORTED
    RESOURCE_EXHAUSTED = GrpcErrorCode.RESOURCE_EXHAUSTED
    FAILED_PRECONDITION = GrpcErrorCode.FAILED_PRECONDITION
    UNAVAILABLE = GrpcErrorCode.UNAVAILABLE
    ALREADY_EXISTS = GrpcErrorCode.ALREADY_EXISTS
    _default_certs = None

    @staticmethod
    def assert_raises_exception(status, error_message_phrase, callable_obj, *args, **kwargs):
        return assert_raises_grpc_exception(status, error_message_phrase, callable_obj, *args, **kwargs)

    def __init__(self, address: str, port: str, model_name: str, batch_size: str, input_data_types: dict = None,
                 input_names: list = None, output_names: list = None, output_data_types: dict = None,
                 model_version: str = None, model_meta_from_serving: bool = True,
                 ssl_certificates: SslCertificates = None):
        self.prediction_service = None
        self.model_service = None
        self.url = "{}:{}".format(address, port)
        self.model_name = model_name
        self.model_version = model_version
        self.batch_size = batch_size
        self.input_names = input_names
        self.input_dims = None
        self.input_data_types = input_data_types
        self.output_names = output_names
        self.output_dims = None
        self.output_data_types = output_data_types
        self.protocol = None
        self.input_dims = None
        self.model_meta_from_serving = model_meta_from_serving
        self.ssl_certificates = ssl_certificates if ssl_certificates is not None else self._default_certs

    def create_inference(self):
        raise NotImplementedError

    def prepare_request(self, input_objects: dict):
        raise NotImplementedError

    def get_model_status(self):
        raise NotImplementedError()

    def validate_status(self, model, status):
        to_check = status.model_version_status[0]
        assert model.version == to_check.version, f"Unexpected version (detected: {to_check.version}, expected: "\
                                                  f"{model.version})"
        expected_res = get_model_status_pb2.ModelVersionStatus.State.AVAILABLE
        state_map = get_model_status_pb2.ModelVersionStatus.State.items()
        assert to_check.state == expected_res, f"Unexpected state (detected: {to_check.state}, expected "\
                                               f"{expected_res} - map: {state_map})"
        assert to_check.status.error_message == 'OK', f"Unexpected error msg (detected: "\
                                                      f"{to_check.status.error_message}, expected: OK"

    def get_and_validate_status(self, model):
        status = self.get_model_status()
        self.validate_status(model, status)
        return status

    def get_model_meta(self):
        raise NotImplementedError()

    def validate_meta(self, model, meta):
        json_data = json.loads(MessageToJson(meta))

        assert meta.model_spec.name == model.name, f"Unexpected model name (expected: {model.name}, detected: "\
                                                   f"{meta.model_spec.name})"
        assert meta.model_spec.version.value == model.version
        assert "signature_def" in meta.metadata
        assert meta.metadata['signature_def'].type_url == 'type.googleapis.com/tensorflow.serving.SignatureDefMap'

        def cast_type_to_string(data_type):
            if data_type == np.float32:
                result = 'DT_FLOAT'
            elif data_type == np.int32:
                result = 'DT_INT32'
            else:
                raise NotImplementedError()
            return result

        def validate(test_data, val_shapes, val_types):
            assert len(test_data) == len(val_shapes), f"Unexpected argument list (shapes; expect: {len(val_shapes)}, "\
                                                      f"detect: {len(test_data)})"
            assert len(test_data) == len(val_types), f"Unexpected argument list (shapes; expect: {len(val_types)}, "\
                                                     f"detect: {len(test_data)})"
            for arg_name, arg_data in test_data.items():
                for test, val_dim in zip(arg_data['tensorShape']['dim'], val_shapes[arg_name]):
                    assert int(test['size']) == val_dim, \
                        f"Unexpected shape (expected: {val_shapes[arg_name]}, detected: "\
                        f"{arg_data['tensorShape']['dim']})"
                val_type = cast_type_to_string(val_types[arg_name])
                assert arg_data['dtype'] == val_type, f"Unexpected type (expected: {val_type}, detected: "\
                                                      f"{arg_data['dtype']}"

        data = json_data['metadata']['signature_def']['signatureDef']['serving_default']
        validate(test_data=data['inputs'], val_shapes=model.input_shapes, val_types=model.input_types)
        validate(test_data=data['outputs'], val_shapes=model.output_shapes, val_types=model.output_types)

    def get_and_validate_meta(self, model):
        meta = self.get_model_meta()
        self.validate_meta(model, meta)
        return meta

    def predict(self, request, timeout):
        raise NotImplementedError

    def prepare_stateful_request(self, input_objects: dict, sequence_ctrl=None, sequence_id=None):
        raise NotImplementedError()

    def predict_stateful_request(self, request, timeout):
        raise NotImplementedError()

    def prepare_and_predict_stateful_request(self, input_objects: dict, sequence_ctrl=None, sequence_id=None,
                                             timeout=900):
        request = self.prepare_stateful_request(input_objects, sequence_ctrl, sequence_id)
        return self.predict_stateful_request(request, timeout)

    @staticmethod
    def get_data_type(data_type):
        result = None
        if data_type == 6:
            result = np.int8
        elif data_type == 3:
            result = np.int32
        elif data_type == 1:
            result = np.float32
        return result


class InferenceClientTFS(InferenceClient):
    type = GRPC

    def create_inference(self):
        options = [('grpc.max_message_length', 100 * 1024 * 1024),
                   ('grpc.max_send_message_length ', 100 * 1024 * 1024),
                   ('grpc.max_receive_message_length', 100 * 1024 * 1024)]

        if self.ssl_certificates is not None:
            creds = self.ssl_certificates.get_grpc_ssl_channel_credentials()
            channel = grpc.secure_channel(target=self.url, options=options, credentials=creds)
        else:
            channel = grpc.insecure_channel(self.url, options=options)

        self.prediction_service = prediction_service_pb2_grpc.PredictionServiceStub(channel)
        self.model_service = model_service_pb2_grpc.ModelServiceStub(channel)
        if self.model_meta_from_serving:
            self.get_model_meta()
        return channel

    def prepare_request(self, input_objects: dict):
        request = predict_pb2.PredictRequest()
        request.model_spec.name = self.model_name
        if self.model_version is not None:
            request.model_spec.version.value = self.model_version
        for input_name, input_object in input_objects.items():
            request.inputs[input_name].CopyFrom(make_tensor_proto(input_object, shape=input_object.shape))
        return request

    def prepare_stateful_request(self, input_objects: dict, sequence_ctrl=None, sequence_id=None, ctrl_dtype=None,
                                 id_dtype=None):
        sequence_id_dtype = id_dtype if id_dtype else 'uint64'
        sequence_ctrl_dtype = ctrl_dtype if ctrl_dtype else 'uint32'
        request = self.prepare_request(input_objects)
        if sequence_ctrl is not None:
            request.inputs['sequence_control_input'].CopyFrom(make_tensor_proto([sequence_ctrl], dtype=sequence_ctrl_dtype))
        if sequence_id is not None:
            request.inputs['sequence_id'].CopyFrom(make_tensor_proto([sequence_id], dtype=sequence_id_dtype))
        return request

    def get_model_meta(self):
        metadata_field = "signature_def"
        request = get_model_metadata_pb2.GetModelMetadataRequest()
        request.model_spec.name = self.model_name
        if self.model_version is not None:
            request.model_spec.version.value = self.model_version
        request.metadata_field.append(metadata_field)
        response = self.prediction_service.GetModelMetadata(request, wait_for_ready=True, timeout=GRPC_TIMEOUT)
        signature_def = response.metadata['signature_def']
        signature_map = get_model_metadata_pb2.SignatureDefMap()
        signature_map.ParseFromString(signature_def.value)
        serving_default = signature_map.ListFields()[0][1]['serving_default']
        serving_inputs = serving_default.inputs
        serving_outputs = serving_default.outputs

        if self.input_names is None:
            self.input_names = [key for key in serving_inputs.keys()]
        if self.output_names is None:
            self.output_names = [key for key in serving_outputs.keys()]

        self.input_dims = dict()
        self.input_data_types = dict()
        self.output_dims = dict()
        self.output_data_types = dict()

        for input_name in self.input_names:
            input_tensor_shape = serving_inputs[input_name].tensor_shape
            self.input_dims[input_name] = [d.size for d in input_tensor_shape.dim]
            self.input_data_types[input_name] = self.get_data_type(data_type=serving_inputs[input_name].dtype)
        for output_name in self.output_names:
            output_tensor_shape = serving_outputs[output_name].tensor_shape
            self.output_dims[output_name] = [d.size for d in output_tensor_shape.dim]
            self.output_data_types[output_name] = self.get_data_type(data_type=serving_outputs[output_name].dtype)
        return response

    def get_model_status(self):
        request = get_model_status_pb2.GetModelStatusRequest()
        request.model_spec.name = self.model_name
        if self.model_version is not None:
            request.model_spec.version.value = self.model_version
        result = self.model_service.GetModelStatus(request, wait_for_ready=True, timeout=GRPC_TIMEOUT)
        return result

    def predict(self, request, timeout=GRPC_TIMEOUT):
        result = self.prediction_service.Predict(request, wait_for_ready=True, timeout=timeout)
        data = dict()
        for output_name, output in result.outputs.items():
            data[output_name] = make_ndarray(output)
        return data

    def predict_stateful_request(self, request, timeout=GRPC_TIMEOUT):
        result = self.prediction_service.Predict(request, wait_for_ready=True, timeout=timeout)
        data = dict()
        sequence_id = result.outputs.pop('sequence_id').uint64_val[0]
        for output_name, output in result.outputs.items():
            data[output_name] = make_ndarray(output)
        return sequence_id, data