#
# INTEL CONFIDENTIAL
# Copyright (c) 2020 Intel Corporation
#
# The source code contained or described herein and all documents related to
# the source code ("Material") are owned by Intel Corporation or its suppliers
# or licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material contains trade secrets and proprietary
# and confidential information of Intel or its suppliers and licensors. The
# Material is protected by worldwide copyright and trade secret laws and treaty
# provisions. No part of the Material may be used, copied, reproduced, modified,
# published, uploaded, posted, transmitted, distributed, or disclosed in any way
# without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
#
from typing import List

from e2e.command_utils import Communication
from e2e.process_utils import get_process, get_children, kill_child_processes


class UnexpectedResponseError(AssertionError):
    def __init__(self, status, error_message, message=None):
        message = message or "Code:{} Message:{}".format(status, error_message)
        super(UnexpectedResponseError, self).__init__(message)
        self.status = status
        self.error_message = error_message


class BaseCommandExecutionException(Exception):
    LOG_SEPARATOR = " [...] "
    MAX_CHARACTER_COUNT = 500000 - len(LOG_SEPARATOR)

    def __init__(self, output: List[str], command: str, communication: Communication = None, pid: int = None):
        super().__init__()
        self.communication = communication if communication is not None else Communication(pid=pid)
        self.communication.exception = self
        self.exception_cleanup(output)
        self.output = self.build_exception_output(output)
        self.command = command

    def build_exception_output(self, out):
        exception_output = "\n".join(out)
        if len(exception_output) > self.MAX_CHARACTER_COUNT:
            half = self.MAX_CHARACTER_COUNT // 2
            exception_output = "{}{}{}".format(exception_output[:half], self.LOG_SEPARATOR,
                                               exception_output[-half:])
        return exception_output

    def exception_cleanup(self, out: List[str]):
        if self.communication.pid is None:
            out.append("Lack of pid for parent process, cannot find its children.")
            return
        process = get_process(self.communication.pid)
        children = get_children(process)
        if len(children) > 0:
            out.append("Found not killed process children:")
            out.extend([str(child) for child in children])
            out.append("Trying to terminate process children...")
            kill_child_processes(process.pid)
            children = get_children(process)
            if len(children) > 0:
                out.append("Still found not killed process children:")
                out.extend([str(child) for child in children])
            else:
                out.append("All killed")
        if process.is_running():
            process.kill()


class CommandExecutionException(BaseCommandExecutionException):
    def __init__(self, return_code: int, output: List[str], command: str,
                 communication: Communication = None, pid: int = None):
        super().__init__(output, command, communication=communication, pid=pid)
        self.return_code = return_code

    def __str__(self):
        return "{exception}: received return code: {ret_code} while executing command:\n" \
               "{cmd}\n" \
               "command output:\n" \
               "{output}\n" \
            .format(exception=self.__class__.__name__, cmd=self.command, ret_code=self.return_code, output=self.output)


class TimeoutCommandExecutionException(BaseCommandExecutionException):

    def __init__(self, timeout: int, output: List[str], command: str,
                 communication: Communication = None, pid: int = None):
        super().__init__(output, command, communication=communication, pid=pid)
        self.timeout = timeout

    def __str__(self):
        return "{exception}: timeout occurred ({timeout}) while executing command:\n" \
               "{cmd}\n" \
               "command output:\n" \
               "{output}\n" \
            .format(exception=self.__class__.__name__, cmd=self.command, timeout=self.timeout, output=self.output)


class RedirectionLimitException(Exception):
    pass


class NotFoundException(Exception):
    """Exception that handles situations when the resource/element cannot be found"""
    def __init__(self, message: str):
        super().__init__()
        self.message = message

    def __str__(self):
        return self.message


def suppress_exception_call(method, *args, default_output: str = "<exception occurred>", **kwargs):
    try:
        output = method(*args, **kwargs)
        exc_info = None
    except Exception as e:
        output = default_output
        exc_info = e
    return output, exc_info
